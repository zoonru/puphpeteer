<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use function Amp\async;

/** Native runtime under development; full API coverage is tracked by the generator. */
final class Puppeteer
{
    public function connect(array $options): Future
    {
        return async(static function () use ($options): Browser {
            $endpoint = $options['browserWSEndpoint'] ?? throw new \InvalidArgumentException('browserWSEndpoint is required');
            return new Browser(Connection::open($endpoint, ($options['protocolTimeout'] ?? 30000) / 1000));
        });
    }
}
