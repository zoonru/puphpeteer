<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Nesk\Puphpeteer\Native\Generated\Upstream\CdpDialog;
use Nesk\Puphpeteer\Native\Generated\Upstream\PageCommands;
use Nesk\Puphpeteer\Native\Generated\Upstream\TimeoutSettings;
use function Amp\async;

/** Runtime adapter under construction; see Generated/api-coverage.json for coverage. */
final class Page extends EventEmitter
{
    use PageCommands;
    use Generated\Upstream\PageFileChooserCommands { waitForFileChooser as private sourceWaitForFileChooser; }
    public function waitForFileChooser(array|object $options = []): Future
    {
        $options = (array) $options;
        if (($options['signal'] ?? null) instanceof \Amp\Cancellation) { $options['signal'] = new Runtime\AbortSignal($options['signal']); }
        return $this->sourceWaitForFileChooser($options);
    }
    use Generated\Upstream\PageErrorCommands;
    use Generated\Upstream\PageConsoleCommands;
    use Generated\Upstream\PageDiagnosticsCommands { metrics as private sourceMetrics; }
    private object $primaryTargetMetadata;
    public function metrics(): Future { return $this->sourceMetrics()->map(static fn ($metrics) => (array) $metrics); }
    use Generated\Upstream\PageCoverageCommands;
    use Generated\Upstream\PageCookieCommands { cookies as private sourceCookies; }

    public function cookies(mixed ...$urls): Future
    {
        return $this->sourceCookies(...$urls)->map(static fn ($cookies) => array_map(static fn ($cookie) => (array) Runtime\Js::toWire($cookie), iterator_to_array(Runtime\Js::iterate($cookies), false)));
    }

    use Generated\Upstream\PageActionCommands;
    use Generated\Upstream\PageDragCommands;
    use Generated\Upstream\PageEmulationCommands;
    use Generated\Upstream\PageNetworkCommands;
    use Generated\Upstream\PageNavigationCommands;
    use Generated\Upstream\PageDocumentCommands;
    use Generated\Upstream\PageTagCommands;
    use Generated\Upstream\PageEventCommands;
    use Generated\Upstream\PageNetworkIdleCommands;

    private TimeoutSettings $timeouts;
    private FrameManager $frameManager;
    private bool $dragInterceptionEnabled = false;
    private Generated\Upstream\EmulationManager $emulationManager;
    private mixed $viewportValue = null;
    private bool $serviceWorkerBypassed = false;
    public readonly Coverage $coverage;
    public readonly Keyboard $keyboard;
    public readonly Mouse $mouse;
    public readonly Touchscreen $touchscreen;

    public function __construct(private Connection $connection, private Session $session, private string $targetId, private Browser $ownerBrowser)
    {
        parent::__construct();
        $this->primaryTargetMetadata = (object) ['_targetId' => $targetId];
        $session->setTarget($this->primaryTargetMetadata);
        $this->initializePageEmitter();
        $this->initializeFileChooser();
        $this->coverage = new Coverage($session);
        $this->timeouts = new TimeoutSettings();
        $this->initializePageNetworkIdle();
        $this->keyboard = new Keyboard($session);
        $this->mouse = new Mouse($session, $this->keyboard);
        $this->touchscreen = new Touchscreen($session, $this->keyboard);
        $this->emulationManager = new Generated\Upstream\EmulationManager($session);
        $this->frameManager = new FrameManager($this, $connection, $session, $this->timeouts);
        $this->session->observeAll(function (string $event, array $params): void {
            try { $this->forwardEvent($event, $params); }
            catch (\Throwable $error) { $this->session->track(Future::error($error)); }
        });
        $this->session->observe('__native_session_closed', function (): void {
            try { $this->emit('close', Runtime\UndefinedValue::Value); }
            catch (\Throwable $error) { $this->session->track(Future::error($error)); }
        });
    }

    public function initialize(): void { $this->CdpPage_initialize()->await(); }
    public function mainFrame(): Frame { return $this->frameManager->mainFrame(); }
    public function frames(): array { return $this->frameManager->frames(); }
    public function url(): string { return $this->mainFrame()->url(); }

    public function cdpSession(): Session { return $this->session; }
    public function browser(): Browser { return $this->ownerBrowser; }

    public function getDefaultTimeout(): int { return $this->timeouts->timeout(); }
    public function getDefaultNavigationTimeout(): int { return $this->timeouts->navigationTimeout(); }

    public function setDefaultTimeout(int $milliseconds): void { $this->timeouts->setDefaultTimeout($milliseconds); }
    public function setDefaultNavigationTimeout(int $milliseconds): void { $this->timeouts->setDefaultNavigationTimeout($milliseconds); }

    public function goto(string $url, array $options = []): Future { return $this->mainFrame()->goto($url, $options); }
    public function waitForNavigation(array|object $options = []): Future { return $this->mainFrame()->waitForNavigation((array) $options); }
    public function evaluate(JsFunction|string $function, mixed ...$arguments): Future { return $this->mainFrame()->evaluate($function, ...$arguments); }
    public function evaluateHandle(JsFunction|string $function, mixed ...$arguments): Future { return $this->mainFrame()->evaluateHandle($function, ...$arguments); }
    public function waitForFunction(JsFunction|string $function, array $options = [], mixed ...$arguments): Future { return $this->mainFrame()->waitForFunction($function, $options, ...$arguments); }
    public function waitForSelector(string $selector, array $options = []): Future { return $this->mainFrame()->waitForSelector($selector, $options); }
    public function querySelector(string $selector): Future { return $this->mainFrame()->querySelector($selector); }
    public function querySelectorAll(string $selector): Future { return $this->mainFrame()->querySelectorAll($selector); }
    public function title(): Future { return $this->mainFrame()->title(); }

    public function exposeFunction(string $name, callable $callback): Future { return $this->frameManager->exposeFunction($name, $callback); }
    public function removeExposedFunction(string $name): Future { return $this->frameManager->removeExposedFunction($name); }

    public function screenshot(array $options = []): Future
    {
        return async(function () use ($options): string {
            $result = $this->session->send('Page.captureScreenshot', ['format' => $options['type'] ?? 'png'])->await();
            $bytes = base64_decode($result['data'], true);
            if ($bytes === false) {
                throw new \RuntimeException('Invalid screenshot data');
            }
            if (isset($options['path'])) {
                // File writing is intentionally outside the event reader.
                if (file_put_contents($options['path'], $bytes) !== strlen($bytes)) {
                    throw new \RuntimeException('Cannot write screenshot');
                }
            }
            return $bytes;
        });
    }

    public function emit(mixed $type, mixed $event): mixed
    {
        return Runtime\Js::withCallbackObserver($this->session->track(...), fn () => parent::emit($type, $event));
    }

    private function forwardEvent(string $event, array $params): void
    {
        $mapped = [
            '__native_frameattached' => ['frameattached', 'frame'], '__native_framenavigated' => ['framenavigated', 'frame'], '__native_framedetached' => ['framedetached', 'frame'],
            '__native_request' => ['request', 'request'], '__native_requestfinished' => ['requestfinished', 'request'], '__native_requestfailed' => ['requestfailed', 'request'],
            '__native_requestservedfromcache' => ['requestservedfromcache', 'request'], '__native_response' => ['response', 'response'],
        ];
        if (isset($mapped[$event])) { [$name, $field] = $mapped[$event]; $this->emit($name, $params[$field]); return; }
        if ($event === 'Page.fileChooserOpened') { $this->session->track($this->CdpPage_onFileChooser($params)); return; }
        if ($event === 'Runtime.exceptionThrown') { $this->CdpPage_handleException($params); return; }
        if ($event === '__native_console') { $this->CdpPage_onConsoleAPI($params['world'], $params['event']); return; }
        if ($event === 'Performance.metrics') { $this->CdpPage_emitMetrics($params); return; }
        if ($event === 'Log.entryAdded') { $this->CdpPage_onLogEntryAdded($params); return; }
        if ($event === 'Page.javascriptDialogOpening') {
            $this->emit('dialog', new CdpDialog($this->session, $params['type'], $params['message'], $params['defaultPrompt'] ?? ''));
        } elseif ($event === 'Page.domContentEventFired' || $event === 'Page.loadEventFired') {
            $this->emit($event === 'Page.loadEventFired' ? 'load' : 'domcontentloaded', Runtime\UndefinedValue::Value);
        }
    }

    public function close(): Future
    {
        return $this->connection->session()->send('Target.closeTarget', ['targetId' => $this->targetId]);
    }
}
