<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\Future;
use Amp\TimeoutCancellation;
use Nesk\Puphpeteer\Native\Generated\Upstream\TimeoutSettings;
use function Amp\async;
use function Amp\Future\await;

/** Frame identity survives document and renderer changes; contexts belong to sessions. */
final class FrameManager
{
    /** @var array<string, Frame> */
    private array $frames = [];
    private ?Frame $main = null;
    public readonly NetworkManager $networkManager;
    private array $contexts = [];
    private array $defaults = [];
    private array $isolated = [];
    private array $sessions = [];
    private array $bindings = [];
    private array $bindingScripts = [];
    private ?Future $frameTreeUpdate = null;

    public function __construct(private Page $page, private Connection $connection, private Session $root, public readonly TimeoutSettings $timeoutSettings)
    {
        $this->networkManager = new NetworkManager($root, $this);
        $this->register($root);
    }

    public function page(): Page { return $this->page; }
    public function events(): Session { return $this->root; }
    public function frame(string $id): ?Frame { return $this->frames[$id] ?? null; }
    public function frames(): array { return array_values($this->frames); }
    public function mainFrame(): Frame { return $this->main ?? throw new \RuntimeException('Main frame is not initialized'); }

    public function frameTreeReady(): Future { return $this->frameTreeUpdate ?? Future::complete(); }

    private function ensureFrame(string $id, Session $session, ?string $parent = null): Frame
    {
        if (isset($this->frames[$id])) {
            if ($parent !== null) { $this->frames[$id]->parentId = $parent; }
            return $this->frames[$id];
        }
        $frame = $this->frames[$id] = new Frame($this, $id, $parent, $session, $this->timeoutSettings);
        if ($parent !== null) { $this->root->dispatch('__native_frameattached', ['frame' => $frame]); }
        return $frame;
    }

    private function navigated(Session $session, array $payload, string $type = 'Navigation'): void
    {
        $top = $session === $this->root && !isset($payload['parentId']);
        if ($top && $this->main !== null && $this->main->id !== $payload['id']) {
            unset($this->frames[$this->main->id]);
            $this->main->id = $payload['id'];
            $this->frames[$payload['id']] = $this->main;
        }
        $frame = $this->ensureFrame($payload['id'], $session, $payload['parentId'] ?? null);
        $frame->switchSession($session);
        $frame->navigated($payload);
        if ($top) { $this->main = $frame; }
        $this->root->dispatch('__native_framenavigated', ['frame' => $frame, 'type' => $type]);
    }

    private function remove(Frame $frame): void
    {
        foreach ($frame->childFrames() as $child) { $this->remove($child); }
        $this->networkManager->forgetFrame($frame->id);
        foreach ($this->contexts as $key => $contexts) {
            foreach ($contexts as $id => $context) {
                if ($context->frameId === $frame->id) { $context->invalidate(); unset($this->contexts[$key][$id]); }
            }
            unset($this->defaults[$key][$frame->id]);
            foreach (array_keys($this->isolated) as $cacheKey) {
                if (str_starts_with($cacheKey, $key . ':' . $frame->id . ':')) { unset($this->isolated[$cacheKey]); }
            }
        }
        $frame->markDetached();
        unset($this->frames[$frame->id]);
        $this->root->dispatch('__native_framedetached', ['frame' => $frame]);
        $this->root->dispatch('__native_contextchange', []);
    }

    private function register(Session $session): void
    {
        $key = $session->id() ?? '';
        if (isset($this->sessions[$key])) { return; }
        $this->sessions[$key] = $session;
        $this->networkManager->addClient($session);
        $session->observe('Page.lifecycleEvent', function (array $event): void {
            $frame = $this->frame($event['frameId']);
            if ($frame === null) { return; }
            $frame->_onLifecycleEvent($event['loaderId'], $event['name']);
            $this->root->dispatch('__native_lifecycle', ['frame' => $frame]);
        });
        $session->observe('Page.frameStartedLoading', function (array $event): void {
            $frame = $this->frame($event['frameId']);
            if ($frame !== null) { $frame->_onLoadingStarted(); }
        });
        $session->observe('Page.frameStoppedLoading', function (array $event): void {
            $frame = $this->frame($event['frameId']);
            if ($frame === null) { return; }
            $frame->_onLoadingStopped();
            $this->root->dispatch('__native_lifecycle', ['frame' => $frame]);
        });
        $session->observe('Page.frameAttached', fn (array $event) => $this->ensureFrame($event['frameId'], $session, $event['parentFrameId']));
        $session->observe('Page.frameNavigated', function (array $event) use ($session): void {
            $type = $event['type'] ?? 'Navigation';
            // BFCache restore can arrive after its child attachment events. Those
            // restored frames belong to the active document and must be retained.
            if ($type === 'BackForwardCacheRestore') {
                // Chrome may omit frameAttached for same-process cached children.
                // Reconcile their metadata before publishing restored navigation.
                $previousUpdate = $this->frameTreeUpdate;
                $update = $this->frameTreeUpdate = async(function () use ($session, $event, $type, $previousUpdate): void {
                    $previousUpdate?->await();
                    $result = $session->send('Page.getFrameTree')->await();
                    $tree = function (array $node) use ($session, &$tree): void {
                        $frame = $this->ensureFrame($node['frame']['id'], $session, $node['frame']['parentId'] ?? null);
                        $frame->navigated($node['frame']);
                        foreach ($node['childFrames'] ?? [] as $child) { $tree($child); }
                    };
                    $tree($result['frameTree']);
                    $this->navigated($session, $event['frame'], $type);
                });
                $session->track($update->finally(function () use ($update): void { if ($this->frameTreeUpdate === $update) { $this->frameTreeUpdate = null; } }));
                return;
            } else {
                $previous = $this->frame($event['frame']['id']);
                if ($previous === null && $session === $this->root && !isset($event['frame']['parentId'])) { $previous = $this->main; }
                foreach ($previous?->childFrames() ?? [] as $child) { $this->remove($child); }
            }
            $this->navigated($session, $event['frame'], $type);
        });
        $session->observe('Page.navigatedWithinDocument', function (array $event): void {
            $frame = $this->frame($event['frameId']);
            if ($frame !== null) {
                $frame->sameDocument($event['url']);
                $this->root->dispatch('__native_samedocument', ['frame' => $frame]);
                $this->root->dispatch('__native_framenavigated', ['frame' => $frame]);
            }
        });
        $session->observe('Page.frameDetached', function (array $event): void {
            if (($event['reason'] ?? '') !== 'swap' && ($frame = $this->frame($event['frameId'])) !== null) { $this->remove($frame); }
        });
        $session->observe('Runtime.executionContextCreated', function (array $event) use ($key, $session): void {
            $description = $event['context'];
            $frameId = $description['auxData']['frameId'] ?? null;
            if ($frameId === null) { return; }
            $frame = $this->ensureFrame($frameId, $session);
            $context = new ExecutionContext($session, $description['id'], $frameId, fn () => async(fn () => $this->context($frame, true)), $frame, ($description['auxData']['isDefault'] ?? false), $description['name'] ?? '');
            $context->on('consoleapicalled', function (object $event) use ($context): void {
                if (!$context->active() || !$context->consoleEnabled) { return; }
                $this->root->dispatch('__native_console', ['world' => $context, 'event' => (array) $event]);
            });
            $this->contexts[$key][$description['id']] = $context;
            if ($description['auxData']['isDefault'] ?? false) {
                $this->defaults[$key][$frameId] = $context;
                foreach ($this->bindings as $binding) { $context->registerBinding($binding); }
            }
            $this->root->dispatch('__native_contextchange', []);
        });
        $session->observe('Runtime.consoleAPICalled', function (array $event) use ($key): void {
            $world = $this->contexts[$key][$event['executionContextId']] ?? null;
            $world?->dispatchConsoleEvent((object) $event);
        });
        $session->on('Runtime.bindingCalled', function (array $event) use ($key): ?Future {
            return ($this->contexts[$key][$event['executionContextId']] ?? null)?->dispatchBinding($event);
        });
        $session->observe('Runtime.executionContextDestroyed', function (array $event) use ($key): void {
            $context = $this->contexts[$key][$event['executionContextId']] ?? null;
            $context?->invalidate();
            if ($context !== null) { unset($this->isolated[$key . ':' . $context->frameId . ':' . $context->id]); }
            unset($this->contexts[$key][$event['executionContextId']]);
            $this->root->dispatch('__native_contextchange', []);
        });
        $clear = function () use ($key): void {
            foreach ($this->contexts[$key] ?? [] as $context) { $context->invalidate(); }
            $this->contexts[$key] = $this->defaults[$key] = [];
            foreach (array_keys($this->isolated) as $cacheKey) { if (str_starts_with($cacheKey, $key . ':')) { unset($this->isolated[$cacheKey]); } }
            $this->root->dispatch('__native_contextchange', []);
        };
        $session->observe('Runtime.executionContextsCleared', $clear);
        $session->observe('__native_session_closed', function () use ($clear, $key, $session): void {
            $clear();
            unset($this->sessions[$key], $this->contexts[$key], $this->defaults[$key], $this->bindingScripts[$key]);
            if ($session === $this->root) { foreach ($this->frames() as $frame) { if (!$frame->detached()) { $this->remove($frame); } } }
        });
        $session->on('Target.attachedToTarget', function (array $event): Future {
            return async(function () use ($event): void {
                $child = $this->connection->session($event['sessionId']);
                $child->setTarget((object) ['_targetId' => $event['targetInfo']['targetId']]);
                try {
                    if ($event['targetInfo']['type'] !== 'iframe') { return; }
                    $frame = $this->ensureFrame($event['targetInfo']['targetId'], $child);
                    $frame->switchSession($child);
                    $this->register($child);
                    $this->initializeSession($child);
                } finally { $child->send('Runtime.runIfWaitingForDebugger')->await(); }
            });
        });
    }

    private function installExposedBinding(Session $session, Binding $binding): Future
    {
        $key = $session->id() ?? '';
        return $this->bindingScripts[$key][$binding->name] ??= async(function () use ($session, $binding): string {
            $session->send('Runtime.addBinding', ['name' => Generated\Upstream\BindingFunctions::prefix . $binding->name])->await();
            $result = $session->send('Page.addScriptToEvaluateOnNewDocument', ['source' => $binding->initSource()])->await();
            return $result['identifier'];
        });
    }

    public function exposeFunction(string $name, callable $callback): Future
    {
        return async(function () use ($name, $callback): void {
            if (isset($this->bindings[$name])) { throw new \RuntimeException("Failed to add page binding with name {$name}: window['{$name}'] already exists!"); }
            $binding = $this->bindings[$name] = new Binding($name, \Closure::fromCallable($callback));
            try {
                await(array_map(fn (Session $session) => $this->installExposedBinding($session, $binding), $this->sessions));
                $installs = [];
                foreach ($this->defaults as $contexts) {
                    foreach ($contexts as $context) {
                        if (!$context->active()) { continue; }
                        $installs[] = $context->bind($binding, false)->catch($context->rethrowIfActive(...));
                    }
                }
                await($installs);
            } catch (\Throwable $error) {
                try { $this->removeExposedFunction($name)->await(); } catch (\Throwable) {}
                throw $error;
            }
        });
    }

    public function removeExposedFunction(string $name): Future
    {
        return async(function () use ($name): void {
            if (!isset($this->bindings[$name])) { throw new \RuntimeException('Failed to remove page binding with name ' . $name . ': binding does not exist'); }
            unset($this->bindings[$name]);
            $removals = [];
            foreach ($this->sessions as $key => $session) {
                $script = $this->bindingScripts[$key][$name] ?? null;
                unset($this->bindingScripts[$key][$name]);
                $removals[] = async(static function () use ($session, $script, $name): void {
                    if ($script !== null) {
                        $id = $script->await();
                        $session->send('Page.removeScriptToEvaluateOnNewDocument', ['identifier' => $id])->await();
                    }
                    $session->send('Runtime.removeBinding', ['name' => Generated\Upstream\BindingFunctions::prefix . $name])->await();
                });
            }
            foreach ($this->defaults as $contexts) {
                foreach ($contexts as $context) {
                    if (!$context->active()) { continue; }
                    $removals[] = $context->unbind($name)->catch($context->rethrowIfActive(...));
                }
            }
            await($removals);
        });
    }

    public function initialize(?Session $session = null): Future { return Runtime\Js::async(fn () => $this->initializeSession($session ?? $this->root)); }

    private function initializeSession(Session $session): void
    {
        await(array_map(fn (Binding $binding) => $this->installExposedBinding($session, $binding), $this->bindings));
        $tree = function (array $node) use ($session, &$tree): void {
            $this->navigated($session, $node['frame']);
            foreach ($node['childFrames'] ?? [] as $child) { $tree($child); }
        };
        await([
            $session->send('Page.enable'), $session->send('Runtime.enable'), $this->networkManager->initializeNetworkClient($session),
            $session->send('Page.setLifecycleEventsEnabled', ['enabled' => true]),
            $session->send('Page.getFrameTree')->map(fn (array $result) => $tree($result['frameTree'])),
            $session->send('Target.setAutoAttach', ['autoAttach' => true, 'waitForDebuggerOnStart' => true, 'flatten' => true]),
        ]);
    }

    public function context(Frame $frame, bool $isolated = false, ?Cancellation $cancellation = null): ExecutionContext
    {
        $cancellation ??= $this->timeoutSettings->timeout() > 0 ? new TimeoutCancellation($this->timeoutSettings->timeout() / 1000) : null;
        while (true) {
            $frame->assertAttached();
            $cancellation?->throwIfRequested();
            $session = $frame->session();
            $key = $session->id() ?? '';
            $context = $this->defaults[$key][$frame->id] ?? null;
            if ($context?->active()) { break; }
            $this->root->waitFor('__native_contextchange', null, $cancellation)->await();
        }
        if (!$isolated) { return $context; }
        $cacheKey = $key . ':' . $frame->id . ':' . $context->id;
        $future = $this->isolated[$cacheKey] ??= async(function () use ($frame, $session, $key): ExecutionContext {
            $result = $session->send('Page.createIsolatedWorld', ['frameId' => $frame->id, 'worldName' => '__puppeteer_native_utility_world__', 'grantUniveralAccess' => true])->await();
            return $this->contexts[$key][$result['executionContextId']] ??= new ExecutionContext($session, $result['executionContextId'], $frame->id, null, $frame, false, '__puppeteer_native_utility_world__');
        });
        $isolatedContext = $future->await($cancellation);
        if (!$isolatedContext->active()) {
            unset($this->isolated[$cacheKey]);
            return $this->context($frame, true, $cancellation);
        }
        return $isolatedContext;
    }

}
