<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
use function Amp\async;

/** The lifetime and argument-serialization boundary for CDP evaluation. */
final class ExecutionContext extends EventEmitter implements Runtime\JsObject
{
    use Generated\Upstream\RealmTransferCommands;
    private bool $active = true;
    use Generated\Upstream\ExecutionUtilityCommands;
    use Generated\Upstream\ExecutionBindingCommands;
    use Generated\Upstream\ExecutionEventCommands;
    use Generated\Upstream\PageBindingCommands;
    private ?Generated\Upstream\ExecutionEvaluator $evaluator = null;
    private ?Future $selectorUtility = null;
    private Runtime\JsMap $bindings;
    private array $bindingInstalls = [];

    public function __construct(public readonly Session $session, public readonly int $id, public readonly string $frameId, private readonly ?\Closure $isolatedResolver = null, public readonly ?Frame $frame = null, public readonly bool $consoleEnabled = true, public readonly string $name = '') {
        parent::__construct();
        $this->initializeSourceBindings();
        $this->bindings = new Runtime\JsMap();
        $this->on('bindingcalled', fn ($event) => $this->dispatchExposedBinding($this, $event));
    }

    public function getJsProperty(string $name): mixed { return match ($name) { 'environment' => $this->frame, 'context' => $this->active ? $this : UndefinedValue::Value, default => UndefinedValue::Value }; }

    public function invalidate(): void { $this->active = false; $this->bindings->clear(); $this->bindingInstalls = []; $this->sourceBindings->clear(); }
    public function active(): bool { return $this->active; }

    public function evaluateHandle(JsFunction|string $function, mixed ...$arguments): Future
    {
        return $this->evaluate($function, $arguments, false);
    }

    public function adoptBackendNode(mixed $backendNodeId = UndefinedValue::Value): Future
    {
        return async(function () use ($backendNodeId): JSHandle {
            if (!$this->active) { throw new \RuntimeException('Execution context was destroyed'); }
            $result = $this->session->send('DOM.resolveNode', ['backendNodeId'=>$backendNodeId, 'executionContextId'=>$this->id])->await();
            return $this->handle($result['object']);
        });
    }

    /** Recheck lifetime after a suspended operation, when navigation may have destroyed this context. */
    public function rethrowIfActive(\Throwable $error): void
    {
        if ($this->active) { throw $error; }
    }

    public function evaluate(JsFunction|string $function, array $arguments = [], bool $returnByValue = true, ?Cancellation $cancellation = null): Future
    {
        return Js::async(function () use ($function, $arguments, $returnByValue, $cancellation): mixed {
            if (!$this->active) {
                throw new \RuntimeException('Execution context was destroyed, most likely because of a navigation');
            }
            $client = new Runtime\EvaluationClient($this->session, $this, $cancellation);
            $evaluator = $this->evaluator ??= new Generated\Upstream\ExecutionEvaluator($this, $this->id);
            return $evaluator->run($client, $returnByValue, $function, ...$arguments)->await();
        });
    }

    public function waitForFunction(JsFunction|string $function, array $options, array $arguments): Future
    {
        return async(function () use ($function, $options, $arguments): JSHandle {
            $polling = $options['polling'] ?? 'raf';
            if (!in_array($polling, ['raf', 'mutation'], true) && !((is_int($polling) || is_float($polling)) && $polling > 0)) {
                throw new \InvalidArgumentException('polling must be raf, mutation or a positive interval');
            }
            $source = $function instanceof JsFunction ? $function->source : '() => (' . $function . ')';
            $utility = $this->utility()->await();
            $task = $utility->evaluateHandle(new JsFunction(<<<'JS'
(utility, source, polling, root, ...args) => {
    const fn = utility.createFunction(source);
    const predicate = () => fn(...args);
    const poller = polling === 'raf' ? new utility.RAFPoller(predicate)
        : polling === 'mutation' ? new utility.MutationPoller(predicate, root ?? document)
        : new utility.IntervalPoller(predicate, polling);
    const result = (async () => { await poller.start(); return await poller.result(); })();
    result.catch(() => {});
    return {result, stop: () => poller.stop()};
}
JS), $source, $polling, $options['root'] ?? UndefinedValue::Value, ...$arguments)->await();
            try {
                return $this->evaluate(new JsFunction('task => task.result'), [$task], false, $options['signal'] ?? null)->await();
            } finally {
                try { $task->evaluate(new JsFunction('task => task.stop()'))->await(); } catch (\Throwable) {}
                $task->dispose()->await();
            }
        });
    }

    public function isolated(): Future
    {
        return $this->isolatedResolver === null ? Future::complete($this) : ($this->isolatedResolver)();
    }

    public function adoptElement(ElementHandle $handle): Future
    {
        return async(function () use ($handle): ElementHandle {
            if ($handle->disposed()) { throw new \RuntimeException('JSHandle is disposed'); }
            if (!$handle->context()->active() || !$this->active) { throw new \RuntimeException('Execution context was destroyed'); }
            if ($handle->context() === $this) { return $handle; }
            $node = $this->session->send('DOM.describeNode', ['objectId' => $handle->id()])->await();
            $result = $this->session->send('DOM.resolveNode', ['backendNodeId' => $node['node']['backendNodeId'], 'executionContextId' => $this->id])->await();
            return new ElementHandle($this, $result['object']);
        });
    }

    public function registerBinding(Binding $binding): void { $this->bindings->set($binding->name, $binding); }

    public function bind(Binding $binding, bool $installProtocol = true): Future
    {
        $this->registerBinding($binding);
        return $this->bindingInstalls[$binding->name] ??= async(function () use ($binding, $installProtocol): void {
            if ($installProtocol) {
                $this->session->send('Runtime.addBinding', ['name' => Generated\Upstream\BindingFunctions::prefix . $binding->name, 'executionContextId' => $this->id])->await();
            }
            $this->evaluate($binding->initSource())->await();
        });
    }

    public function unbind(string $name): Future
    {
        $this->bindings->delete($name); unset($this->bindingInstalls[$name]);
        return $this->evaluate(new JsFunction('name => { delete globalThis[name]; }'), [$name]);
    }

    public function dispatchBinding(array $event): Future { return $this->dispatchBindingEvent((object) $event); }

    public function emit(mixed $type, mixed $event): mixed
    {
        return Js::withCallbackObserver($this->session->track(...), fn () => parent::emit($type, $event));
    }

    public function utility(): Future { return $this->sourceUtility(); }

    /** Original selector parser bundle has its own handle; PuppeteerUtil remains frozen. */
    public function selectorUtility(): Future
    {
        return $this->selectorUtility ??= $this->evaluateHandle(file_get_contents(__DIR__ . '/Generated/selectors.js'));
    }

    /** Variadic evaluate signature used by the generated binding installer. */
    private function evaluateBinding(JsFunction $function, mixed ...$arguments): Future { return $this->evaluate($function, $arguments); }

    /** ExecutionContext's source #world is the realm represented by this adapter. */
    public function sourceWorld(): self { return $this; }

    public function argument(mixed $argument): object
    {
        return Generated\Upstream\ExecutionHelpers::convertArgument($this, $argument);
    }

    public function createCdpHandle(array|object $remote): JSHandle { return $this->handle((array) $remote); }

    public function handle(array $remote): JSHandle
    {
        return ($remote['subtype'] ?? null) === 'node' ? new ElementHandle($this, $remote) : new JSHandle($this, $remote);
    }
}
