<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

class TouchHandle extends Generated\Upstream\CdpTouchHandle {}
