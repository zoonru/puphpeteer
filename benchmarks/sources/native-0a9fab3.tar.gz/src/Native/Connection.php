<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\CompositeCancellation;
use Amp\DeferredFuture;
use Amp\Future;
use Amp\Sync\LocalMutex;
use Amp\TimeoutCancellation;
use Amp\Websocket\Client\WebsocketConnection;
use Nesk\Puphpeteer\Native\Runtime\Js;
use function Amp\async;
use function Amp\Websocket\Client\connect;

/** One reader, multiplexed request IDs, and independent async event handlers. */
final class Connection
{
    private int $nextId = 0;
    /** @var array<int, array{deferred: DeferredFuture, session: ?string}> */
    private array $pending = [];
    private array $sessions = [];
    private LocalMutex $writer;
    private bool $closed = false;
    private ?\Throwable $listenerError = null;

    public function __construct(private WebsocketConnection $socket, private float $timeout = 30)
    {
        $this->writer = new LocalMutex();
        async(function (): void {
            try {
                while (($message = $this->socket->receive()) !== null) {
                    $data = json_decode($message->buffer(), true, 512, JSON_THROW_ON_ERROR);
                    if (isset($data['id'])) {
                        $entry = $this->pending[$data['id']] ?? null;
                        if ($entry === null) {
                            continue; // Timed out/cancelled command: discard its late response.
                        }
                        if (($data['sessionId'] ?? null) !== $entry['session']) {
                            throw new \RuntimeException('CDP response has an unexpected sessionId');
                        }
                        unset($this->pending[$data['id']]);
                        $entry['deferred']->complete($data);
                        continue;
                    }
                    if (($data['method'] ?? '') === 'Target.detachedFromTarget') {
                        $id = $data['params']['sessionId'];
                        $this->detach($id);
                    }
                    $this->session($data['sessionId'] ?? null)->dispatch($data['method'] ?? '', $data['params'] ?? []);
                }
                $this->shutdown(new TargetCloseError('Browser connection closed'));
            } catch (\Throwable $error) {
                $this->shutdown($error);
            }
        })->ignore();
    }

    public static function open(string $endpoint, float $timeout = 30): self
    {
        return new self(connect($endpoint, new TimeoutCancellation($timeout)), $timeout);
    }

    public function session(?string $id = null): Session
    {
        return $this->sessions[$id ?? ''] ??= new Session($this, $id);
    }

    public function send(string $method, array|object $params = [], ?string $sessionId = null, ?Cancellation $cancellation = null): Future
    {
        if ($this->closed) { return Future::error(new TargetCloseError('Browser connection is closed')); }
        // Match the synchronous JSON serialization boundary of the Node transport.
        $params = Js::toWire((object) $params);
        return async(function () use ($method, $params, $sessionId, $cancellation): array {
            if ($this->closed) {
                throw new TargetCloseError('Browser connection is closed');
            }
            if (count($this->pending) >= 1024) {
                throw new \RuntimeException('Too many in-flight browser commands');
            }
            $deadline = new TimeoutCancellation($this->timeout);
            $cancel = $cancellation ? new CompositeCancellation($deadline, $cancellation) : $deadline;
            $id = ++$this->nextId;
            $deferred = new DeferredFuture();
            $this->pending[$id] = ['deferred' => $deferred, 'session' => $sessionId];
            $deferred->getFuture()->ignore(); // A write error can race connection shutdown.
            try {
                $payload = ['id' => $id, 'method' => $method, 'params' => $params];
                if ($sessionId !== null) {
                    $payload['sessionId'] = $sessionId;
                }
                $encoded = json_encode($payload, JSON_THROW_ON_ERROR);
                // The caller can cancel while waiting for the writer. If a frame is already
                // being written, finish it atomically and discard the late response.
                $write = async(function () use ($encoded, $cancel): void {
                    $lock = $this->writer->acquire();
                    try {
                        $cancel->throwIfRequested();
                        $this->socket->sendText($encoded);
                    } finally {
                        $lock->release();
                    }
                });
                $write->ignore();
                $write->await($cancel);
                $response = $deferred->getFuture()->await($cancel);
                if (isset($response['error'])) {
                    throw new ProtocolException($method, $response['error']);
                }
                return $response['result'] ?? [];
            } finally {
                unset($this->pending[$id]);
            }
        });
    }

    private function detach(string $id): void
    {
        foreach ($this->pending as $key => $entry) {
            if ($entry['session'] === $id) {
                unset($this->pending[$key]);
                $entry['deferred']->error(new TargetCloseError('CDP session detached'));
            }
        }
        if (isset($this->sessions[$id])) {
            $this->sessions[$id]->markClosed();
            unset($this->sessions[$id]);
        }
    }

    public function recordListenerError(\Throwable $error): void
    {
        $this->listenerError ??= $error;
    }

    public function throwListenerError(): void
    {
        if ($this->listenerError !== null) {
            $error = $this->listenerError;
            $this->listenerError = null;
            throw $error;
        }
    }

    private function shutdown(\Throwable $error): void
    {
        if ($this->closed) {
            return;
        }
        $this->closed = true;
        foreach ($this->pending as $entry) {
            $entry['deferred']->error($error);
        }
        $this->pending = [];
        foreach ($this->sessions as $session) {
            $session->markClosed();
        }
        $this->sessions = [];
        $this->socket->close();
    }

    public function close(): void
    {
        $this->shutdown(new TargetCloseError('Browser connection closed by PHP'));
    }
}
