<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Amp\Future;
use Nesk\Puphpeteer\Native\{ExecutionContext,JSHandle,JsFunction};

/** Source variadic evaluation signatures over a native execution context. */
final class BindingContext
{
    public function __construct(private ExecutionContext $context) {}
    public function evaluate(JsFunction|string $function, mixed ...$arguments): Future
    {
        return $this->context->evaluate($function, $arguments);
    }
    public function evaluateHandle(JsFunction|string $function, mixed ...$arguments): Future
    {
        return $this->context->evaluateHandle($function, ...$arguments)
            ->map(static fn (JSHandle $handle) => new BindingHandle($handle));
    }
}
