<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Identity-bearing host equivalents of the source's well-known Symbols. */
enum WellKnownSymbol
{
    case Dispose;
    case AsyncDispose;
    case ToStringTag;
}
