<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Insertion-ordered Map with SameValueZero keys, including object identity. */
final class JsMap implements \IteratorAggregate
{
    private array $entries = [];
    public function __construct(mixed $iterable = null)
    {
        if ($iterable === null || $iterable === UndefinedValue::Value) { return; }
        foreach (Js::iterate($iterable) as $entry) {
            if (!is_array($entry) && !is_object($entry)) { throw new \TypeError('Iterator value is not an entry object'); }
            $this->set(Js::get($entry, 0), Js::get($entry, 1));
        }
    }
    private function index(mixed $key): ?int
    {
        foreach ($this->entries as $index => [$stored]) { if (Js::strictEqual($key, $stored) || is_float($key) && is_nan($key) && is_float($stored) && is_nan($stored)) { return $index; } }
        return null;
    }
    public function has(mixed $key): bool { return $this->index($key) !== null; }
    public function get(mixed $key): mixed { $index = $this->index($key); return $index === null ? UndefinedValue::Value : $this->entries[$index][1]; }
    public function set(mixed $key, mixed $value): self { $index = $this->index($key); if ($index === null) { $this->entries[] = [$key, $value]; } else { $this->entries[$index][1] = $value; } return $this; }
    public function delete(mixed $key): bool { $index = $this->index($key); if ($index === null) { return false; } unset($this->entries[$index]); return true; }
    public function clear(): void { $this->entries = []; }
    public function keys(): \Traversable { foreach ($this->entries as [$key]) { yield $key; } }
    public function getIterator(): \Traversable { foreach ($this->entries as $entry) { yield new JsArray($entry); } }
}
