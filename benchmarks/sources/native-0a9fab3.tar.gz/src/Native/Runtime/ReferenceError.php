<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

final class ReferenceError extends JsError
{
    public function __construct(mixed $message = UndefinedValue::Value)
    {
        parent::__construct($message);
        $this->setJsProperty('name', 'ReferenceError');
    }
}
