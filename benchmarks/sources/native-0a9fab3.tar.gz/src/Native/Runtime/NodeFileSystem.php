<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Amp\Future;
use function Amp\delay;

/** Local UTF-8 file reads; yields between chunks and never launches a process. */
final class NodeFileSystem
{
    public static function readFile(mixed $path, mixed $encoding): Future
    {
        return Js::async(static function () use ($path, $encoding): string {
            if (!is_string($path) || str_contains($path, "\0")) { throw new \TypeError('The path argument must be a string without null bytes'); }
            if ($encoding !== 'utf8') { throw new \TypeError('File encoding requires an explicit runtime adapter'); }
            delay(0);
            // Node treats URL-shaped string arguments as paths, not stream wrappers.
            $localPath = str_contains($path, '://') ? './'.$path : $path;
            if (is_dir($localPath)) { throw new NodeFileError('EISDIR', $path, 'read'); }
            $file = @fopen($localPath, 'rb');
            if ($file === false) { throw new NodeFileError(file_exists($localPath) ? 'EACCES' : 'ENOENT', $path); }
            try {
                $content = '';
                while (!feof($file)) {
                    $chunk = fread($file, 65536);
                    if ($chunk === false) { throw new NodeFileError('EIO', $path, 'read'); }
                    $content .= $chunk;
                    if (!feof($file)) { delay(0); }
                }
                return json_decode(json_encode($content, JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR), true, 512, JSON_THROW_ON_ERROR);
            } finally { fclose($file); }
        });
    }
}
