<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** String-valued JS Set used by generated code. */
final class StringSet
{
    private array $values = [];
    public function has(string $value): bool { return isset($this->values[$value]); }
    public function add(string $value): self { $this->values[$value] = true; return $this; }
    public function delete(string $value): bool { $exists = $this->has($value); unset($this->values[$value]); return $exists; }
    public function clear(): void { $this->values = []; }
}
