<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Compiler permits a shared regex subset and the audited /-./g replacement. */
final class JsRegExp
{
    public function __construct(private string $pattern, private bool $global = false, private bool $prefixMatch = false) {}
    public function test(mixed $value): bool
    {
        if ($this->global) { throw new \TypeError('Stateful global RegExp.test requires a lastIndex adapter'); }
        return preg_match($this->pattern, Js::string($value)) === 1;
    }
    public function replaceAll(string $value, \Closure $replacement): string
    {
        if (!$this->global || $this->pattern !== '/-./') { throw new \TypeError('RegExp.replaceAll requires an audited global pattern'); }
        // This non-Unicode JS regexp consumes one UTF-16 unit after '-'.
        if (preg_match('/-[\x{10000}-\x{10ffff}]/u', $value)) { throw new \TypeError('Surrogate regexp replacement requires a JS string adapter'); }
        return preg_replace_callback('/-[^\r\n\x{2028}\x{2029}]/u', static function (array $match) use ($value, $replacement): string {
            $offset = intdiv(strlen(mb_convert_encoding(substr($value, 0, $match[0][1]), 'UTF-16LE', 'UTF-8')), 2);
            return Js::string($replacement($match[0][0], $offset, $value));
        }, $value, -1, $count, PREG_OFFSET_CAPTURE);
    }
    public function replace(string $value, string $replacement): string
    {
        if (!$this->global || $this->pattern !== '/\\n/' || str_contains($replacement, '$')) { throw new \TypeError('RegExp.replace requires an audited pattern and literal replacement'); }
        return str_replace("\n", $replacement, $value);
    }
    public function match(string $value): ?array
    {
        if ($this->prefixMatch && !$this->global) {
            $matched = preg_match($this->pattern, $value, $matches, PREG_UNMATCHED_AS_NULL);
            if ($matched === false) { throw new \TypeError('RegExp match failed: ' . preg_last_error_msg()); }
            return $matched ? array_map(static fn ($value) => $value ?? UndefinedValue::Value, $matches) : null;
        }
        if ($this->global || $this->pattern !== '/[^ ]* [^ ]* (.*)/') { throw new \TypeError('RegExp.match requires an audited pattern'); }
        return preg_match('/[^ ]* [^ ]* ([^\r\n\x{2028}\x{2029}]*)/u', $value, $matches) === 1 ? $matches : null;
    }
}
