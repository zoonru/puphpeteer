<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Strong, insertion-ordered Map for the compiler's explicitly object-keyed maps. */
final class ObjectMap
{
    private \SplObjectStorage $storage;
    public function __construct() { $this->storage = new \SplObjectStorage(); }
    public function has(object $key): bool { return $this->storage->offsetExists($key); }
    public function set(object $key, mixed $value): self { $this->storage[$key] = $value; return $this; }
    public function get(object $key): mixed { return $this->has($key) ? $this->storage[$key] : UndefinedValue::Value; }
    public function delete(object $key): bool { $has = $this->has($key); $this->storage->offsetUnset($key); return $has; }
    public function keys(): JsArray { $keys = []; foreach ($this->storage as $key) { $keys[] = $key; } return new JsArray($keys); }
}
