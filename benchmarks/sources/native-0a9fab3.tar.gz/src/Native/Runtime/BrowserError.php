<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Browser exception with the JS stack assembled by upstream client/evaluation error helpers. */
final class BrowserError extends JsError
{
    public static int $stackTraceLimit = 10;
    private ?string $browserStack = null;
    private array $hostFrames;
    public function __construct(mixed $message = UndefinedValue::Value, mixed $options = UndefinedValue::Value)
    {
        parent::__construct($message, $options);
        $trace = $this->getTrace();
        $this->hostFrames = [];
        // A V8 stack starts at the new Error expression, not inside the Error constructor.
        foreach (array_slice([['file'=>$this->getFile(), 'line'=>$this->getLine()], ...$trace], 0, max(0, self::$stackTraceLimit)) as $index => $frame) {
            $caller = $trace[$index] ?? [];
            $function = ($caller['class'] ?? '') . ($caller['type'] ?? '') . ($caller['function'] ?? '<anonymous>');
            $this->hostFrames[] = '    at ' . $function . ' (' . ($frame['file'] ?? '<internal>') . ':' . ($frame['line'] ?? 0) . ':0)';
        }
    }
    public function getJsProperty(string $name): mixed
    {
        if ($name !== 'stack') { return parent::getJsProperty($name); }
        if ($this->browserStack === null) {
            $errorName = parent::getJsProperty('name');
            $message = $this->getMessage();
            $header = $errorName === '' ? $message : ($message === '' ? $errorName : $errorName . ': ' . $message);
            $this->browserStack = implode("\n", [$header, ...$this->hostFrames]);
        }
        return $this->browserStack;
    }
    public function setJsProperty(string $name, mixed $value): mixed
    {
        if ($name === 'stack') { $this->browserStack = Js::string($value); return $value; }
        return parent::setJsProperty($name, $value);
    }
}
