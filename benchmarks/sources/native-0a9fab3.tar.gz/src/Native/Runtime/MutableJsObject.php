<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

interface MutableJsObject extends JsObject
{
    public function setJsProperty(string $name, mixed $value): mixed;
}
