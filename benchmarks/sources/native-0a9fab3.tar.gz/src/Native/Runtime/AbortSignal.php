<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** EventTarget bridge for source methods accepting AbortSignal through Amp Cancellation. */
final class AbortSignal implements JsObject
{
    private mixed $reason=UndefinedValue::Value;
    public function __construct(private \Amp\Cancellation $cancellation){}
    public function getJsProperty(string $name):mixed{return $name==='reason'?$this->reason:UndefinedValue::Value;}
    public function addEventListener(string $event,\Closure $listener,array|object $options=[]):void
    {
        if($event!=='abort'||!Js::truthy(Js::get($options,'once'))){throw new \TypeError('Only one-shot abort listeners are supported');}
        // Registering a DOM abort listener after abortion does not replay the event.
        if($this->cancellation->isRequested())return;
        $id=null;
        $id=$this->cancellation->subscribe(function(\Amp\CancelledException $reason)use($listener,&$id):void{
            $this->reason=$reason;
            if($id!==null)$this->cancellation->unsubscribe($id);
            Js::discard(Js::call($listener,[]));
        });
    }
}
