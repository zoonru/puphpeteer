<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

use Amp\Future;

/** Explicit semantic adapters used by the source compiler. */
final class Js
{
    private static ?\Closure $debugLogger = null;
    private static ?\WeakMap $callbackObservers = null;
    private static ?\Closure $mainCallbackObserver = null;

    public static function withCallbackObserver(?\Closure $observer, \Closure $operation): mixed
    {
        $fiber = \Fiber::getCurrent(); $map = self::$callbackObservers ??= new \WeakMap();
        $previous = $fiber === null ? self::$mainCallbackObserver : ($map[$fiber] ?? null);
        if ($fiber === null) { self::$mainCallbackObserver = $observer; } else { $map[$fiber] = $observer; }
        try { return $operation(); }
        finally { if ($fiber === null) { self::$mainCallbackObserver = $previous; } elseif ($previous === null) { unset($map[$fiber]); } else { $map[$fiber] = $previous; } }
    }

    /** Run the synchronous prefix now; suspended PHP handlers behave like JS async callbacks. */
    public static function call(callable $callback, array $arguments): mixed
    {
        $parent = \Fiber::getCurrent(); $map = self::$callbackObservers ??= new \WeakMap();
        $observer = $parent === null ? self::$mainCallbackObserver : ($map[$parent] ?? null);
        $deferred = new \Amp\DeferredFuture(); $value = UndefinedValue::Value; $error = null; $returnedFuture = false;
        $fiber = new \Fiber(static function () use ($callback, $arguments, $observer, $map, $deferred, &$value, &$error, &$returnedFuture): void {
            $current = \Fiber::getCurrent();
            if ($observer !== null) { $map[$current] = $observer; }
            try { $value = $callback(...$arguments); $returnedFuture = $value instanceof Future; if ($returnedFuture) { $value = $value->await(); } $deferred->complete($value); }
            catch (\Throwable $failure) { $error = $failure; $deferred->error($failure); }
            finally { unset($map[$current]); }
        });
        $fiber->start(); $future = $deferred->getFuture();
        if ($fiber->isTerminated() && !$returnedFuture) { $future->ignore(); if ($error !== null) { throw $error; } return $value; }
        if ($observer !== null) { $observer($future); }
        return $future;
    }

    /** Source method references are already bound to their PHP receiver. */
    public static function callBoundMethod(\Closure $method, object $receiver, array $arguments): mixed
    {
        if ((new \ReflectionFunction($method))->getClosureThis() !== $receiver) {
            throw new \TypeError('Rebinding a source method to another receiver requires an adapter');
        }
        return $method(...$arguments);
    }

    /** Awaitable predicate errors belong to the consuming operation, not the event listener sink. */
    public static function callAwaitable(callable $callback, array $arguments): mixed
    {
        return self::withCallbackObserver(null, static fn () => self::call($callback, $arguments));
    }

    public static function last(mixed $first, mixed $last): mixed { return $last; }
    public static function unsignedShift(int $value, int $bits): int { return ($value & 0xffffffff) >> ($bits & 31); }
    public static function get(mixed $value, string|int|WellKnownSymbol $key): mixed
    {
        if ($key instanceof WellKnownSymbol) {
            if ($value === null || $value === UndefinedValue::Value) { throw new \TypeError('Cannot read a property of null or undefined'); }
            return $value instanceof JsSymbolObject ? $value->getJsSymbol($key) : UndefinedValue::Value;
        }
        if ($value instanceof JsArray) { return $value->get($key); }
        if ($value instanceof JsObject) { return $value->getJsProperty((string) $key); }
        if ($value instanceof \Throwable && $key === 'stack') { return $value->getTraceAsString(); }
        if ($value instanceof \Throwable && $key === 'name') { return $value instanceof \TypeError ? 'TypeError' : 'Error'; }
        if ($value instanceof \Throwable && $key === 'message') { return $value->getMessage(); }
        if ($value instanceof \Throwable && $key === 'originalMessage') { return $value->getMessage(); }
        if ($value === null || $value === UndefinedValue::Value) {
            throw new \TypeError('Cannot read a property of null or undefined');
        }
        if (is_array($value)) {
            if ($key === 'length' && array_is_list($value)) { return count($value); }
            return array_key_exists($key, $value) ? $value[$key] : UndefinedValue::Value;
        }
        if (is_string($value) && $key === 'length') {
            // JS strings count UTF-16 code units, whereas for-of yields code points.
            $length = 0;
            foreach (self::iterate($value) as $character) { $length += strlen($character) > 3 ? 2 : 1; }
            return $length;
        }
        if (is_string($value) && (is_int($key) || preg_match('/^[0-9]+$/D', $key))) {
            $index = (int) $key;
            if ((string) $index !== (string) $key || $index < 0) { return UndefinedValue::Value; }
            $units = mb_convert_encoding($value, 'UTF-16LE', 'UTF-8');
            if ($index >= strlen($units) / 2) { return UndefinedValue::Value; }
            $unit = substr($units, $index * 2, 2);
            $code = unpack('v', $unit)[1];
            if ($code >= 0xd800 && $code <= 0xdfff) { throw new \TypeError('Isolated UTF-16 surrogate requires a JS string adapter'); }
            return mb_convert_encoding($unit, 'UTF-8', 'UTF-16LE');
        }
        if (!is_object($value)) { return UndefinedValue::Value; }
        return property_exists($value, (string) $key) ? $value->{$key} : UndefinedValue::Value;
    }

    public static function set(object $object, string|int|float $key, mixed $value): mixed
    {
        $key = self::string($key);
        if ($object instanceof JsArray) { return $object->set($key, $value); }
        if ($object instanceof MutableJsObject) { return $object->setJsProperty($key, $value); }
        if (!$object instanceof \stdClass && !property_exists($object, $key)) { throw new \TypeError('Property write requires an explicit runtime mapping: ' . $key); }
        return $object->{$key} = $value;
    }

    public static function assign(\stdClass $target, mixed ...$sources): \stdClass
    {
        foreach ($sources as $source) {
            if ($source === null || $source === UndefinedValue::Value) { continue; }
            if (!is_array($source) && !$source instanceof \stdClass) { throw new \TypeError('Object.assign source needs an explicit adapter'); }
            foreach ($source as $key => $value) { $target->{$key} = $value; }
        }
        return $target;
    }

    public static function numeric(string $operator, int|float $left, int|float $right): int|float|bool
    {
        return match ($operator) {
            '-' => $left - $right, '*' => $left * $right, '/' => fdiv($left, $right),
            '<' => $left < $right, '<=' => $left <= $right, '>' => $left > $right, '>=' => $left >= $right,
            default => throw new \LogicException('Unsupported numeric operator'),
        };
    }

    /** Unary plus over primitive values; object-to-primitive hooks need a host adapter. */
    public static function number(mixed $value): int|float
    {
        if (is_int($value) || is_float($value)) { return $value; }
        if ($value === null) { return 0; }
        if ($value === UndefinedValue::Value) { return NAN; }
        if (is_bool($value)) { return (int) $value; }
        if (!is_string($value)) { throw new TypeError('Numeric conversion requires a primitive value'); }
        $space = '[\x{0009}-\x{000d}\x{0020}\x{00a0}\x{1680}\x{2000}-\x{200a}\x{2028}\x{2029}\x{202f}\x{205f}\x{3000}\x{feff}]';
        $value = preg_replace('/\A'.$space.'+|'.$space.'+\z/u', '', $value);
        if ($value === null) { throw new TypeError('Invalid UTF-8 numeric string'); }
        if ($value === '') { return 0; }
        if (in_array($value, ['Infinity','+Infinity','-Infinity'], true)) { return $value[0] === '-' ? -INF : INF; }
        if (preg_match('/\A0([xob])([0-9a-f]+)\z/iD', $value, $match)) {
            $base = ['x'=>16,'o'=>8,'b'=>2][strtolower($match[1])];
            $bits = '';
            foreach (str_split(strtolower($match[2])) as $digit) {
                $number = strpos('0123456789abcdef', $digit);
                if ($number >= $base) { return NAN; }
                $bits .= str_pad(decbin($number), $base === 16 ? 4 : ($base === 8 ? 3 : 1), '0', STR_PAD_LEFT);
            }
            $bits = ltrim($bits, '0');
            if ($bits === '') { return 0; }
            if (strlen($bits) <= 53) { return (float) bindec($bits); }
            $significand = (int) bindec(substr($bits, 0, 53));
            if ($bits[53] === '1' && (str_contains(substr($bits, 54), '1') || $significand % 2)) { ++$significand; }
            return $significand * (2.0 ** (strlen($bits) - 53));
        }
        return preg_match('/\A[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\z/D', $value) ? (float) $value : NAN;
    }

    public static function strictEqual(mixed $left, mixed $right): bool
    {
        if ((is_int($left) || is_float($left)) && (is_int($right) || is_float($right))) { return (float) $left === (float) $right; }
        if (is_array($left) && is_array($right)) { throw new \TypeError('Array identity requires JsArray'); }
        return $left === $right;
    }

    public static function round(int|float $value): int|float
    {
        if (!is_finite((float) $value) || $value == 0) { return $value; }
        $floor = floor($value);
        $result = $value - $floor < 0.5 ? $floor : $floor + 1;
        return $result == 0 && $value < 0 ? -0.0 : $result;
    }

    public static function min(int|float ...$values): int|float { return self::extreme(false, $values); }
    public static function max(int|float ...$values): int|float { return self::extreme(true, $values); }
    private static function extreme(bool $maximum, array $values): int|float
    {
        $result = $maximum ? -INF : INF;
        foreach ($values as $value) {
            if (is_nan((float) $value)) { return NAN; }
            if ($maximum ? $value > $result : $value < $result) { $result = $value; }
            elseif ($value == 0 && $result == 0 && ($maximum ? fdiv(1, $value) > fdiv(1, $result) : fdiv(1, $value) < fdiv(1, $result))) { $result = $value; }
        }
        return $result;
    }

    public static function optionalGet(mixed $target, string|int $key): mixed
    {
        return $target === null || $target === UndefinedValue::Value ? UndefinedValue::Value : self::get($target, $key);
    }

    public static function optionalInvoke(mixed $target, string $method, \Closure $arguments): mixed
    {
        return $target === null || $target === UndefinedValue::Value ? UndefinedValue::Value : self::invoke($target, $method, $arguments());
    }

    public static function optionalCall(mixed $callback, \Closure $arguments): mixed
    {
        return $callback === null || $callback === UndefinedValue::Value
            ? UndefinedValue::Value : self::functionValue($callback)(...$arguments());
    }

    public static function bindMethod(object $target, string $method): \Closure
    {
        return $target->{$method}(...);
    }

    /** Capture the dispose method when entering a source using declaration. */
    public static function disposer(mixed $resource): ?\Closure
    {
        if ($resource === null || $resource === UndefinedValue::Value) { return null; }
        return self::functionValue(self::get($resource, WellKnownSymbol::Dispose));
    }

    public static function disposeUsing(?\Closure $dispose, ?\Throwable $bodyError): void
    {
        if ($dispose === null) { return; }
        try { self::discard($dispose()); }
        catch (\Throwable $error) {
            if ($bodyError !== null) {
                throw new \Nesk\Puphpeteer\Native\Generated\Upstream\SuppressedErrorPolyfill(
                    self::catchValue($error), self::catchValue($bodyError), 'An error was suppressed during disposal.');
            }
            throw $error;
        }
    }

    /** Mutable records for the selected generated DOM geometry algorithms. */
    public static function browserResult(Future $result): Future
    {
        return $result->map(self::browserValue(...));
    }

    private static function browserValue(mixed $value): mixed
    {
        if (!is_array($value)) { return $value; }
        $mapped = array_map(self::browserValue(...), $value);
        return array_is_list($value) ? new JsArray($mapped) : self::object($mapped);
    }

    /** JSHandle's synchronous dispose symbol starts asynchronous disposal. */
    public static function disposeHandle(mixed $handle): void
    {
        if ($handle === null || $handle === false || $handle === UndefinedValue::Value) { return; }
        if (!$handle instanceof \Nesk\Puphpeteer\Native\JSHandle) { throw new \TypeError('Resource is not a JSHandle'); }
        $handle->disposeResource();
    }

    public static function typeOf(mixed $value): string
    {
        if ($value instanceof \Nesk\Puphpeteer\Native\BigInt) { return 'bigint'; }
        return match (true) {
            $value === UndefinedValue::Value => 'undefined', is_bool($value) => 'boolean',
            is_string($value) => 'string', is_int($value) || is_float($value) => 'number',
            $value instanceof \Closure => 'function', default => 'object',
        };
    }

    /** JS async functions run synchronously until the first await. */
    public static function async(\Closure $operation): Future
    {
        $deferred = new \Amp\DeferredFuture();
        $fiber = new \Fiber(static function () use ($operation, $deferred): void {
            try {
                $value = $operation();
                $deferred->complete($value instanceof Future ? $value->await() : $value);
            } catch (\Throwable $error) { $deferred->error($error); }
        });
        $fiber->start();
        return $deferred->getFuture();
    }

    /** Promise capability used by generated Deferred; executor runs immediately. */
    public static function promise(\Closure $executor): Future
    {
        $deferred = new \Amp\DeferredFuture(); $future = $deferred->getFuture(); $settled = false;
        $reject = static function (mixed $error) use ($deferred, &$settled): void {
            if ($settled) { return; } $settled = true;
            $deferred->error($error instanceof \Throwable ? $error : new \RuntimeException(self::string($error)));
        };
        $resolve = static function (mixed $value = UndefinedValue::Value) use ($deferred, $future, &$settled): void {
            if ($settled) { return; } $settled = true;
            if ($value === $future) { $deferred->error(new \TypeError('Chaining cycle detected for promise')); return; }
            if ($value instanceof Future) { $value->map($deferred->complete(...))->catch($deferred->error(...))->ignore(); }
            else { $deferred->complete($value); }
        };
        try { $executor($resolve, $reject); } catch (\Throwable $error) { $reject($error); }
        return $future;
    }

    public static function setTimeout(\Closure $callback, int|float $milliseconds): string
    {
        return \Revolt\EventLoop::delay(max(0, $milliseconds) / 1000, static function () use ($callback): void { self::discard(self::call($callback, [])); });
    }
    public static function clearTimeout(mixed $timer): void
    {
        if ($timer !== UndefinedValue::Value && $timer !== null) { \Revolt\EventLoop::cancel($timer); }
    }
    public static function race(iterable $values): Future
    {
        $deferred = new \Amp\DeferredFuture();
        foreach ($values as $value) {
            self::resolve($value)->map(static function ($result) use ($deferred): void { if (!$deferred->isComplete()) { $deferred->complete($result); } })
                ->catch(static function (\Throwable $error) use ($deferred): void { if (!$deferred->isComplete()) { $deferred->error($error); } })->ignore();
        }
        return $deferred->getFuture();
    }

    /** Promise.all: preserve input order, fail promptly, keep other operations alive. */
    public static function all(iterable $values): Future
    {
        $values = array_values(iterator_to_array((static function () use ($values) { yield from $values; })()));
        if ($values === []) { return Future::complete(new JsArray()); }
        $deferred = new \Amp\DeferredFuture();
        $remaining = count($values);
        $results = [];
        foreach ($values as $index => $value) {
            ($value instanceof Future ? $value : Future::complete($value))
                ->map(static function ($result) use ($index, &$remaining, &$results, $deferred): void {
                    $results[$index] = $result;
                    if (--$remaining === 0 && !$deferred->isComplete()) { ksort($results); $deferred->complete(new JsArray($results)); }
                })->catch(static function (\Throwable $error) use ($deferred): void {
                    if (!$deferred->isComplete()) { $deferred->error($error); }
                })->ignore();
        }
        return $deferred->getFuture();
    }

    public static function eventOnce(\Nesk\Puphpeteer\Native\Session $session, string $event, string $property): Future
    {
        return $session->waitFor($event)->map(static fn ($params) => self::get($params, $property));
    }

    public static function iterate(mixed $value): iterable
    {
        if (is_string($value)) {
            $characters = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY);
            if ($characters === false) { throw new \InvalidArgumentException('Invalid UTF-8 string'); }
            return $characters;
        }
        if (is_array($value) || $value instanceof \Traversable) { return $value; }
        throw new \TypeError('Value is not iterable');
    }

    public static function bitwise(string $operator, int $left, int $right): int
    {
        $result = match ($operator) { '&' => $left & $right, '|' => $left | $right, default => throw new \LogicException('Unsupported bitwise operator') };
        $result &= 0xffffffff;
        return $result >= 0x80000000 ? $result - 0x100000000 : $result;
    }

    public static function bitNot(int $value): int { return self::bitwise('&', ~$value, 0xffffffff); }

    public static function defaultValue(mixed $value, \Closure $fallback): mixed
    {
        return $value === UndefinedValue::Value ? $fallback() : $value;
    }

    public static function delay(int|float $milliseconds): Future
    {
        return \Amp\async(static function () use ($milliseconds) {
            // Node timers normalize out-of-range delays to 1 ms and truncate fractions.
            $delay = $milliseconds >= 1 && $milliseconds <= 2147483647 ? (int) $milliseconds : 1;
            \Amp\delay($delay / 1000);
            return UndefinedValue::Value;
        });
    }

    public static function cloneValue(mixed $value): mixed
    {
        if (is_array($value)) { return array_map(self::cloneValue(...), $value); }
        if ($value instanceof \stdClass) { return (object) array_map(self::cloneValue(...), get_object_vars($value)); }
        if (is_object($value) && $value !== UndefinedValue::Value) { throw new \InvalidArgumentException('Unsupported structuredClone value'); }
        return $value;
    }

    public static function object(array $properties): object
    {
        // Preserve absent vs null until the protocol serialization boundary.
        return (object) $properties;
    }

    public static function truthy(mixed $value): bool
    {
        if ($value === UndefinedValue::Value || $value === null || $value === false) {
            return false;
        }
        if (is_string($value)) {
            return $value !== ''; // JavaScript's "0" is truthy.
        }
        if (is_int($value) || is_float($value)) {
            return $value != 0 && !is_nan((float) $value);
        }
        return true; // Including empty arrays and objects.
    }

    public static function logicalAnd(mixed $value, \Closure $fallback): mixed
    {
        return self::truthy($value) ? $fallback() : $value;
    }

    public static function logicalOr(mixed $value, \Closure $fallback): mixed
    {
        return self::truthy($value) ? $value : $fallback();
    }

    public static function add(mixed $left, mixed $right): mixed
    {
        if (is_string($left) || is_string($right)) {
            return self::string($left) . self::string($right);
        }
        return $left + $right;
    }

    public static function string(mixed $value): string
    {
        return match (true) {
            $value === UndefinedValue::Value => 'undefined',
            $value === null => 'null',
            $value === true => 'true',
            $value === false => 'false',
            is_float($value) && is_nan($value) => 'NaN',
            $value === INF => 'Infinity',
            $value === -INF => '-Infinity',
            is_float($value) && $value === 0.0 => '0',
            $value instanceof \Stringable => (string) $value,
            is_object($value) => '[object Object]',
            is_array($value) => implode(',', array_map(static fn ($item) => $item === null || $item === UndefinedValue::Value ? '' : self::string($item), $value)),
            default => (string) $value,
        };
    }

    public static function coalesce(mixed $value, \Closure $fallback): mixed
    {
        return $value === null || $value === UndefinedValue::Value ? $fallback() : $value;
    }

    public static function await(mixed $value): mixed
    {
        return ($value instanceof Future ? $value : Future::complete($value))->await();
    }

    public static function deleteProperty(mixed &$object, string|int $key): bool
    {
        if (is_array($object)) { unset($object[$key]); return true; }
        if ($object instanceof \stdClass) { unset($object->{$key}); return true; }
        throw new \TypeError('Unsupported delete target');
    }

    public static function stringStartsWith(mixed $value, mixed $search): bool
    {
        if ($value === null || $value === UndefinedValue::Value) { throw new \TypeError('String.prototype.startsWith called on null or undefined'); }
        return str_starts_with(self::string($value), self::string($search));
    }

    /** String-search replacement with JavaScript substitution tokens (no capture groups). */
    private static function replaceString(string $value, string $search, string $replacement): string
    {
        $offset = strpos($value, $search);
        if ($offset === false) { return $value; }
        $before = substr($value, 0, $offset);
        $after = substr($value, $offset + strlen($search));
        $replacement = preg_replace_callback('/\\$(\\$|&|`|\')/', static fn (array $match): string => match ($match[1]) {
            '$' => '$', '&' => $search, '`' => $before, "'" => $after,
        }, $replacement);
        return $before . $replacement . $after;
    }

    public static function optionalMap(mixed $value, \Closure $continuation): mixed
    {
        return $value === null || $value === UndefinedValue::Value ? UndefinedValue::Value : $continuation($value);
    }

    private static function sliceString(string $value, int $start): string
    {
        $utf16 = mb_convert_encoding($value, 'UTF-16LE', 'UTF-8');
        $length = intdiv(strlen($utf16), 2);
        $offset = $start < 0 ? max(0, $length + $start) : min($start, $length);
        $slice = substr($utf16, $offset * 2);
        $text = mb_convert_encoding($slice, 'UTF-8', 'UTF-16LE');
        if (mb_convert_encoding($text, 'UTF-16LE', 'UTF-8') !== $slice) { throw new \TypeError('String slice would produce an isolated surrogate'); }
        return $text;
    }

    public static function invoke(mixed $object, string $method, array $arguments): mixed
    {
        if (is_array($object) && array_is_list($object) && $method === 'slice' && $arguments === []) { return $object; }
        if ($object instanceof \stdClass && isset($object->{$method}) && $object->{$method} instanceof \Closure) { return ($object->{$method})(...$arguments); }
        if ($object instanceof Future && $method === 'then') { return $object->map(static fn ($value) => self::await($arguments[0]($value))); }
        if ($object instanceof Future && $method === 'catch') { return $object->catch(static fn (\Throwable $error) => self::await($arguments[0](self::catchValue($error)))); }
        if (is_array($object) && array_is_list($object) && in_array($method, ['map', 'reduce', 'filter', 'some'], true)) { return (new JsArray($object))->{$method}(...$arguments); }
        if (is_string($object) && $method === 'substring' && count($arguments) === 1 && is_int($arguments[0])) { return self::sliceString($object, max(0, $arguments[0])); }
        if (is_string($object) && $method === 'slice' && count($arguments) === 1 && is_int($arguments[0])) { return self::sliceString($object, $arguments[0]); }
        if (is_string($object) && $method === 'startsWith' && count($arguments) === 1) { return str_starts_with($object, self::string($arguments[0])); }
        if (is_string($object) && $method === 'endsWith' && count($arguments) === 1) { return str_ends_with($object, self::string($arguments[0])); }
        if (is_string($object) && $method === 'includes' && count($arguments) === 1) { return str_contains($object, self::string($arguments[0])); }
        if (is_string($object) && $method === 'toLowerCase' && $arguments === []) { return mb_strtolower($object, 'UTF-8'); }
        if (is_string($object) && $method === 'toUpperCase' && $arguments === []) { return mb_strtoupper($object, 'UTF-8'); }
        if (is_string($object) && $method === 'replace' && count($arguments) === 2 && is_string($arguments[0]) && is_string($arguments[1])) { return self::replaceString($object, $arguments[0], $arguments[1]); }
        if (is_string($object) && $method === 'replaceAll' && count($arguments) === 2 && $arguments[0] instanceof JsRegExp && $arguments[1] instanceof \Closure) { return $arguments[0]->replaceAll($object, $arguments[1]); }
        if (is_string($object) && $method === 'replace' && count($arguments) === 2 && $arguments[0] instanceof JsRegExp && is_string($arguments[1])) { return $arguments[0]->replace($object, $arguments[1]); }
        if (is_string($object) && $method === 'split' && count($arguments) >= 1 && count($arguments) <= 2 && is_string($arguments[0]) && $arguments[0] !== '') {
            $parts = explode($arguments[0], $object);
            return new JsArray(count($arguments) === 1 ? $parts : array_slice($parts, 0, ((int) $arguments[1]) & 0xffffffff));
        }
        if (is_string($object) && $method === 'match' && count($arguments) === 1 && $arguments[0] instanceof JsRegExp) { return $arguments[0]->match($object); }
        return $object->{$method}(...$arguments);
    }

    public static function isArray(mixed $value): bool { return $value instanceof JsArray || is_array($value) && array_is_list($value); }
    public static function isString(mixed $value): bool { return is_string($value); }
    public static function entries(array|\stdClass $value): JsArray
    {
        $entries = [];
        foreach ($value as $key => $item) { $entries[] = new JsArray([(string) $key, $item]); }
        return new JsArray($entries);
    }
    public static function keys(array|\stdClass $value): JsArray { return new JsArray(array_map('strval', array_keys((array) $value))); }
    public static function hasProperty(mixed $value, string|int $key): bool
    {
        if ($value instanceof JsArray) { return $value->has((string) $key); }
        if ($value instanceof \Throwable) { return in_array($key, ['name','message','stack'], true) || property_exists($value, (string) $key); }
        if (is_array($value)) { return array_key_exists($key, $value); }
        if (is_object($value)) { return property_exists($value, (string) $key); }
        throw new TypeError('Right-hand side of in is not an object');
    }
    public static function objectIs(mixed $left, mixed $right): bool
    {
        if (is_float($left) && is_nan($left) && is_float($right) && is_nan($right)) { return true; }
        if ((is_int($left) || is_float($left)) && (is_int($right) || is_float($right)) && $left == 0 && $right == 0) { return fdiv(1, $left) === fdiv(1, $right); }
        return self::strictEqual($left, $right);
    }
    public static function resolve(mixed $value = UndefinedValue::Value): Future { return $value instanceof Future ? $value : Future::complete($value); }
    public static function bytesToBase64(\Nesk\Puphpeteer\Native\ByteArray $value): string { return base64_encode($value->bytes); }
    public static function stringToBase64(string $value): string { return self::bytesToBase64((new TextEncoder())->encode($value)); }
    /** The Node branch of the hash-guarded upstream encoding helper. */
    public static function stringToTypedArray(string $value, bool $base64Encoded = false): \Nesk\Puphpeteer\Native\ByteArray
    {
        if (!$base64Encoded) { return (new TextEncoder())->encode($value); }
        return new \Nesk\Puphpeteer\Native\ByteArray(base64_decode(strtr($value, '-_', '+/')));
    }
    /** JSON objects map to associative PHP arrays at this API boundary. */
    public static function parseJson(string $value): mixed
    {
        return self::decodeJson($value, true);
    }
    /** JSON.parse representation for source execution: objects and arrays stay distinct. */
    public static function parseJsonValue(mixed $value): mixed
    {
        return self::jsonObjects(self::decodeJson(self::string($value), false));
    }
    private static function jsonObjects(mixed $value): mixed
    {
        if (is_array($value)) { return new JsArray(array_map(self::jsonObjects(...), $value)); }
        if ($value instanceof \stdClass) { foreach (get_object_vars($value) as $key => $entry) { $value->{$key} = self::jsonObjects($entry); } }
        return $value;
    }
    private static function decodeJson(string $value, bool $associative): mixed
    {
        $parsed = json_decode($value, $associative, 512, JSON_THROW_ON_ERROR);
        // JSON.parse produces IEEE-754 numbers. PHP otherwise preserves 64-bit
        // integers that JavaScript has already rounded, and loses integer -0.
        $normalized = preg_replace_callback('/"(?:\\\\.|[^"\\\\])*"|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/s', static function (array $match): string {
            $token = $match[0];
            if ($token[0] === '"') { return $token; }
            if ($token === '-0') { return '-0.0'; }
            if (strpbrk($token, '.eE') === false && strlen(ltrim($token, '-')) >= 16 && is_finite((float) $token)) { return sprintf('%.0f', (float) $token); }
            return $token;
        }, $value);
        return $normalized === $value ? $parsed : json_decode($normalized, $associative, 512, JSON_THROW_ON_ERROR);
    }
    public static function arrayFrom(iterable $value): JsArray { return new JsArray(is_array($value) ? array_values($value) : iterator_to_array($value, false)); }
    public static function isErrorLike(mixed $value): bool { return $value instanceof \Throwable; }
    /** A non-Error JS throw is transported by JavaScriptException, not an Error instance. */
    public static function isErrorInstance(mixed $value): bool
    {
        return $value instanceof \Throwable && !$value instanceof \Nesk\Puphpeteer\Native\JavaScriptException;
    }
    /** Host boundary for Puppeteer's optional puppeteer:error debug sink. */
    public static function setDebugLogger(?\Closure $logger): void { self::$debugLogger = $logger; }
    public static function debugError(mixed $error): UndefinedValue
    {
        if (self::$debugLogger !== null) { (self::$debugLogger)('puppeteer:error', $error); }
        return UndefinedValue::Value;
    }
    public static function discard(mixed $value): UndefinedValue
    {
        if ($value instanceof Future) { $value->ignore(); }
        return UndefinedValue::Value;
    }

    /** Mirrors upstream's WeakMap decorator: cache before invocation, including failures. */
    public static function onceForArguments(string $method, array $arguments, \Closure $operation): mixed
    {
        static $caches = [];
        static $depths = [];
        $depths[$method] ??= count($arguments);
        if ($depths[$method] !== count($arguments)) { throw new \RuntimeException('Memoized method was called with the wrong number of arguments'); }
        $cache = $caches[$method] ??= new \WeakMap();
        $fresh = false;
        foreach ($arguments as $argument) {
            if (!is_object($argument)) { throw new \TypeError('Invalid value used as weak map key'); }
            if (!isset($cache[$argument])) { $fresh = true; $cache[$argument] = new \WeakMap(); }
            $cache = $cache[$argument];
        }
        return $fresh ? $operation() : UndefinedValue::Value;
    }

    public static function assert(mixed $condition, string $message): void
    {
        if (!self::truthy($condition)) {
            throw new \RuntimeException($message);
        }
    }

    /** Hoisted function bindings are assigned before any source statements execute. */
    public static function functionValue(mixed $value): \Closure
    {
        if (!$value instanceof \Closure) { throw new TypeError('Value is not a function'); }
        return $value;
    }

    public static function throwValue(mixed $value): never
    {
        throw $value instanceof \Throwable ? $value : new \Nesk\Puphpeteer\Native\JavaScriptException($value);
    }
    public static function catchValue(\Throwable $error): mixed
    {
        return $error instanceof \Nesk\Puphpeteer\Native\JavaScriptException ? $error->value : $error;
    }

    public static function toWire(mixed $value): mixed
    {
        return self::wireValue($value, new \SplObjectStorage(), [], 0);
    }

    private static function wireValue(mixed $value, \SplObjectStorage $objects, array $references, int $depth): mixed
    {
        if ($depth > 512) { throw new TypeError('CDP JSON value exceeds maximum nesting depth'); }
        if ($value instanceof \Nesk\Puphpeteer\Native\BigInt) { throw new TypeError('Do not know how to serialize a BigInt'); }
        if ($value instanceof \Nesk\Puphpeteer\Native\JsFunction || $value instanceof \Closure) { return UndefinedValue::Value; }
        if (is_float($value) && !is_finite($value)) { return null; }
        if ($value instanceof JsArray || $value instanceof \stdClass) {
            if ($objects->offsetExists($value)) { throw new TypeError('Converting circular structure to JSON'); }
            $objects->offsetSet($value);
            try {
                if ($value instanceof JsArray) {
                    $result=[];
                    foreach ($value as $item) {
                        $converted=$item===UndefinedValue::Value ? UndefinedValue::Value : self::wireValue($item,$objects,$references,$depth+1);
                        $result[]=$converted===UndefinedValue::Value ? null : $converted;
                    }
                    return $result;
                }
                $result=new \stdClass();
                foreach (get_object_vars($value) as $key=>$item) {
                    if ($item===UndefinedValue::Value) { continue; }
                    $converted=self::wireValue($item,$objects,$references,$depth+1);
                    if ($converted!==UndefinedValue::Value) { $result->{$key}=$converted; }
                }
                return $result;
            } finally { $objects->offsetUnset($value); }
        }
        if (is_array($value)) {
            $list=array_is_list($value);$result=$list?[]:new \stdClass();
            foreach ($value as $key=>$item) {
                $branch=$references;$reference=\ReflectionReference::fromArrayElement($value,$key);
                if ($reference!==null) {
                    $id=bin2hex($reference->getId());
                    if (isset($branch[$id])) { throw new TypeError('Converting circular structure to JSON'); }
                    $branch[$id]=true;
                }
                $converted=$item===UndefinedValue::Value ? UndefinedValue::Value : self::wireValue($item,$objects,$branch,$depth+1);
                if ($list) { $result[]=$converted===UndefinedValue::Value ? null : $converted; }
                elseif ($converted!==UndefinedValue::Value) { $result->{$key}=$converted; }
            }
            return $result;
        }
        if ($value === UndefinedValue::Value || is_object($value)) {
            throw new \InvalidArgumentException('Value cannot be serialized as a CDP argument');
        }
        return $value;
    }
}
