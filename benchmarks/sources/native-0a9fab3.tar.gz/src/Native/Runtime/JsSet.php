<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Ordered Set with object identity and SameValueZero primitive equality. */
final class JsSet implements \IteratorAggregate, JsObject
{
    private array $values = [];
    public function __construct(iterable $values = []) { foreach ($values as $value) { $this->add($value); } }
    public function getJsProperty(string $name): mixed { return $name === 'size' ? count($this->values) : UndefinedValue::Value; }
    public function clear(): void { $this->values = []; }
    public function getIterator(): \Traversable { yield from $this->values; }
    private function index(mixed $value): ?int
    {
        foreach ($this->values as $index => $entry) {
            if (Js::strictEqual($entry, $value) || is_float($entry) && is_nan($entry) && is_float($value) && is_nan($value)) { return $index; }
        }
        return null;
    }
    public function has(mixed $value): bool { return $this->index($value) !== null; }
    public function add(mixed $value): self { if (!$this->has($value)) { $this->values[] = $value; } return $this; }
    public function delete(mixed $value): bool
    {
        $index = $this->index($value);
        if ($index === null) { return false; }
        unset($this->values[$index]);
        return true;
    }
}
