<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Map for the source's string-valued CDP request identifiers. */
final class StringMap
{
    private array $values = [];
    public function has(string $key): bool { return array_key_exists($key, $this->values); }
    public function get(string $key): mixed { return $this->has($key) ? $this->values[$key] : UndefinedValue::Value; }
    public function set(string $key, mixed $value): self { $this->values[$key] = $value; return $this; }
    public function delete(string $key): bool { $has = $this->has($key); unset($this->values[$key]); return $has; }
    public function values(): JsArray { return new JsArray(array_values($this->values)); }
}
