<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Nesk\Puphpeteer\Native\Session;

/** Maps callback identity to Session observer tokens and preserves mutable CDP objects. */
final class SessionEmitterAdapter
{
    private array $listeners = [];
    public function __construct(private Session $session) {}

    public function on(string $event, \Closure $handler): void
    {
        $id = $this->session->observeSource($event, function (object $value) use ($handler): void {
            $result = $handler($value);
            if ($result instanceof \Amp\Future) { $this->session->track($result); }
        });
        $this->listeners[$event][] = [$handler, $id];
    }

    public function off(string $event, \Closure $handler): void
    {
        foreach ($this->listeners[$event] ?? [] as $index => [$registered, $id]) {
            if ($registered !== $handler) { continue; }
            $this->session->off($event, $id);
            unset($this->listeners[$event][$index]);
            if ($this->listeners[$event] === []) { unset($this->listeners[$event]); }
            return;
        }
    }
}
