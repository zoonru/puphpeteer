<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Text enters the PHP API as UTF-8; binary data uses ByteArray. */
final class TextEncoder
{
    public function encode(string $value): \Nesk\Puphpeteer\Native\ByteArray
    {
        if (!mb_check_encoding($value, 'UTF-8')) { throw new \InvalidArgumentException('Expected UTF-8 text; use ByteArray for binary data'); }
        return new \Nesk\Puphpeteer\Native\ByteArray($value);
    }
}
