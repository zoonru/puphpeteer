<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;
use Amp\{Cancellation,Future};
use Nesk\Puphpeteer\Native\{ExecutionContext,ProtocolException,Session};

/** Per-call cancellation and CDP payload boundary for the generated evaluator. */
final class EvaluationClient
{
    public function __construct(private Session $session, private ExecutionContext $context, private ?Cancellation $cancellation) {}
    public function send(string $method, array|object $params): Future
    {
        return $this->session->send($method,$params,$this->cancellation)->map(static function(array $response):array {
            if(isset($response['exceptionDetails']['stackTrace']['callFrames'])){
                $response['exceptionDetails']['stackTrace']['callFrames']=new JsArray($response['exceptionDetails']['stackTrace']['callFrames']);
            }
            return $response;
        })->catch(function(\Throwable $error):never {
            if($error instanceof ProtocolException&&in_array($error->error['message']??'',['Cannot find context with specified id','Cannot find context with specified unique id','Inspected target navigated or closed'],true)){$this->context->invalidate();}
            throw $error;
        });
    }
}
