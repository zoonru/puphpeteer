<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Identity-preserving dense arrays for generated Input state and transactions. */
final class JsArray implements \IteratorAggregate, \JsonSerializable
{
    public function __construct(private array $items = []) { $this->items = array_values($items); }
    public function getIterator(): \Traversable { yield from $this->items; }
    public function jsonSerialize(): mixed { return Js::toWire($this->items); }
    public function get(string|int $key): mixed { return $key === 'length' ? count($this->items) : (array_key_exists($key, $this->items) ? $this->items[$key] : UndefinedValue::Value); }
    public function has(string $key): bool { return $key === 'length' || preg_match('/^(0|[1-9][0-9]*)$/D', $key) && array_key_exists($key, $this->items); }
    public function set(string $key, mixed $value): mixed
    {
        if ($this->has($key) && $key !== 'length') { return $this->items[$key] = $value; }
        if ($key !== 'length' || !is_int($value) || $value < 0 || $value > count($this->items)) { throw new \TypeError('Unsupported array write'); }
        $this->items = array_slice($this->items, 0, $value);
        return $value;
    }
    public function join(string $separator = ','): string
    {
        return implode($separator, array_map(static fn ($value) => $value === null || $value === UndefinedValue::Value ? '' : Js::string($value), $this->items));
    }
    public function push(mixed ...$values): int { array_push($this->items, ...$values); return count($this->items); }
    public function indexOf(mixed $value): int { $index = array_search($value, $this->items, true); return $index === false ? -1 : $index; }
    public function lastIndexOf(mixed $value): int { for ($index = count($this->items) - 1; $index >= 0; --$index) { if (Js::strictEqual($this->items[$index], $value)) { return $index; } } return -1; }
    public function slice(int $start = 0): self { return new self(array_slice($this->items, $start)); }
    public function splice(int $start, int $deleteCount): self { return new self(array_splice($this->items, $start, max(0, $deleteCount))); }
    public function reverse(): self { $this->items = array_reverse($this->items); return $this; }
    public function pop(): mixed { return $this->items === [] ? UndefinedValue::Value : array_pop($this->items); }
    public function sort(\Closure $comparator): self
    {
        // PHP 8 sorting is stable; preserve fractional comparisons instead of casting to int.
        $items = $this->items;
        usort($items, static function ($left, $right) use ($comparator): int {
            $order = $comparator($left, $right);
            if (!is_int($order) && !is_float($order)) { throw new \TypeError('Array comparator must return a number'); }
            return is_nan((float) $order) || $order == 0 ? 0 : ($order < 0 ? -1 : 1);
        });
        $this->items = $items;
        return $this;
    }
    public function unshift(mixed ...$values): int { array_unshift($this->items, ...$values); return count($this->items); }
    public function shift(): mixed { return $this->items === [] ? UndefinedValue::Value : array_shift($this->items); }
    public function map(\Closure $callback): self
    {
        $result = [];
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) { $result[] = $callback($this->get($index), $index, $this); }
        return new self($result);
    }
    public function filter(\Closure $callback): self
    {
        $result = [];
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) {
            if (!array_key_exists($index, $this->items)) { continue; }
            $value = $this->items[$index];
            if (Js::truthy($callback($value, $index, $this))) { $result[] = $value; }
        }
        return new self($result);
    }
    public function some(\Closure $callback): bool
    {
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) {
            if (array_key_exists($index, $this->items) && Js::truthy($callback($this->items[$index], $index, $this))) { return true; }
        }
        return false;
    }
    public function reduce(\Closure $callback, mixed $initial): mixed
    {
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) { $initial = $callback($initial, $this->get($index), $index, $this); }
        return $initial;
    }
    public function find(\Closure $predicate): mixed
    {
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) {
            $value = $this->get($index);
            if (Js::truthy($predicate($value, $index, $this))) { return $value; }
        }
        return UndefinedValue::Value;
    }
    public function forEach(\Closure $callback): void
    {
        $length = count($this->items);
        for ($index = 0; $index < $length; ++$index) {
            if (array_key_exists($index, $this->items)) { $callback($this->items[$index], $index, $this); }
        }
    }
}
