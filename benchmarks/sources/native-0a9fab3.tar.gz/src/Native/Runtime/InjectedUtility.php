<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

use Nesk\Puphpeteer\Native\{AriaQueryHandler, Binding, ElementHandle};
use Nesk\Puphpeteer\Native\Generated\Upstream\ScriptInjector;

/** Module-level dependencies of ExecutionContext's generated utility getter. */
final class InjectedUtility
{
    private static ?ScriptInjector $injector = null;
    private static ?Binding $queryOne = null;
    private static ?Binding $queryAll = null;

    public static function injector(): ScriptInjector
    {
        return self::$injector ??= new ScriptInjector();
    }

    public static function queryOneBinding(): Binding
    {
        return self::$queryOne ??= new Binding('__ariaQuerySelector',
            static fn (ElementHandle $root, string $selector) => AriaQueryHandler::query($root, $selector, false), 'internal');
    }

    public static function queryAllBinding(): Binding
    {
        return self::$queryAll ??= new Binding('__ariaQuerySelectorAll',
            static fn (ElementHandle $root, string $selector) => AriaQueryHandler::query($root, $selector, true), 'internal');
    }
}
