<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Computed symbol members of source object literals, distinct from string keys. */
final class SymbolObject implements JsSymbolObject
{
    private array $members = [];
    public function __construct(array $entries)
    {
        foreach ($entries as [$symbol, $value]) {
            if (!$symbol instanceof WellKnownSymbol) { throw new \TypeError('Expected a well-known symbol'); }
            $this->members[$symbol->name] = $value;
        }
    }
    public function getJsSymbol(WellKnownSymbol $symbol): mixed { return array_key_exists($symbol->name, $this->members) ? $this->members[$symbol->name] : UndefinedValue::Value; }
}
