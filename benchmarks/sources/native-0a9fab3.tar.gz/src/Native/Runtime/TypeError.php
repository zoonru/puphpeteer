<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** JavaScript TypeError with the mutable message required by upstream catch blocks. */
final class TypeError extends JsError
{
    public function __construct(mixed $message = UndefinedValue::Value)
    {
        parent::__construct($message);$this->name='TypeError';
    }
}
