<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Nesk\Puphpeteer\Native\Generated\Upstream\EventEmitter;
use Nesk\Puphpeteer\Native\Session;

/** Source EventEmitter composition over the native Session subscription API. */
final class TransportEventEmitter extends EventEmitter
{
    public function __construct(mixed $emitter = UndefinedValue::Value)
    {
        parent::__construct($emitter instanceof Session ? new SessionEmitterAdapter($emitter) : $emitter);
    }
}
