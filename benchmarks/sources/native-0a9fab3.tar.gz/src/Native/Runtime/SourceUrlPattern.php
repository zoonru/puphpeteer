<?php

declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Audited SOURCE_URL_REGEX, with ECMAScript whitespace and all four line terminators. */
final class SourceUrlPattern
{
    public function test(mixed $input): bool
    {
        $space = '\x{0009}-\x{000D}\x{0020}\x{00A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}\x{FEFF}';
        return preg_match('~(?:\A|(?<=[\r\n\x{2028}\x{2029}]))[\x20\t]*//[@#] sourceURL=['.$space.']{0,10}([^'.$space.']*?)['.$space.']{0,10}(?=\z|[\r\n\x{2028}\x{2029}])~u', Js::string($input)) === 1;
    }
}
