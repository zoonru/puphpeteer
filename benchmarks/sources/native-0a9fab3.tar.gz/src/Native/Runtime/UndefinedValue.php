<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

enum UndefinedValue
{
    case Value;
}
