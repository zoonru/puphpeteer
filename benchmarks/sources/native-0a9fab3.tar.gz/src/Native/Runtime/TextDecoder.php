<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Nesk\Puphpeteer\Native\ByteArray;

/** UTF-8 decoder for generated HTTPResponse.text(). */
final class TextDecoder
{
    private bool $fatal;
    private bool $ignoreBom;
    public function __construct(string $encoding = 'utf-8', mixed $options = UndefinedValue::Value)
    {
        if (!in_array(strtolower(trim($encoding)), ['utf-8','utf8'], true)) { throw new \TypeError('TextDecoder encoding requires an explicit adapter'); }
        $this->fatal = $options !== UndefinedValue::Value && Js::truthy(Js::get($options, 'fatal'));
        $this->ignoreBom = $options !== UndefinedValue::Value && Js::truthy(Js::get($options, 'ignoreBOM'));
    }
    public function decode(ByteArray $value): string
    {
        $bytes = $value->bytes;
        if (preg_match('//u', $bytes) !== 1) {
            if ($this->fatal) { throw new \TypeError('The encoded data was not valid for encoding utf-8'); }
            $bytes = json_decode(json_encode($bytes, JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR), true, 512, JSON_THROW_ON_ERROR);
        }
        return !$this->ignoreBom && str_starts_with($bytes, "\xEF\xBB\xBF") ? substr($bytes, 3) : $bytes;
    }
}
