<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

/** Mutable state shared by outer/inner subscription callbacks. */
final class FlattenState
{
    public int $active = 0;
    public bool $outerDone = false;
    public ?Subscriber $inner = null;
    public function completeMerge(Subscriber $destination): void
    {
        if ($this->outerDone && $this->active === 0) { $destination->complete(); }
    }
    public function completeSwitch(Subscriber $destination): void
    {
        if ($this->outerDone && $this->inner === null) { $destination->complete(); }
    }
}
