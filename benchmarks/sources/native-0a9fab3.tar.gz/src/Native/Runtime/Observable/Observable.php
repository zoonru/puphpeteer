<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

class Observable
{
    public function __construct(private \Closure $initialize) {}
    public function subscribe(mixed $observer): Subscription
    {
        if ($observer instanceof Subscriber) { $subscriber = $observer; }
        elseif ($observer instanceof ReplaySubject) { $subscriber = new Subscriber($observer->next(...), $observer->error(...), $observer->complete(...)); }
        else { $subscriber = new Subscriber($observer, static function (\Throwable $error): never { throw $error; }, static function (): void {}); }
        if (!$subscriber->closed) {
            try { $subscriber->add(($this->initialize)($subscriber)); }
            catch (\Throwable $error) { $subscriber->error($error); }
        }
        return $subscriber;
    }
    public function pipe(\Closure ...$operators): self
    {
        $result = $this;
        foreach ($operators as $operator) { $result = $operator($result); }
        return $result;
    }
}
