<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

use Amp\DeferredFuture;
use Amp\Future;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
use Revolt\EventLoop;

/** PHP host implementation of the RxJS operators used by generated source. */
final class Rx
{
    public static function never(): Observable { return new Observable(static function (): void {}); }
    public static function empty(): Observable { return self::of(); }
    public static function of(mixed ...$values): Observable
    {
        return new Observable(static function (Subscriber $subscriber) use ($values): void {
            foreach ($values as $value) { if ($subscriber->closed) { break; } $subscriber->next($value); }
            $subscriber->complete();
        });
    }
    public static function from(mixed $input): Observable
    {
        if ($input instanceof Observable) { return $input; }
        if ($input instanceof Future) {
            return new Observable(static function (Subscriber $subscriber) use ($input): void {
                $input->map(static function ($value) use ($subscriber): void {
                    $subscriber->next($value); $subscriber->complete();
                })->catch($subscriber->error(...))->ignore();
            });
        }
        if (is_iterable($input)) {
            return new Observable(static function (Subscriber $subscriber) use ($input): void {
                foreach ($input as $value) { $subscriber->next($value); if ($subscriber->closed) { break; } }
                $subscriber->complete();
            });
        }
        throw new \TypeError('Observable input must be an Amp Future, iterable, or Observable');
    }
    public static function first(): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source): void {
            $seen = false;
            $source->subscribe(self::child($destination, static function ($value) use ($destination, &$seen): void {
                if (!$seen) { $seen = true; $destination->next($value); $destination->complete(); }
            }, static function () use ($destination, &$seen): void {
                if (!$seen) { $destination->error(new EmptyError()); } else { $destination->complete(); }
            }));
        });
    }
    public static function timer(int|float $milliseconds): Observable
    {
        return new Observable(static function (Subscriber $subscriber) use ($milliseconds): \Closure {
            $timer = EventLoop::delay(max(0, $milliseconds) / 1000, static function () use ($subscriber): void { $subscriber->next(0); $subscriber->complete(); });
            return static fn () => EventLoop::cancel($timer);
        });
    }
    public static function firstValueFrom(Observable $source): Future
    {
        $deferred = new DeferredFuture(); $subscriber = null;
        $subscriber = new Subscriber(
            static function ($value) use ($deferred, &$subscriber): void { $deferred->complete($value); $subscriber->unsubscribe(); },
            static fn (\Throwable $error) => $deferred->error($error),
            static fn () => $deferred->error(new EmptyError()),
        );
        $source->subscribe($subscriber);
        return $deferred->getFuture();
    }
    private static function child(Subscriber $destination, \Closure $next, ?\Closure $complete = null): Subscriber
    {
        $child = new Subscriber($next, $destination->error(...), $complete ?? $destination->complete(...));
        $destination->add($child);
        $child->add(static fn () => $destination->remove($child));
        return $child;
    }
    public static function map(\Closure $project): \Closure
    {
        return static fn (Observable $source) => new Observable(static fn (Subscriber $destination) => $source->subscribe(self::child($destination, static fn ($value) => $destination->next($project($value)))));
    }
    public static function filter(\Closure $predicate): \Closure
    {
        return static fn (Observable $source) => new Observable(static fn (Subscriber $destination) => $source->subscribe(self::child($destination, static function ($value) use ($predicate, $destination): void { if (Js::truthy($predicate($value))) { $destination->next($value); } })));
    }
    public static function take(int $count): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $count): void {
            if ($count <= 0) { $destination->complete(); return; }
            $seen = 0;
            $child = self::child($destination, static function ($value) use ($destination, $count, &$seen): void {
                if (++$seen <= $count) {
                    $destination->next($value);
                    if ($count <= $seen) { $destination->complete(); }
                }
            });
            $source->subscribe($child);
        });
    }
    public static function startWith(mixed $value): \Closure { return static fn (Observable $source) => self::concat(self::of($value), $source); }
    public static function takeUntil(Observable $notifier): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $notifier): void {
            $notifier->subscribe(self::child($destination, static fn () => $destination->complete(), static function (): void {}));
            if (!$destination->closed) { $source->subscribe(self::child($destination, $destination->next(...))); }
        });
    }
    public static function distinctUntilChanged(): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source): void {
            $first = true; $previous = null;
            $source->subscribe(self::child($destination, static function ($value) use ($destination, &$first, &$previous): void {
                if ($first || !Js::strictEqual($previous, $value)) { $first = false; $previous = $value; $destination->next($value); }
            }));
        });
    }
    public static function mergeMap(\Closure $project): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $project): void {
            $state = new FlattenState();
            $check = static function () use ($destination, $state): void { $state->completeMerge($destination); };
            $source->subscribe(self::child($destination, static function ($value) use ($destination, $project, $state, $check): void {
                ++$state->active;
                $project($value)->subscribe(self::child($destination, $destination->next(...), static function () use ($state, $check): void { --$state->active; $check(); }));
            }, static function () use ($state, $check): void { $state->outerDone = true; $check(); }));
        });
    }
    public static function mergeScan(\Closure $accumulator, mixed $seed): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $accumulator, $seed): void {
            $state = $seed;
            $source->pipe(self::mergeMap(static function ($value) use ($accumulator, &$state): Observable {
                return $accumulator($state, $value)->pipe(self::map(static function ($next) use (&$state) { $state = $next; return $next; }));
            }))->subscribe($destination);
        });
    }
    public static function switchMap(\Closure $project): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $project): void {
            $state = new FlattenState();
            $source->subscribe(self::child($destination, static function ($value) use ($destination, $project, $state): void {
                $state->inner?->unsubscribe();
                $projected = $project($value);
                $state->inner = self::child($destination, $destination->next(...), static function () use ($state, $destination): void { $state->inner = null; $state->completeSwitch($destination); });
                $projected->subscribe($state->inner);
            }, static function () use ($state, $destination): void { $state->outerDone = true; $state->completeSwitch($destination); }));
        });
    }
    public static function concat(Observable ...$sources): Observable
    {
        return new Observable(static function (Subscriber $destination) use ($sources): void {
            $index = 0; $advance = null;
            $advance = static function () use (&$index, &$advance, $sources, $destination): void {
                if ($destination->closed) { return; }
                if ($index === count($sources)) { $destination->complete(); return; }
                $sources[$index++]->subscribe(self::child($destination, $destination->next(...), $advance));
            };
            $advance();
        });
    }
    public static function merge(Observable ...$sources): Observable { return self::of(...$sources)->pipe(self::mergeMap(static fn ($source) => $source)); }
    public static function raceWith(Observable ...$others): \Closure
    {
        return static fn (Observable $source) => new Observable(static function (Subscriber $destination) use ($source, $others): void {
            $winner = null; $children = [];
            foreach ([$source, ...$others] as $index => $candidate) {
                if ($destination->closed || $winner !== null) { break; }
                $child = self::child($destination, static function ($value) use ($index, &$winner, &$children, $destination): void {
                    if ($winner === null) { $winner = $index; foreach ($children as $otherIndex => $other) { if ($otherIndex !== $index) { $other->unsubscribe(); } } }
                    $destination->next($value);
                });
                $children[$index] = $child;
                $candidate->subscribe($child);
            }
        });
    }
    /** AbortSignal's host counterpart is Amp Cancellation. Source boundary is hash-guarded. */
    public static function fromAbortSignal(mixed $signal = UndefinedValue::Value, mixed $cause = UndefinedValue::Value): Observable
    {
        if ($signal === UndefinedValue::Value || $signal === null) { return self::never(); }
        if (!$signal instanceof \Amp\Cancellation) { throw new \TypeError('signal must implement Amp\\Cancellation'); }
        return new Observable(static function (Subscriber $subscriber) use ($signal): \Closure {
            // Upstream fromEvent observes future abort events only, not an earlier abort.
            if ($signal->isRequested()) { return static function (): void {}; }
            $id = $signal->subscribe($subscriber->error(...));
            return static fn () => $signal->unsubscribe($id);
        });
    }
}
