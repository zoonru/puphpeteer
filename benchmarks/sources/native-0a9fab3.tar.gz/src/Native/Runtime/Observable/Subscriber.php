<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

final class Subscriber extends Subscription
{
    private bool $stopped = false;
    public function __construct(private \Closure $onNext, private \Closure $onError, private \Closure $onComplete) {}
    public function next(mixed $value): void
    {
        if ($this->closed || $this->stopped) { return; }
        try { ($this->onNext)($value); } catch (\Throwable $error) { $this->error($error); }
    }
    public function error(\Throwable $error): void
    {
        if ($this->closed || $this->stopped) { return; }
        $this->stopped = true;
        try { ($this->onError)($error); } finally { $this->unsubscribe(); }
    }
    public function complete(): void
    {
        if ($this->closed || $this->stopped) { return; }
        $this->stopped = true;
        try { ($this->onComplete)(); } finally { $this->unsubscribe(); }
    }
}
