<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

/** Subscription ownership makes synchronous completion tear down late-added resources too. */
class Subscription
{
    public bool $closed = false;
    private array $teardowns = [];
    public function add(mixed $teardown): void
    {
        if ($teardown === $this || !($teardown instanceof self || $teardown instanceof \Closure)) { return; }
        if ($this->closed) { $teardown instanceof self ? $teardown->unsubscribe() : $teardown(); }
        else { $this->teardowns[] = $teardown; }
    }
    public function remove(self $child): void
    {
        foreach ($this->teardowns as $key => $teardown) { if ($teardown === $child) { unset($this->teardowns[$key]); } }
    }
    public function unsubscribe(): void
    {
        if ($this->closed) { return; }
        $this->closed = true; $teardowns = $this->teardowns; $this->teardowns = [];
        foreach ($teardowns as $teardown) { $teardown instanceof self ? $teardown->unsubscribe() : $teardown(); }
    }
}
