<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime\Observable;

final class EmptyError extends \RuntimeException
{
    public function __construct() { parent::__construct('no elements in sequence'); }
}
