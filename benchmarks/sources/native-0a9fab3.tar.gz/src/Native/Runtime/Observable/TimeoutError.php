<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

/** JavaScript ErrorOptions at the generated utility boundary. */
final class TimeoutError extends \Nesk\Puphpeteer\Native\TimeoutError
{
    public function __construct(string $message, mixed $options = null)
    {
        $cause = $options->cause ?? null;
        parent::__construct($message, 0, $cause instanceof \Throwable ? $cause : null);
    }
}
