<?php
declare(strict_types=1);

// PHP host adaptation of RxJS 7.8.2 behavior, with Amp/Revolt scheduling.
// Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors.
// SPDX-License-Identifier: Apache-2.0. See LICENSE-RXJS.

namespace Nesk\Puphpeteer\Native\Runtime\Observable;

final class ReplaySubject extends Observable
{
    private array $buffer = [];
    private array $subscribers = [];
    private bool $stopped = false;
    private ?\Throwable $failure = null;
    public function __construct(private int $bufferSize)
    {
        parent::__construct(function (Subscriber $subscriber): void {
            $id = spl_object_id($subscriber);
            if (!$this->stopped) { $this->subscribers[$id] = $subscriber; }
            $subscriber->add(function () use ($id): void { unset($this->subscribers[$id]); });
            foreach ($this->buffer as $value) { $subscriber->next($value); }
            if ($this->stopped) { $this->failure ? $subscriber->error($this->failure) : $subscriber->complete(); }
        });
    }
    public function next(mixed $value): void
    {
        if ($this->stopped) { return; }
        $this->buffer[] = $value;
        $this->buffer = array_slice($this->buffer, -max(1, $this->bufferSize));
        foreach ($this->subscribers as $subscriber) { $subscriber->next($value); }
    }
    public function error(\Throwable $error): void { if ($this->stopped) { return; } $this->failure = $error; $this->finish(); }
    public function complete(): void { $this->finish(); }
    private function finish(): void
    {
        if ($this->stopped) { return; }
        $this->stopped = true;
        foreach ($this->subscribers as $subscriber) { $this->failure ? $subscriber->error($this->failure) : $subscriber->complete(); }
        $this->subscribers = [];
    }
}
