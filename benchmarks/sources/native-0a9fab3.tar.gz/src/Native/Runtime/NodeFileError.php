<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Error properties exposed by the local-file boundary used by generated methods. */
final class NodeFileError extends JsError
{
    public function __construct(public readonly string $filesystemCode, public readonly string $path, private string $operation = 'open')
    {
        $description = match($filesystemCode){'ENOENT'=>'no such file or directory','EISDIR'=>'illegal operation on a directory','EACCES'=>'permission denied',default=>'i/o error'};
        parent::__construct($filesystemCode.': '.$description.', '.$operation.($operation === 'open' ? " '".$path."'" : ''));
    }
    public function getJsProperty(string $name): mixed
    {
        return match($name){'code'=>$this->filesystemCode,'path'=>$this->path,'syscall'=>$this->operation,'errno'=>match($this->filesystemCode){'ENOENT'=>-2,'EISDIR'=>-21,'EACCES'=>-13,default=>-5},default=>parent::getJsProperty($name)};
    }
}
