<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Amp\Future;
use Nesk\Puphpeteer\Native\JSHandle;

/** The source Binding consumes a Map; public PHP getProperties exposes an array. */
final class BindingHandle implements JsSymbolObject
{
    public function __construct(private JSHandle $handle) {}
    public function getProperties(): Future { return $this->handle->getPropertiesMap(); }
    public function getJsSymbol(WellKnownSymbol $symbol): mixed { return $this->handle->getJsSymbol($symbol); }
}
