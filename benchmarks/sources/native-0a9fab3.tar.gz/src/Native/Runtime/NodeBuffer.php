<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

use Nesk\Puphpeteer\Native\ByteArray;

/** PHP Buffer representation is a binary string; Uint8Array uses ByteArray. */
final class NodeBuffer
{
    public static function from(ByteArray $value): string { return $value->bytes; }
}
