<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** Node path operations used by uploadFile: lexical resolution, never realpath/stat. */
final class NodePath implements JsObject
{
    public function getJsProperty(string $name): mixed
    {
        return match ($name) { 'win32'=>new PathFlavor(true), 'posix'=>new PathFlavor(false), default=>UndefinedValue::Value };
    }
    public function resolve(string $path): string
    {
        if (DIRECTORY_SEPARATOR !== '/') { throw new \RuntimeException('Relative upload paths on Windows require a Node path adapter; use absolute paths'); }
        $cwd=getcwd();if($cwd===false){throw new \RuntimeException('Cannot resolve current working directory');}
        $parts=[];foreach(explode('/',$cwd.'/'.$path)as$part){if($part===''||$part==='.')continue;if($part==='..'){array_pop($parts);}else{$parts[]=$part;}}
        return '/'.implode('/',$parts);
    }
}
final class PathFlavor
{
    public function __construct(private bool $windows){}
    public function isAbsolute(string $path):bool
    {
        if($path==='')return false;
        if($path[0]==='/')return true;
        return $this->windows && ($path[0]==='\\' || strlen($path)>=3 && (ord($path[0])>=65&&ord($path[0])<=90||ord($path[0])>=97&&ord($path[0])<=122) && $path[1]===':' && ($path[2]==='/'||$path[2]==='\\'));
    }
}
