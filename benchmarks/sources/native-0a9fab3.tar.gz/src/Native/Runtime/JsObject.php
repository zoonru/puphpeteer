<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** Getter dispatch declared explicitly by generated classes. */
interface JsObject
{
    public function getJsProperty(string $name): mixed;
}
