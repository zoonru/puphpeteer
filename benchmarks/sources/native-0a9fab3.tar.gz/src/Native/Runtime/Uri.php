<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/** ECMAScript URI-component encoding for the UTF-8 strings used in source URLs. */
final class Uri
{
    private static function invalid(): never
    {
        $error=new JsError('URI malformed');$error->name='URIError';throw $error;
    }
    public static function encodeComponent(string $value): string
    {
        if(preg_match('//u',$value)!==1){self::invalid();}
        return strtr(rawurlencode($value),['%21'=>'!','%27'=>"'",'%28'=>'(','%29'=>')','%2A'=>'*']);
    }
    public static function decodeComponent(string $value): string
    {
        if(preg_match('/%(?![0-9a-fA-F]{2})/',$value)){self::invalid();}
        $decoded=rawurldecode($value);
        if(preg_match('//u',$decoded)!==1){self::invalid();}
        return $decoded;
    }
}
