<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

interface JsSymbolObject
{
    public function getJsSymbol(WellKnownSymbol $symbol): mixed;
}
