<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native\Runtime;

/** WHATWG URL host object; parsing is shared across PHP versions through rowbot/url. */
final class WhatwgUrl implements JsObject
{
    private \Rowbot\URL\URL $url;

    public function __construct(mixed $input, mixed $base = UndefinedValue::Value)
    {
        try {
            $this->url = new \Rowbot\URL\URL(Js::string($input), $base === UndefinedValue::Value ? null : Js::string($base));
        } catch (\Rowbot\URL\Exception\TypeError $error) {
            throw new \TypeError('Invalid URL', 0, $error);
        }
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'href', 'origin', 'protocol', 'username', 'password', 'host', 'hostname', 'port', 'pathname', 'search', 'hash' => $this->url->{$name},
            default => UndefinedValue::Value,
        };
    }
}
