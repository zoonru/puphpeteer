<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

/**
 * JavaScript Error's mutable message/name/cause at the PHP exception boundary.
 * @property string $name
 */
class JsError extends \RuntimeException implements MutableJsObject
{
    private mixed $cause;
    private string $errorName = 'Error';
    public function __construct(mixed $message = UndefinedValue::Value, mixed $options = UndefinedValue::Value)
    {
        $this->cause = $options === UndefinedValue::Value ? UndefinedValue::Value : Js::get($options,'cause');
        parent::__construct($message === UndefinedValue::Value ? '' : Js::string($message), 0, $this->cause instanceof \Throwable ? $this->cause : null);
    }
    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
    public function getJsProperty(string $name): mixed
    {
        return match ($name) { 'message'=>$this->message, 'name'=>$this->errorName, 'cause'=>$this->cause, default=>UndefinedValue::Value };
    }
    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            case 'message': $this->message = Js::string($value); break;
            case 'name': $this->errorName = Js::string($value); break;
            case 'cause': $this->cause = $value; break;
            default: throw new \TypeError('Unsupported Error property: '.$name);
        }
        return $value;
    }
}
