<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native\Runtime;

final class WeakObjectMap
{
    private \WeakMap $values;
    public function __construct() { $this->values = new \WeakMap(); }
    public function get(mixed $key): mixed { return is_object($key) ? ($this->values[$key] ?? UndefinedValue::Value) : UndefinedValue::Value; }
    public function set(object $key, mixed $value): self { $this->values[$key] = $value; return $this; }
}
