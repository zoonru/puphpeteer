<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use function Amp\async;

final class BrowserContext
{
    use Generated\Upstream\ContextStorageCommands { cookies as private sourceCookies; }
    use Generated\Upstream\ContextCookieCommands;
    private mixed $contextId;
    private bool $closed = false;

    public function __construct(private Connection $connection, private ?string $id, private Browser $browser)
    {
        $this->contextId = $id ?? Runtime\UndefinedValue::Value;
    }

    public function cookies(): Future
    {
        return $this->sourceCookies()->map(static fn ($cookies) => array_map(static fn ($cookie) => (array) Runtime\Js::toWire($cookie), iterator_to_array(Runtime\Js::iterate($cookies), false)));
    }

    public function newPage(): Future
    {
        return async(function (): Page {
            if ($this->closed) {
                throw new \RuntimeException('Browser context closed');
            }
            $params = ['url' => 'about:blank'];
            if ($this->id !== null) {
                $params['browserContextId'] = $this->id;
            }
            $target = $this->connection->session()->send('Target.createTarget', $params)->await();
            $attached = $this->connection->session()->send('Target.attachToTarget', ['targetId' => $target['targetId'], 'flatten' => true])->await();
            $page = new Page($this->connection, $this->connection->session($attached['sessionId']), $target['targetId'], $this->browser);
            $page->initialize();
            return $page;
        });
    }

    public function close(): Future
    {
        return async(function (): void {
            if ($this->closed) {
                return;
            }
            if ($this->id === null) {
                throw new \RuntimeException('The default browser context cannot be closed');
            }
            $this->connection->session()->send('Target.disposeBrowserContext', ['browserContextId' => $this->id])->await();
            $this->closed = true;
        });
    }
}
