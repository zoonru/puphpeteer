<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** PHP value adapters; all request behavior and state are compiled from upstream. */
final class HTTPRequest extends Generated\Upstream\CdpHTTPRequest
{
    public function headers(): array { return (array) Runtime\Js::toWire(parent::headers()); }
    public function redirectChain(): array { return iterator_to_array(Runtime\Js::iterate(parent::redirectChain()), false); }
}
