<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Nesk\Puphpeteer\Native\Generated\Upstream\BindingFunctions;

/** PHP callback and context boundary for the complete source-generated Binding. */
final class Binding
{
    private Generated\Upstream\Binding $source;

    public function __construct(public readonly string $name, \Closure $callback, public readonly string $type = 'exposedFun')
    {
        $init = '(' . BindingFunctions::init . ')(' . implode(',', array_map(
            static fn (string $value): string => json_encode($value, JSON_THROW_ON_ERROR),
            [$type, $name, BindingFunctions::prefix])) . ');';
        $this->source = new Generated\Upstream\Binding($name, $callback, $init);
    }

    public function initSource(): string { return $this->source->initSource(); }

    public function run(ExecutionContext $context, mixed $id, mixed $arguments, mixed $isTrivial): Future
    {
        return $this->source->run(new Runtime\BindingContext($context), $id, $arguments, $isTrivial);
    }
}
