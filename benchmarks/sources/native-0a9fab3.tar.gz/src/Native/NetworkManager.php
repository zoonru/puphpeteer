<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** Native owner lifetime and event delivery around the complete generated manager. */
final class NetworkManager extends Generated\Upstream\NetworkManager
{
    /** @var \WeakMap<Session, \Amp\Future> */
    private \WeakMap $initializations;
    /** @var \WeakMap<HTTPRequest, bool> */
    private \WeakMap $pendingRequests;

    public function __construct(private Session $session, ?FrameManager $frameProvider = null, mixed $networkEnabled = Runtime\UndefinedValue::Value)
    {
        $this->initializations = new \WeakMap();
        $this->pendingRequests = new \WeakMap();
        parent::__construct($frameProvider ?? new class { public function frame(string $id): mixed { return null; } }, $networkEnabled);
        $session->observe('__native_session_closed', function (): void {
            foreach ($this->pendingRequests as $request => $_) { $request->response()?->_resolveBody(new TargetCloseError('Target closed')); }
            $this->pendingRequests = new \WeakMap();
            $this->networkEvents = new Generated\Upstream\NetworkEventStore();
        });
        $this->addClient($session);
    }

    public function addClient(mixed $client): mixed
    {
        $future = parent::addClient($client);
        if ($client instanceof Session && !isset($this->initializations[$client])) {
            // Frame registration precedes its awaitable initialization phase.
            $this->initializations[$client] = $future;
            $client->observe('__native_session_closed', function () use ($client): void { unset($this->initializations[$client]); });
        }
        $future->ignore();
        return $future;
    }

    public function initializeNetworkClient(Session $client): \Amp\Future
    {
        return $this->initializations[$client] ?? $this->addClient($client);
    }

    public function events(): Session { return $this->session; }

    public function emit(mixed $event, mixed $value): mixed
    {
        if (!is_string($event) || !in_array($event, ['request','response','requestfinished','requestfailed','requestservedfromcache'], true)) { return parent::emit($event, $value); }
        if ($event === 'request') { $this->pendingRequests[$value] = true; }
        if ($event === 'requestfinished' || $event === 'requestfailed') { unset($this->pendingRequests[$value]); }
        $this->session->dispatch('__native_' . $event, [$event === 'response' ? 'response' : 'request' => $value]);
        return parent::emit($event, $value);
    }

    /** Release native body waiters when their owning frame is destroyed. */
    public function forgetFrame(string $frameId): void
    {
        foreach ($this->pendingRequests as $request => $_) {
            if ($request->frame()?->id !== $frameId) { continue; }
            $request->response()?->_resolveBody(new \RuntimeException('Frame detached before response body was loaded'));
            if ($this->networkEvents->getRequest($request->id) === $request) { $this->NetworkManager_forgetRequest($request, true); }
            unset($this->pendingRequests[$request]);
        }
    }
}
