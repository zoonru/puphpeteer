<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** PHP map representation at the boundary of the complete generated classes. */
final class HTTPResponse extends Generated\Upstream\CdpHTTPResponse
{
    public function headers(): array { return (array) Runtime\Js::toWire(parent::headers()); }
    public function remoteAddress(): array { return (array) Runtime\Js::toWire(parent::remoteAddress()); }
}
