<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\CancelledException;
use Amp\CompositeCancellation;
use Amp\Future;
use Amp\TimeoutCancellation;
use Nesk\Puphpeteer\Native\Generated\Upstream\FrameCommands;
use Nesk\Puphpeteer\Native\Generated\Upstream\FrameApiCommands;
use Nesk\Puphpeteer\Native\Generated\Upstream\TimeoutSettings;
use function Amp\async;

final class Frame implements Runtime\JsObject
{
    use FrameCommands;
    use Generated\Upstream\FrameNavigationCommands;
    use Generated\Upstream\FrameTagCommands;
    use Generated\Upstream\FrameLifecycleCommands;
    use FrameApiCommands;
    use Generated\Upstream\FrameDocumentCommands;
    use Generated\Upstream\FrameDocumentWriter;
    use Generated\Upstream\FrameContentCommands;
    use Generated\Upstream\FrameActionCommands;

    private string $frameUrl = '';
    private string $frameName = '';
    private bool $removed = false;
    public string $loaderId = '';
    public Runtime\StringSet $_lifecycleEvents;
    public bool $_hasStartedLoading = false;

    public function __construct(public readonly FrameManager $manager, public string $id, public ?string $parentId, private Session $client, private TimeoutSettings $timeouts) { $this->_lifecycleEvents = new Runtime\StringSet(); }

    public function getJsProperty(string $name): mixed
    {
        return match($name){'worlds'=>['main'=>$this->mainRealm()],'client'=>$this->client,'_loaderId','loaderId'=>$this->loaderId,'id','_id'=>$this->id,'parentId'=>$this->parentId,'_lifecycleEvents'=>$this->_lifecycleEvents,'_hasStartedLoading'=>$this->_hasStartedLoading,default=>Runtime\UndefinedValue::Value};
    }

    public function session(): Session { return $this->client; }
    public function switchSession(Session $session): void { $this->client = $session; }
    public function page(): Page { return $this->manager->page(); }
    public function isolatedRealm(): ExecutionContext { return $this->manager->context($this, true); }
    public function mainRealm(): ExecutionContext { return $this->executionContext(); }

    public function parentFrame(): ?self { return $this->parentId === null || $this->removed ? null : $this->manager->frame($this->parentId); }
    public function childFrames(): array { return array_values(array_filter($this->manager->frames(), fn (self $frame) => $frame->parentId === $this->id)); }
    public function isDetached(): bool { return $this->detached(); }
    public function markDetached(): void { $this->removed = true; }
    public function assertAttached(): void { if ($this->removed) { throw new \RuntimeException(Generated\Upstream\FrameErrors::detached($this)); } }

    public function navigated(array $payload): void
    {
        $this->frameUrl = $payload['url'] . ($payload['urlFragment'] ?? '');
        $this->frameName = $payload['name'] ?? '';
        $this->loaderId = $payload['loaderId'] ?? $this->loaderId;
        $this->parentId = $payload['parentId'] ?? $this->parentId;
    }

    public function sameDocument(string $url): void { $this->frameUrl = $url; }

    public function frameElement(): Future
    {
        return async(function (): ?ElementHandle {
            $parent = $this->parentFrame();
            if ($parent === null) { return null; }
            $owner = $parent->session()->send('DOM.getFrameOwner', ['frameId' => $this->id])->await();
            $context = $parent->executionContext();
            $resolved = $parent->session()->send('DOM.resolveNode', ['backendNodeId' => $owner['backendNodeId'], 'executionContextId' => $context->id])->await();
            return new ElementHandle($context, $resolved['object']);
        });
    }

    public function executionContext(?Cancellation $cancellation = null): ExecutionContext
    {
        return $this->manager->context($this, false, $cancellation);
    }

    public function evaluate(JsFunction|string $function, mixed ...$arguments): Future
    {
        return Runtime\Js::async(fn () => $this->executionContext()->evaluate($function, $arguments)->await());
    }

    public function evaluateHandle(JsFunction|string $function, mixed ...$arguments): Future
    {
        return Runtime\Js::async(fn () => $this->executionContext()->evaluate($function, $arguments, false)->await());
    }

    /** Original browser pollers; a context replacement restarts the same wait. */
    public function waitForFunction(JsFunction|string $function, array $options = [], mixed ...$arguments): Future
    {
        return async(function () use ($function, $options, $arguments): JSHandle {
            $timeout = $options['timeout'] ?? $this->timeouts->timeout();
            $deadline = $timeout > 0 ? new TimeoutCancellation($timeout / 1000) : null;
            $signal = $options['signal'] ?? null;
            $cancellation = $deadline && $signal ? new CompositeCancellation($deadline, $signal) : ($signal ?? $deadline);
            $options['signal'] = $cancellation;
            try {
                while (true) {
                    $cancellation?->throwIfRequested();
                    $context = $this->executionContext($cancellation);
                    try { return $context->waitForFunction($function, $options, $arguments)->await(); }
                    catch (\Throwable $error) {
                        if ($context->active() || $error instanceof CancelledException) { throw $error; }
                    }
                }
            } catch (CancelledException $error) {
                if ($deadline?->isRequested() && !$signal?->isRequested()) {
                    throw new TimeoutError('Waiting failed: ' . $timeout . 'ms exceeded', 0, $error);
                }
                throw $error;
            }
        });
    }

    public function waitForSelector(string $selector, array $options = []): Future
    {
        return QueryHandler::waitFor($this, $selector, $options);
    }

    public function querySelector(string $selector): Future
    {
        return async(function () use ($selector): ?ElementHandle {
            $document = $this->evaluateHandle('document')->await();
            try { return $document->querySelector($selector)->await(); }
            finally { $document->dispose()->await(); }
        });
    }

    public function querySelectorAll(string $selector): Future
    {
        return async(function () use ($selector): array {
            $document = $this->evaluateHandle('document')->await();
            try { return $document->querySelectorAll($selector)->await(); }
            finally { $document->dispose()->await(); }
        });
    }

    public function title(): Future { return $this->evaluate('document.title'); }

}
