<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** PHP representation of a Uint8Array; the input string contains raw bytes. */
final class ByteArray implements Runtime\JsObject
{
    public function __construct(public readonly string $bytes) {}
    public function getJsProperty(string $name): mixed { return in_array($name, ['length', 'byteLength'], true) ? strlen($this->bytes) : Runtime\UndefinedValue::Value; }
}
