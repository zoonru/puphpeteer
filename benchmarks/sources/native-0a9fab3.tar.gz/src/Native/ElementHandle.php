<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Nesk\Puphpeteer\Native\Generated\Upstream\ElementFunctions;
use Nesk\Puphpeteer\Native\Runtime\Js;
use function Amp\async;

class ElementHandle extends JSHandle
{
    use Generated\Upstream\ElementInputCommands;
    use Generated\Upstream\ElementUploadCommands;
    use Generated\Upstream\ElementGeometryCommands;

    private ?Future $isolatedHandle = null;

    /** Isolated binding for generated methods returning values or void, not JSHandles. */
    private function invokeIsolatedVoid(\Closure $operation): Future
    {
        if ($this->disposed()) { throw new \RuntimeException('Attempted to use disposed CdpElementHandle.'); }
        return async(function () use ($operation) {
            $isolated = $this->isolated()->await();
            return $operation->call($isolated);
        });
    }

    public function frame(): Frame { return $this->context()->frame ?? throw new \RuntimeException('Element has no frame'); }

    public function contentFrame(): Future
    {
        return $this->context()->session->send('DOM.describeNode', ['objectId' => $this->id()])
            ->map(fn (array $result): ?Frame => isset($result['node']['frameId']) ? $this->frame()->manager->frame($result['node']['frameId']) : null);
    }

    public function queryAXTree(?string $name = null, ?string $role = null): Future
    {
        return async(function () use ($name, $role): array {
            $params = ['objectId' => $this->id()];
            if ($name !== null) { $params['accessibleName'] = $name; }
            if ($role !== null) { $params['role'] = $role; }
            $result = $this->context()->session->send('Accessibility.queryAXTree', $params)->await();
            $handles = [];
            try {
                foreach ($result['nodes'] as $node) {
                    if (($node['ignored'] ?? false) || !isset($node['role']) || in_array($node['role']['value'], Generated\Upstream\BindingFunctions::ignoredAxRoles, true)) { continue; }
                    $resolved = $this->context()->session->send('DOM.resolveNode', ['backendNodeId' => $node['backendDOMNodeId'], 'executionContextId' => $this->context()->id])->await();
                    $handles[] = $this->context()->handle($resolved['object']);
                }
                return $handles;
            } catch (\Throwable $error) {
                foreach ($handles as $handle) { $handle->dispose()->await(); }
                throw $error;
            }
        });
    }

    public function asElement(): mixed { return $this; }

    private function isolated(): Future
    {
        if ($this->disposed()) { return Future::error(new \RuntimeException('JSHandle is disposed')); }
        return $this->isolatedHandle ??= async(fn () => $this->context()->isolated()->await()->adoptElement($this)->await());
    }

    public function focus(): Future
    {
        return async(fn () => $this->isolated()->await()->evaluate(new JsFunction(ElementFunctions::focus))->await());
    }

    public function select(string ...$values): Future
    {
        return async(fn () => $this->isolated()->await()->evaluate(new JsFunction(ElementFunctions::select), $values)->await());
    }

    public function scrollIntoView(): Future
    {
        return async(function (): void {
            $handle = $this->isolated()->await();
            $error = $handle->evaluate(new JsFunction(ElementFunctions::assertConnectedElement))->await();
            if (Js::truthy($error)) { throw new \RuntimeException($error); }
            try {
                $this->context()->session->send('DOM.scrollIntoViewIfNeeded', ['objectId' => $handle->id()])->await();
            } catch (ProtocolException) {
                $handle->evaluate(new JsFunction(ElementFunctions::scrollIntoView))->await();
            }
        });
    }

    public function waitForSelector(string $selector, array $options = []): Future
    {
        return QueryHandler::waitFor($this, $selector, $options);
    }

    public function querySelector(string $selector): Future
    {
        return QueryHandler::query($this, $selector);
    }

    public function querySelectorAll(string $selector): Future
    {
        return QueryHandler::query($this, $selector, true);
    }

    public function dispose(): Future
    {
        $dispose = parent::dispose();
        return async(function () use ($dispose): void {
            try { $dispose->await(); } finally {
                if ($this->isolatedHandle !== null) {
                    try { $isolated = $this->isolatedHandle->await(); } catch (\Throwable) { $isolated = null; }
                    if ($isolated !== null && $isolated !== $this) { $isolated->dispose()->await(); }
                }
            }
        });
    }
}
