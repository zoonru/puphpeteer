<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

class Touchscreen extends Generated\Upstream\CdpTouchscreen {}
