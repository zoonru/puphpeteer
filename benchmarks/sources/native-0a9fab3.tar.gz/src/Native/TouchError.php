<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

class TouchError extends \RuntimeException {}
