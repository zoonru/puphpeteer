<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Generated\Upstream\Deferred;
use Nesk\Puphpeteer\Native\Generated\Upstream\Lifecycle;
use Nesk\Puphpeteer\Native\Runtime\Js;

/** Host event wiring around LifecycleWatcher's generated state and completion logic. */
final class LifecycleWatcher
{
    use Generated\Upstream\LifecycleCommands { navigationResponse as private sourceNavigationResponse; }

    private array $expected = [];
    private string $initialLoader;

    public function __construct(NetworkManager $networkManager, private Frame $frame, mixed $waitUntil, private int $timeout, Cancellation|\Nesk\Puphpeteer\Native\Runtime\UndefinedValue|null $signal = null)
    {
        $this->initializeLifecycleState();
        foreach (is_string($waitUntil) ? [$waitUntil] : Js::iterate($waitUntil) as $event) {
            $this->expected[] = Lifecycle::EVENTS[$event] ?? throw new \InvalidArgumentException('Unknown value for options.waitUntil: '.$event);
        }
        $this->initialLoader = $frame->loaderId;
        $this->terminationDeferred = Deferred::create(['timeout'=>$this->timeout,'message'=>'Navigation timeout of '.$this->timeout.' ms exceeded']);
        $events=$frame->manager->events();
        $observe=function(string $event, \Closure $handler, ?Session $source = null) use($events):void {
            $source ??= $events;
            $id=$source->observe($event,$handler);
            $this->subscriptions->defer(static fn()=>$source->off($event,$id));
        };
        $observe('__native_lifecycle',fn()=> $this->check());
        $observe('__native_framenavigated',function(array $event):void {if($event['frame']===$this->frame){$this->LifecycleWatcher_navigated($event['type']??'Navigation');}});
        $observe('__native_samedocument',function(array $event):void {if($event['frame']===$this->frame){$this->LifecycleWatcher_navigatedWithinDocument();}});
        $observe('__native_framedetached',fn(array $event)=>$this->LifecycleWatcher_onFrameDetached($event['frame']));
        foreach(['__native_request'=>'LifecycleWatcher_onRequest','__native_response'=>'LifecycleWatcher_onResponse','__native_requestfailed'=>'LifecycleWatcher_onRequestFailed'] as $event=>$method){
            $observe($event,fn(array $payload)=>$this->{$method}($payload[$event==='__native_response'?'response':'request']),$networkManager->events());
        }
        if($signal instanceof Cancellation){
            $id=$signal->subscribe(fn(\Throwable $error)=>$this->terminationDeferred->reject($error));
            $this->subscriptions->defer(static fn()=>$signal->unsubscribe($id));
        }
        $this->check();
    }

    /** Wait for the native BFCache frame metadata boundary before exposing the response. */
    public function navigationResponse(): Future
    {
        return Js::async(function (): mixed {
            $this->frame->manager->frameTreeReady()->await();
            return $this->sourceNavigationResponse()->await();
        });
    }
}
