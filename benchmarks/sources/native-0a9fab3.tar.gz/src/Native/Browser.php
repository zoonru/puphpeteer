<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use function Amp\async;

final class Browser
{
    use Generated\Upstream\BrowserVersionCommands;
    use Generated\Upstream\BrowserCookieCommands;
    use Generated\Upstream\BrowserContextCommands;
    private BrowserContext $defaultContext;
    public function __construct(private Connection $connection)
    {
        $this->defaultContext = new BrowserContext($connection, null, $this);
    }

    public function createBrowserContext(): Future
    {
        return async(function (): BrowserContext {
            $result = $this->connection->session()->send('Target.createBrowserContext', ['disposeOnDetach' => true])->await();
            return new BrowserContext($this->connection, $result['browserContextId'], $this);
        });
    }

    public function newPage(): Future
    {
        return $this->defaultBrowserContext()->newPage();
    }

    public function disconnect(): void
    {
        $this->connection->close();
    }

    public function close(): Future
    {
        return async(function (): void {
            try {
                $this->connection->session()->send('Browser.close')->await();
            } finally {
                $this->disconnect();
            }
        });
    }

    public function throwListenerError(): void
    {
        $this->connection->throwListenerError();
    }
}
