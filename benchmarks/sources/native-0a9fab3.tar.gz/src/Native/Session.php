<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Cancellation;
use Amp\DeferredFuture;
use Amp\Future;
use Nesk\Puphpeteer\Native\Runtime\Js;
use function Amp\async;

final class Session
{
    use Generated\Upstream\SessionTargetCommands;
    private mixed $sourceTarget = Runtime\UndefinedValue::Value;
    private array $listeners = [];
    private array $observers = [];
    private array $allObservers = [];
    private array $waiters = [];
    private int $nextListener = 0;
    private bool $closed = false;
    private ?object $sourcePayload = null;

    public function __construct(private Connection $connection, private ?string $id) {}

    public function id(): ?string { return $this->id; }

    public function send(string $method, array|object $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->closed ? Future::error(new TargetCloseError('CDP session is closed'))
            : $this->connection->send($method, $params, $this->id, $cancellation);
    }

    /** Internal observers run before user callbacks and must never perform I/O. */
    public function observe(string $event, callable $observer): int
    {
        $id = ++$this->nextListener;
        $this->observers[$event][$id] = $observer;
        return $id;
    }
    /** Source listeners share one mutable object per dispatch, including nested dispatches. */
    public function observeSource(string $event, callable $observer): int
    {
        return $this->observe($event, function (array $payload) use ($observer): mixed {
            if ($this->sourcePayload === null) {
                $this->sourcePayload = (object) $payload;
                if (isset($this->sourcePayload->request)) {
                    $this->sourcePayload->request = (object) $this->sourcePayload->request;
                    $this->sourcePayload->request->headers = (object) $this->sourcePayload->request->headers;
                }
            }
            return $observer($this->sourcePayload);
        });
    }

    public function observeAll(\Closure $observer): void { $this->allObservers[] = $observer; }

    public function on(string $event, callable $listener): int
    {
        $id = ++$this->nextListener;
        $this->listeners[$event][$id] = $listener;
        return $id;
    }

    public function once(string $event, callable $listener): int
    {
        $id = $this->observe($event, function (array $params) use ($event, $listener, &$id): void {
            $this->off($event, $id);
            // Source EmulationManager uses this for synchronous Set deletion.
            $listener($params);
        });
        return $id;
    }

    public function off(string $event, int $id): void
    {
        unset($this->listeners[$event][$id], $this->observers[$event][$id]);
    }
    /** Observe failures of internal continuations without blocking the CDP reader. */
    public function track(Future $future): void { $future->catch(fn (\Throwable $error) => $this->connection->recordListenerError($error))->ignore(); }

    /** Registers immediately, before an action can emit the event. */
    public function waitFor(string $event, ?callable $predicate = null, ?Cancellation $cancellation = null): Future
    {
        if ($this->closed) {
            return Future::error(new TargetCloseError('CDP session is closed'));
        }
        $id = ++$this->nextListener;
        $deferred = new DeferredFuture();
        $deferred->getFuture()->ignore();
        $this->waiters[$event][$id] = [$predicate, $deferred];
        return async(function () use ($event, $id, $deferred, $cancellation) {
            try {
                return $deferred->getFuture()->await($cancellation);
            } finally {
                unset($this->waiters[$event][$id]);
            }
        });
    }

    public function dispatch(string $event, array $params): void
    {
        $previous = $this->sourcePayload; $this->sourcePayload = null;
        try {
            foreach ($this->observers[$event] ?? [] as $observer) {
                $observer($params);
            }
            foreach ($this->allObservers as $observer) { $observer($event, $params); }
            foreach ($this->waiters[$event] ?? [] as $id => [$predicate, $deferred]) {
                try {
                    // Predicates must be synchronous; user handlers below may await freely.
                    if ($predicate === null || $predicate($params)) {
                        unset($this->waiters[$event][$id]);
                        $deferred->complete($params);
                    }
                } catch (\Throwable $error) {
                    unset($this->waiters[$event][$id]);
                    $deferred->error($error);
                }
            }
            foreach ($this->listeners[$event] ?? [] as $listener) {
                async(static fn () => Js::await($listener($params)))
                    ->catch(fn (\Throwable $error) => $this->connection->recordListenerError($error))->ignore();
            }
        } finally { $this->sourcePayload = $previous; }
    }

    public function markClosed(): void
    {
        $this->closed = true;
        $previous = $this->sourcePayload; $this->sourcePayload = null;
        try { foreach ($this->observers['__native_session_closed'] ?? [] as $observer) { $observer([]); } }
        finally { $this->sourcePayload = $previous; }
        foreach ($this->waiters as $waiters) {
            foreach ($waiters as [, $deferred]) {
                $deferred->error(new TargetCloseError('CDP session closed while waiting for event'));
            }
        }
        $this->waiters = [];
        $this->listeners = [];
        $this->observers = [];
        $this->allObservers = [];
    }
}
