<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class LayerTree
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function compositingReasons(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.compositingReasons', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function loadSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.loadSnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function makeSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.makeSnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function profileSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.profileSnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function releaseSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.releaseSnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function replaySnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.replaySnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function snapshotCommandLog(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('LayerTree.snapshotCommandLog', $params, $cancellation);
    }

    public const EVENT_LAYER_PAINTED = 'LayerTree.layerPainted';

    public const EVENT_LAYER_TREE_DID_CHANGE = 'LayerTree.layerTreeDidChange';
}
