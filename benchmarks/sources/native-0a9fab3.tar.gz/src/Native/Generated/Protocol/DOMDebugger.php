<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class DOMDebugger
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function getEventListeners(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.getEventListeners', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeDOMBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.removeDOMBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeEventListenerBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.removeEventListenerBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeInstrumentationBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.removeInstrumentationBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeXHRBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.removeXHRBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBreakOnCSPViolation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.setBreakOnCSPViolation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDOMBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.setDOMBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEventListenerBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.setEventListenerBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInstrumentationBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.setInstrumentationBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setXHRBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOMDebugger.setXHRBreakpoint', $params, $cancellation);
    }
}
