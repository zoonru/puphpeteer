<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Memory
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function getDOMCounters(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.getDOMCounters', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getDOMCountersForLeakDetection(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.getDOMCountersForLeakDetection', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function prepareForLeakDetection(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.prepareForLeakDetection', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function forciblyPurgeJavaScriptMemory(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.forciblyPurgeJavaScriptMemory', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPressureNotificationsSuppressed(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.setPressureNotificationsSuppressed', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulatePressureNotification(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.simulatePressureNotification', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startSampling(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.startSampling', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopSampling(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.stopSampling', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAllTimeSamplingProfile(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.getAllTimeSamplingProfile', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBrowserSamplingProfile(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.getBrowserSamplingProfile', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSamplingProfile(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Memory.getSamplingProfile', $params, $cancellation);
    }
}
