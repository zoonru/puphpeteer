<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Page
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function addScriptToEvaluateOnLoad(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.addScriptToEvaluateOnLoad', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addScriptToEvaluateOnNewDocument(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.addScriptToEvaluateOnNewDocument', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function bringToFront(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.bringToFront', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function captureScreenshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.captureScreenshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function captureSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.captureSnapshot', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDeviceMetricsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.clearDeviceMetricsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDeviceOrientationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.clearDeviceOrientationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearGeolocationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.clearGeolocationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function createIsolatedWorld(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.createIsolatedWorld', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteCookie(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.deleteCookie', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAppManifest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getAppManifest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getInstallabilityErrors(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getInstallabilityErrors', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getManifestIcons(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getManifestIcons', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAppId(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getAppId', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAdScriptAncestry(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getAdScriptAncestry', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getFrameTree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getFrameTree', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getLayoutMetrics(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getLayoutMetrics', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getNavigationHistory(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getNavigationHistory', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resetNavigationHistory(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.resetNavigationHistory', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getResourceContent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getResourceContent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getResourceTree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getResourceTree', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function handleJavaScriptDialog(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.handleJavaScriptDialog', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function navigate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.navigate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function navigateToHistoryEntry(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.navigateToHistoryEntry', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function printToPDF(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.printToPDF', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function reload(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.reload', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeScriptToEvaluateOnLoad(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.removeScriptToEvaluateOnLoad', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeScriptToEvaluateOnNewDocument(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.removeScriptToEvaluateOnNewDocument', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function screencastFrameAck(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.screencastFrameAck', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function searchInResource(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.searchInResource', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAdBlockingEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setAdBlockingEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBypassCSP(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setBypassCSP', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getPermissionsPolicyState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getPermissionsPolicyState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getOriginTrials(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getOriginTrials', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDeviceMetricsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setDeviceMetricsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDeviceOrientationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setDeviceOrientationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setFontFamilies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setFontFamilies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setFontSizes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setFontSizes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDocumentContent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setDocumentContent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDownloadBehavior(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setDownloadBehavior', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setGeolocationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setGeolocationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setLifecycleEventsEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setLifecycleEventsEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setTouchEmulationEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setTouchEmulationEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startScreencast(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.startScreencast', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopLoading(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.stopLoading', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function crash(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.crash', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function close(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.close', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setWebLifecycleState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setWebLifecycleState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopScreencast(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.stopScreencast', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function produceCompilationCache(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.produceCompilationCache', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addCompilationCache(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.addCompilationCache', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearCompilationCache(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.clearCompilationCache', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSPCTransactionMode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setSPCTransactionMode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setRPHRegistrationMode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setRPHRegistrationMode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function generateTestReport(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.generateTestReport', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function waitForDebugger(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.waitForDebugger', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInterceptFileChooserDialog(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setInterceptFileChooserDialog', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPrerenderingAllowed(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.setPrerenderingAllowed', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAnnotatedPageContent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Page.getAnnotatedPageContent', $params, $cancellation);
    }

    public const EVENT_DOM_CONTENT_EVENT_FIRED = 'Page.domContentEventFired';

    public const EVENT_FILE_CHOOSER_OPENED = 'Page.fileChooserOpened';

    public const EVENT_FRAME_ATTACHED = 'Page.frameAttached';

    public const EVENT_FRAME_CLEARED_SCHEDULED_NAVIGATION = 'Page.frameClearedScheduledNavigation';

    public const EVENT_FRAME_DETACHED = 'Page.frameDetached';

    public const EVENT_FRAME_SUBTREE_WILL_BE_DETACHED = 'Page.frameSubtreeWillBeDetached';

    public const EVENT_FRAME_NAVIGATED = 'Page.frameNavigated';

    public const EVENT_DOCUMENT_OPENED = 'Page.documentOpened';

    public const EVENT_FRAME_RESIZED = 'Page.frameResized';

    public const EVENT_FRAME_STARTED_NAVIGATING = 'Page.frameStartedNavigating';

    public const EVENT_FRAME_REQUESTED_NAVIGATION = 'Page.frameRequestedNavigation';

    public const EVENT_FRAME_SCHEDULED_NAVIGATION = 'Page.frameScheduledNavigation';

    public const EVENT_FRAME_STARTED_LOADING = 'Page.frameStartedLoading';

    public const EVENT_FRAME_STOPPED_LOADING = 'Page.frameStoppedLoading';

    public const EVENT_DOWNLOAD_WILL_BEGIN = 'Page.downloadWillBegin';

    public const EVENT_DOWNLOAD_PROGRESS = 'Page.downloadProgress';

    public const EVENT_INTERSTITIAL_HIDDEN = 'Page.interstitialHidden';

    public const EVENT_INTERSTITIAL_SHOWN = 'Page.interstitialShown';

    public const EVENT_JAVASCRIPT_DIALOG_CLOSED = 'Page.javascriptDialogClosed';

    public const EVENT_JAVASCRIPT_DIALOG_OPENING = 'Page.javascriptDialogOpening';

    public const EVENT_LIFECYCLE_EVENT = 'Page.lifecycleEvent';

    public const EVENT_BACK_FORWARD_CACHE_NOT_USED = 'Page.backForwardCacheNotUsed';

    public const EVENT_LOAD_EVENT_FIRED = 'Page.loadEventFired';

    public const EVENT_NAVIGATED_WITHIN_DOCUMENT = 'Page.navigatedWithinDocument';

    public const EVENT_SCREENCAST_FRAME = 'Page.screencastFrame';

    public const EVENT_SCREENCAST_VISIBILITY_CHANGED = 'Page.screencastVisibilityChanged';

    public const EVENT_WINDOW_OPEN = 'Page.windowOpen';

    public const EVENT_COMPILATION_CACHE_PRODUCED = 'Page.compilationCacheProduced';
}
