<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class DOM
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function collectClassNamesFromSubtree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.collectClassNamesFromSubtree', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function copyTo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.copyTo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function describeNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.describeNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function scrollIntoViewIfNeeded(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.scrollIntoViewIfNeeded', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function discardSearchResults(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.discardSearchResults', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function focus(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.focus', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAttributes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getAttributes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBoxModel(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getBoxModel', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getContentQuads(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getContentQuads', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getDocument(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getDocument', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getFlattenedDocument(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getFlattenedDocument', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getNodesForSubtreeByStyle(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getNodesForSubtreeByStyle', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getNodeForLocation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getNodeForLocation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getOuterHTML(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getOuterHTML', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getRelayoutBoundary(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getRelayoutBoundary', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSearchResults(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getSearchResults', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function hideHighlight(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.hideHighlight', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.highlightNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightRect(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.highlightRect', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function markUndoableState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.markUndoableState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function moveTo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.moveTo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function performSearch(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.performSearch', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function pushNodeByPathToFrontend(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.pushNodeByPathToFrontend', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function pushNodesByBackendIdsToFrontend(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.pushNodesByBackendIdsToFrontend', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function querySelector(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.querySelector', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function querySelectorAll(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.querySelectorAll', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getTopLayerElements(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getTopLayerElements', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getElementByRelation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getElementByRelation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function redo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.redo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeAttribute(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.removeAttribute', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.removeNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestChildNodes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.requestChildNodes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.requestNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resolveNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.resolveNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAttributeValue(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setAttributeValue', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAttributesAsText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setAttributesAsText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setFileInputFiles(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setFileInputFiles', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setNodeStackTracesEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setNodeStackTracesEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getNodeStackTraces(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getNodeStackTraces', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getFileInfo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getFileInfo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getDetachedDomNodes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getDetachedDomNodes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInspectedNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setInspectedNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setNodeName(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setNodeName', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setNodeValue(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setNodeValue', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setOuterHTML(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.setOuterHTML', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function undo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.undo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getFrameOwner(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getFrameOwner', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getContainerForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getContainerForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getQueryingDescendantsForContainer(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getQueryingDescendantsForContainer', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAnchorElement(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.getAnchorElement', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function forceShowPopover(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('DOM.forceShowPopover', $params, $cancellation);
    }

    public const EVENT_ATTRIBUTE_MODIFIED = 'DOM.attributeModified';

    public const EVENT_ADOPTED_STYLE_SHEETS_MODIFIED = 'DOM.adoptedStyleSheetsModified';

    public const EVENT_ATTRIBUTE_REMOVED = 'DOM.attributeRemoved';

    public const EVENT_CHARACTER_DATA_MODIFIED = 'DOM.characterDataModified';

    public const EVENT_CHILD_NODE_COUNT_UPDATED = 'DOM.childNodeCountUpdated';

    public const EVENT_CHILD_NODE_INSERTED = 'DOM.childNodeInserted';

    public const EVENT_CHILD_NODE_REMOVED = 'DOM.childNodeRemoved';

    public const EVENT_DISTRIBUTED_NODES_UPDATED = 'DOM.distributedNodesUpdated';

    public const EVENT_DOCUMENT_UPDATED = 'DOM.documentUpdated';

    public const EVENT_INLINE_STYLE_INVALIDATED = 'DOM.inlineStyleInvalidated';

    public const EVENT_PSEUDO_ELEMENT_ADDED = 'DOM.pseudoElementAdded';

    public const EVENT_TOP_LAYER_ELEMENTS_UPDATED = 'DOM.topLayerElementsUpdated';

    public const EVENT_SCROLLABLE_FLAG_UPDATED = 'DOM.scrollableFlagUpdated';

    public const EVENT_AFFECTED_BY_STARTING_STYLES_FLAG_UPDATED = 'DOM.affectedByStartingStylesFlagUpdated';

    public const EVENT_PSEUDO_ELEMENT_REMOVED = 'DOM.pseudoElementRemoved';

    public const EVENT_SET_CHILD_NODES = 'DOM.setChildNodes';

    public const EVENT_SHADOW_ROOT_POPPED = 'DOM.shadowRootPopped';

    public const EVENT_SHADOW_ROOT_PUSHED = 'DOM.shadowRootPushed';
}
