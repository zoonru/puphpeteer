<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class BluetoothEmulation
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSimulatedCentralState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.setSimulatedCentralState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulatePreconnectedPeripheral(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulatePreconnectedPeripheral', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulateAdvertisement(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulateAdvertisement', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulateGATTOperationResponse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulateGATTOperationResponse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulateCharacteristicOperationResponse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulateCharacteristicOperationResponse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulateDescriptorOperationResponse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulateDescriptorOperationResponse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addService(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.addService', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeService(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.removeService', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addCharacteristic(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.addCharacteristic', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeCharacteristic(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.removeCharacteristic', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addDescriptor(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.addDescriptor', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeDescriptor(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.removeDescriptor', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function simulateGATTDisconnection(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('BluetoothEmulation.simulateGATTDisconnection', $params, $cancellation);
    }

    public const EVENT_GATT_OPERATION_RECEIVED = 'BluetoothEmulation.gattOperationReceived';

    public const EVENT_CHARACTERISTIC_OPERATION_RECEIVED = 'BluetoothEmulation.characteristicOperationReceived';

    public const EVENT_DESCRIPTOR_OPERATION_RECEIVED = 'BluetoothEmulation.descriptorOperationReceived';
}
