<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class ServiceWorker
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function deliverPushMessage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.deliverPushMessage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dispatchSyncEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.dispatchSyncEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dispatchPeriodicSyncEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.dispatchPeriodicSyncEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setForceUpdateOnPageLoad(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.setForceUpdateOnPageLoad', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function skipWaiting(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.skipWaiting', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startWorker(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.startWorker', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopAllWorkers(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.stopAllWorkers', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopWorker(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.stopWorker', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function unregister(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.unregister', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function updateRegistration(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('ServiceWorker.updateRegistration', $params, $cancellation);
    }

    public const EVENT_WORKER_ERROR_REPORTED = 'ServiceWorker.workerErrorReported';

    public const EVENT_WORKER_REGISTRATION_UPDATED = 'ServiceWorker.workerRegistrationUpdated';

    public const EVENT_WORKER_VERSION_UPDATED = 'ServiceWorker.workerVersionUpdated';
}
