<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class WebAuthn
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addVirtualAuthenticator(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.addVirtualAuthenticator', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setResponseOverrideBits(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.setResponseOverrideBits', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeVirtualAuthenticator(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.removeVirtualAuthenticator', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addCredential(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.addCredential', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCredential(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.getCredential', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCredentials(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.getCredentials', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeCredential(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.removeCredential', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearCredentials(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.clearCredentials', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setUserVerified(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.setUserVerified', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAutomaticPresenceSimulation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.setAutomaticPresenceSimulation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCredentialProperties(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAuthn.setCredentialProperties', $params, $cancellation);
    }

    public const EVENT_CREDENTIAL_ADDED = 'WebAuthn.credentialAdded';

    public const EVENT_CREDENTIAL_DELETED = 'WebAuthn.credentialDeleted';

    public const EVENT_CREDENTIAL_UPDATED = 'WebAuthn.credentialUpdated';

    public const EVENT_CREDENTIAL_ASSERTED = 'WebAuthn.credentialAsserted';
}
