<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class CSS
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function addRule(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.addRule', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function collectClassNames(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.collectClassNames', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function createStyleSheet(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.createStyleSheet', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function forcePseudoState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.forcePseudoState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function forceStartingStyle(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.forceStartingStyle', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBackgroundColors(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getBackgroundColors', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getComputedStyleForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getComputedStyleForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resolveValues(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.resolveValues', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getLonghandProperties(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getLonghandProperties', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getInlineStylesForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getInlineStylesForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAnimatedStylesForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getAnimatedStylesForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getMatchedStylesForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getMatchedStylesForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getEnvironmentVariables(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getEnvironmentVariables', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getMediaQueries(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getMediaQueries', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getPlatformFontsForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getPlatformFontsForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getStyleSheetText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getStyleSheetText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getLayersForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getLayersForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getLocationForSelector(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.getLocationForSelector', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackComputedStyleUpdatesForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.trackComputedStyleUpdatesForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackComputedStyleUpdates(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.trackComputedStyleUpdates', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takeComputedStyleUpdates(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.takeComputedStyleUpdates', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEffectivePropertyValueForNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setEffectivePropertyValueForNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPropertyRulePropertyName(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setPropertyRulePropertyName', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setKeyframeKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setKeyframeKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setMediaText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setMediaText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setContainerQueryText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setContainerQueryText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSupportsText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setSupportsText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setScopeText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setScopeText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setRuleSelector(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setRuleSelector', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setStyleSheetText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setStyleSheetText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setStyleTexts(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setStyleTexts', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startRuleUsageTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.startRuleUsageTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopRuleUsageTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.stopRuleUsageTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takeCoverageDelta(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.takeCoverageDelta', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setLocalFontsEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('CSS.setLocalFontsEnabled', $params, $cancellation);
    }

    public const EVENT_FONTS_UPDATED = 'CSS.fontsUpdated';

    public const EVENT_MEDIA_QUERY_RESULT_CHANGED = 'CSS.mediaQueryResultChanged';

    public const EVENT_STYLE_SHEET_ADDED = 'CSS.styleSheetAdded';

    public const EVENT_STYLE_SHEET_CHANGED = 'CSS.styleSheetChanged';

    public const EVENT_STYLE_SHEET_REMOVED = 'CSS.styleSheetRemoved';

    public const EVENT_COMPUTED_STYLE_UPDATED = 'CSS.computedStyleUpdated';
}
