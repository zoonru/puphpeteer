<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Emulation
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function canEmulate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.canEmulate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDeviceMetricsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.clearDeviceMetricsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearGeolocationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.clearGeolocationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resetPageScaleFactor(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.resetPageScaleFactor', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setFocusEmulationEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setFocusEmulationEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAutoDarkModeOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setAutoDarkModeOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCPUThrottlingRate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setCPUThrottlingRate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDefaultBackgroundColorOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDefaultBackgroundColorOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSafeAreaInsetsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setSafeAreaInsetsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDeviceMetricsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDeviceMetricsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDevicePostureOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDevicePostureOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDevicePostureOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.clearDevicePostureOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDisplayFeaturesOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDisplayFeaturesOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDisplayFeaturesOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.clearDisplayFeaturesOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setScrollbarsHidden(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setScrollbarsHidden', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDocumentCookieDisabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDocumentCookieDisabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEmitTouchEventsForMouse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setEmitTouchEventsForMouse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEmulatedMedia(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setEmulatedMedia', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEmulatedVisionDeficiency(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setEmulatedVisionDeficiency', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setEmulatedOSTextScale(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setEmulatedOSTextScale', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setGeolocationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setGeolocationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getOverriddenSensorInformation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.getOverriddenSensorInformation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSensorOverrideEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setSensorOverrideEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSensorOverrideReadings(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setSensorOverrideReadings', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPressureSourceOverrideEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setPressureSourceOverrideEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPressureStateOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setPressureStateOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPressureDataOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setPressureDataOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setIdleOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setIdleOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearIdleOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.clearIdleOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setNavigatorOverrides(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setNavigatorOverrides', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPageScaleFactor(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setPageScaleFactor', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setScriptExecutionDisabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setScriptExecutionDisabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setTouchEmulationEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setTouchEmulationEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setVirtualTimePolicy(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setVirtualTimePolicy', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setLocaleOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setLocaleOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setTimezoneOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setTimezoneOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setVisibleSize(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setVisibleSize', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDisabledImageTypes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDisabledImageTypes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDataSaverOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setDataSaverOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setHardwareConcurrencyOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setHardwareConcurrencyOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setUserAgentOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setUserAgentOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAutomationOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setAutomationOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSmallViewportHeightDifferenceOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.setSmallViewportHeightDifferenceOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getScreenInfos(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.getScreenInfos', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addScreen(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.addScreen', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeScreen(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Emulation.removeScreen', $params, $cancellation);
    }

    public const EVENT_VIRTUAL_TIME_BUDGET_EXPIRED = 'Emulation.virtualTimeBudgetExpired';
}
