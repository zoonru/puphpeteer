<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class WebAudio
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAudio.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAudio.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getRealtimeData(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('WebAudio.getRealtimeData', $params, $cancellation);
    }

    public const EVENT_CONTEXT_CREATED = 'WebAudio.contextCreated';

    public const EVENT_CONTEXT_WILL_BE_DESTROYED = 'WebAudio.contextWillBeDestroyed';

    public const EVENT_CONTEXT_CHANGED = 'WebAudio.contextChanged';

    public const EVENT_AUDIO_LISTENER_CREATED = 'WebAudio.audioListenerCreated';

    public const EVENT_AUDIO_LISTENER_WILL_BE_DESTROYED = 'WebAudio.audioListenerWillBeDestroyed';

    public const EVENT_AUDIO_NODE_CREATED = 'WebAudio.audioNodeCreated';

    public const EVENT_AUDIO_NODE_WILL_BE_DESTROYED = 'WebAudio.audioNodeWillBeDestroyed';

    public const EVENT_AUDIO_PARAM_CREATED = 'WebAudio.audioParamCreated';

    public const EVENT_AUDIO_PARAM_WILL_BE_DESTROYED = 'WebAudio.audioParamWillBeDestroyed';

    public const EVENT_NODES_CONNECTED = 'WebAudio.nodesConnected';

    public const EVENT_NODES_DISCONNECTED = 'WebAudio.nodesDisconnected';

    public const EVENT_NODE_PARAM_CONNECTED = 'WebAudio.nodeParamConnected';

    public const EVENT_NODE_PARAM_DISCONNECTED = 'WebAudio.nodeParamDisconnected';
}
