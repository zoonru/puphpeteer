<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Fetch
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function failRequest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.failRequest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function fulfillRequest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.fulfillRequest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function continueRequest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.continueRequest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function continueWithAuth(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.continueWithAuth', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function continueResponse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.continueResponse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getResponseBody(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.getResponseBody', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takeResponseBodyAsStream(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Fetch.takeResponseBodyAsStream', $params, $cancellation);
    }

    public const EVENT_REQUEST_PAUSED = 'Fetch.requestPaused';

    public const EVENT_AUTH_REQUIRED = 'Fetch.authRequired';
}
