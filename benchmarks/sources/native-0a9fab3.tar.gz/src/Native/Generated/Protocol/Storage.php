<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Storage
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function getStorageKeyForFrame(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getStorageKeyForFrame', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDataForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.clearDataForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearDataForStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.clearDataForStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.clearCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getUsageAndQuota(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getUsageAndQuota', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function overrideQuotaForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.overrideQuotaForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackCacheStorageForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.trackCacheStorageForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackCacheStorageForStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.trackCacheStorageForStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackIndexedDBForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.trackIndexedDBForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function trackIndexedDBForStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.trackIndexedDBForStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function untrackCacheStorageForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.untrackCacheStorageForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function untrackCacheStorageForStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.untrackCacheStorageForStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function untrackIndexedDBForOrigin(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.untrackIndexedDBForOrigin', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function untrackIndexedDBForStorageKey(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.untrackIndexedDBForStorageKey', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getTrustTokens(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getTrustTokens', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearTrustTokens(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.clearTrustTokens', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getInterestGroupDetails(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getInterestGroupDetails', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInterestGroupTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setInterestGroupTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInterestGroupAuctionTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setInterestGroupAuctionTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSharedStorageMetadata(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getSharedStorageMetadata', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSharedStorageEntries(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getSharedStorageEntries', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSharedStorageEntry(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setSharedStorageEntry', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteSharedStorageEntry(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.deleteSharedStorageEntry', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearSharedStorageEntries(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.clearSharedStorageEntries', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resetSharedStorageBudget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.resetSharedStorageBudget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSharedStorageTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setSharedStorageTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setStorageBucketTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setStorageBucketTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteStorageBucket(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.deleteStorageBucket', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function runBounceTrackingMitigations(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.runBounceTrackingMitigations', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAttributionReportingLocalTestingMode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setAttributionReportingLocalTestingMode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAttributionReportingTracking(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setAttributionReportingTracking', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function sendPendingAttributionReports(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.sendPendingAttributionReports', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getRelatedWebsiteSets(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getRelatedWebsiteSets', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAffectedUrlsForThirdPartyCookieMetadata(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.getAffectedUrlsForThirdPartyCookieMetadata', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setProtectedAudienceKAnonymity(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Storage.setProtectedAudienceKAnonymity', $params, $cancellation);
    }

    public const EVENT_CACHE_STORAGE_CONTENT_UPDATED = 'Storage.cacheStorageContentUpdated';

    public const EVENT_CACHE_STORAGE_LIST_UPDATED = 'Storage.cacheStorageListUpdated';

    public const EVENT_INDEXED_D_B_CONTENT_UPDATED = 'Storage.indexedDBContentUpdated';

    public const EVENT_INDEXED_D_B_LIST_UPDATED = 'Storage.indexedDBListUpdated';

    public const EVENT_INTEREST_GROUP_ACCESSED = 'Storage.interestGroupAccessed';

    public const EVENT_INTEREST_GROUP_AUCTION_EVENT_OCCURRED = 'Storage.interestGroupAuctionEventOccurred';

    public const EVENT_INTEREST_GROUP_AUCTION_NETWORK_REQUEST_CREATED = 'Storage.interestGroupAuctionNetworkRequestCreated';

    public const EVENT_SHARED_STORAGE_ACCESSED = 'Storage.sharedStorageAccessed';

    public const EVENT_SHARED_STORAGE_WORKLET_OPERATION_EXECUTION_FINISHED = 'Storage.sharedStorageWorkletOperationExecutionFinished';

    public const EVENT_STORAGE_BUCKET_CREATED_OR_UPDATED = 'Storage.storageBucketCreatedOrUpdated';

    public const EVENT_STORAGE_BUCKET_DELETED = 'Storage.storageBucketDeleted';

    public const EVENT_ATTRIBUTION_REPORTING_SOURCE_REGISTERED = 'Storage.attributionReportingSourceRegistered';

    public const EVENT_ATTRIBUTION_REPORTING_TRIGGER_REGISTERED = 'Storage.attributionReportingTriggerRegistered';

    public const EVENT_ATTRIBUTION_REPORTING_REPORT_SENT = 'Storage.attributionReportingReportSent';

    public const EVENT_ATTRIBUTION_REPORTING_VERBOSE_DEBUG_REPORT_SENT = 'Storage.attributionReportingVerboseDebugReportSent';
}
