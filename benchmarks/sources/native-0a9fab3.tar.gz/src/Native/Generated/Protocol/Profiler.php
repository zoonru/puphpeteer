<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/js_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Profiler
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBestEffortCoverage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.getBestEffortCoverage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSamplingInterval(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.setSamplingInterval', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function start(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.start', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startPreciseCoverage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.startPreciseCoverage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stop(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.stop', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopPreciseCoverage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.stopPreciseCoverage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takePreciseCoverage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Profiler.takePreciseCoverage', $params, $cancellation);
    }

    public const EVENT_CONSOLE_PROFILE_FINISHED = 'Profiler.consoleProfileFinished';

    public const EVENT_CONSOLE_PROFILE_STARTED = 'Profiler.consoleProfileStarted';

    public const EVENT_PRECISE_COVERAGE_DELTA_UPDATE = 'Profiler.preciseCoverageDeltaUpdate';
}
