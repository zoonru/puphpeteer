<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Extensions
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function loadUnpacked(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.loadUnpacked', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function uninstall(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.uninstall', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getStorageItems(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.getStorageItems', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeStorageItems(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.removeStorageItems', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearStorageItems(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.clearStorageItems', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setStorageItems(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Extensions.setStorageItems', $params, $cancellation);
    }
}
