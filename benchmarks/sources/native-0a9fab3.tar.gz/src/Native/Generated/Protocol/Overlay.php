<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Overlay
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getHighlightObjectForTest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.getHighlightObjectForTest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getGridHighlightObjectsForTest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.getGridHighlightObjectsForTest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSourceOrderHighlightObjectForTest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.getSourceOrderHighlightObjectForTest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function hideHighlight(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.hideHighlight', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightFrame(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.highlightFrame', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.highlightNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightQuad(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.highlightQuad', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightRect(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.highlightRect', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function highlightSourceOrder(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.highlightSourceOrder', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInspectMode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setInspectMode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowAdHighlights(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowAdHighlights', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPausedInDebuggerMessage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setPausedInDebuggerMessage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowDebugBorders(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowDebugBorders', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowFPSCounter(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowFPSCounter', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowGridOverlays(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowGridOverlays', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowFlexOverlays(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowFlexOverlays', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowScrollSnapOverlays(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowScrollSnapOverlays', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowContainerQueryOverlays(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowContainerQueryOverlays', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowPaintRects(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowPaintRects', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowLayoutShiftRegions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowLayoutShiftRegions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowScrollBottleneckRects(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowScrollBottleneckRects', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowHitTestBorders(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowHitTestBorders', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowWebVitals(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowWebVitals', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowViewportSizeOnResize(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowViewportSizeOnResize', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowHinge(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowHinge', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowIsolatedElements(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowIsolatedElements', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setShowWindowControlsOverlay(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Overlay.setShowWindowControlsOverlay', $params, $cancellation);
    }

    public const EVENT_INSPECT_NODE_REQUESTED = 'Overlay.inspectNodeRequested';

    public const EVENT_NODE_HIGHLIGHT_REQUESTED = 'Overlay.nodeHighlightRequested';

    public const EVENT_SCREENSHOT_REQUESTED = 'Overlay.screenshotRequested';

    public const EVENT_INSPECT_MODE_CANCELED = 'Overlay.inspectModeCanceled';
}
