<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class EventBreakpoints
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function setInstrumentationBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('EventBreakpoints.setInstrumentationBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeInstrumentationBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('EventBreakpoints.removeInstrumentationBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('EventBreakpoints.disable', $params, $cancellation);
    }
}
