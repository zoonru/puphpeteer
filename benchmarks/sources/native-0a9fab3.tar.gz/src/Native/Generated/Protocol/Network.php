<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Network
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function setAcceptedEncodings(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setAcceptedEncodings', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearAcceptedEncodingsOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.clearAcceptedEncodingsOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function canClearBrowserCache(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.canClearBrowserCache', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function canClearBrowserCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.canClearBrowserCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function canEmulateNetworkConditions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.canEmulateNetworkConditions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearBrowserCache(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.clearBrowserCache', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clearBrowserCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.clearBrowserCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function continueInterceptedRequest(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.continueInterceptedRequest', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.deleteCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function emulateNetworkConditions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.emulateNetworkConditions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function emulateNetworkConditionsByRule(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.emulateNetworkConditionsByRule', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function overrideNetworkState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.overrideNetworkState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAllCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getAllCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCertificate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getCertificate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getResponseBody(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getResponseBody', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getRequestPostData(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getRequestPostData', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getResponseBodyForInterception(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getResponseBodyForInterception', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takeResponseBodyForInterceptionAsStream(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.takeResponseBodyForInterceptionAsStream', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function replayXHR(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.replayXHR', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function searchInResponseBody(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.searchInResponseBody', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBlockedURLs(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setBlockedURLs', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBypassServiceWorker(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setBypassServiceWorker', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCacheDisabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setCacheDisabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCookie(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setCookie', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCookies(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setCookies', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setExtraHTTPHeaders(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setExtraHTTPHeaders', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAttachDebugStack(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setAttachDebugStack', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setRequestInterception(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setRequestInterception', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setUserAgentOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setUserAgentOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function streamResourceContent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.streamResourceContent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSecurityIsolationStatus(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.getSecurityIsolationStatus', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enableReportingApi(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.enableReportingApi', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function loadNetworkResource(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.loadNetworkResource', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCookieControls(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Network.setCookieControls', $params, $cancellation);
    }

    public const EVENT_DATA_RECEIVED = 'Network.dataReceived';

    public const EVENT_EVENT_SOURCE_MESSAGE_RECEIVED = 'Network.eventSourceMessageReceived';

    public const EVENT_LOADING_FAILED = 'Network.loadingFailed';

    public const EVENT_LOADING_FINISHED = 'Network.loadingFinished';

    public const EVENT_REQUEST_INTERCEPTED = 'Network.requestIntercepted';

    public const EVENT_REQUEST_SERVED_FROM_CACHE = 'Network.requestServedFromCache';

    public const EVENT_REQUEST_WILL_BE_SENT = 'Network.requestWillBeSent';

    public const EVENT_RESOURCE_CHANGED_PRIORITY = 'Network.resourceChangedPriority';

    public const EVENT_SIGNED_EXCHANGE_RECEIVED = 'Network.signedExchangeReceived';

    public const EVENT_RESPONSE_RECEIVED = 'Network.responseReceived';

    public const EVENT_WEB_SOCKET_CLOSED = 'Network.webSocketClosed';

    public const EVENT_WEB_SOCKET_CREATED = 'Network.webSocketCreated';

    public const EVENT_WEB_SOCKET_FRAME_ERROR = 'Network.webSocketFrameError';

    public const EVENT_WEB_SOCKET_FRAME_RECEIVED = 'Network.webSocketFrameReceived';

    public const EVENT_WEB_SOCKET_FRAME_SENT = 'Network.webSocketFrameSent';

    public const EVENT_WEB_SOCKET_HANDSHAKE_RESPONSE_RECEIVED = 'Network.webSocketHandshakeResponseReceived';

    public const EVENT_WEB_SOCKET_WILL_SEND_HANDSHAKE_REQUEST = 'Network.webSocketWillSendHandshakeRequest';

    public const EVENT_WEB_TRANSPORT_CREATED = 'Network.webTransportCreated';

    public const EVENT_WEB_TRANSPORT_CONNECTION_ESTABLISHED = 'Network.webTransportConnectionEstablished';

    public const EVENT_WEB_TRANSPORT_CLOSED = 'Network.webTransportClosed';

    public const EVENT_DIRECT_T_C_P_SOCKET_CREATED = 'Network.directTCPSocketCreated';

    public const EVENT_DIRECT_T_C_P_SOCKET_OPENED = 'Network.directTCPSocketOpened';

    public const EVENT_DIRECT_T_C_P_SOCKET_ABORTED = 'Network.directTCPSocketAborted';

    public const EVENT_DIRECT_T_C_P_SOCKET_CLOSED = 'Network.directTCPSocketClosed';

    public const EVENT_DIRECT_T_C_P_SOCKET_CHUNK_SENT = 'Network.directTCPSocketChunkSent';

    public const EVENT_DIRECT_T_C_P_SOCKET_CHUNK_RECEIVED = 'Network.directTCPSocketChunkReceived';

    public const EVENT_DIRECT_U_D_P_SOCKET_JOINED_MULTICAST_GROUP = 'Network.directUDPSocketJoinedMulticastGroup';

    public const EVENT_DIRECT_U_D_P_SOCKET_LEFT_MULTICAST_GROUP = 'Network.directUDPSocketLeftMulticastGroup';

    public const EVENT_DIRECT_U_D_P_SOCKET_CREATED = 'Network.directUDPSocketCreated';

    public const EVENT_DIRECT_U_D_P_SOCKET_OPENED = 'Network.directUDPSocketOpened';

    public const EVENT_DIRECT_U_D_P_SOCKET_ABORTED = 'Network.directUDPSocketAborted';

    public const EVENT_DIRECT_U_D_P_SOCKET_CLOSED = 'Network.directUDPSocketClosed';

    public const EVENT_DIRECT_U_D_P_SOCKET_CHUNK_SENT = 'Network.directUDPSocketChunkSent';

    public const EVENT_DIRECT_U_D_P_SOCKET_CHUNK_RECEIVED = 'Network.directUDPSocketChunkReceived';

    public const EVENT_REQUEST_WILL_BE_SENT_EXTRA_INFO = 'Network.requestWillBeSentExtraInfo';

    public const EVENT_RESPONSE_RECEIVED_EXTRA_INFO = 'Network.responseReceivedExtraInfo';

    public const EVENT_RESPONSE_RECEIVED_EARLY_HINTS = 'Network.responseReceivedEarlyHints';

    public const EVENT_TRUST_TOKEN_OPERATION_DONE = 'Network.trustTokenOperationDone';

    public const EVENT_POLICY_UPDATED = 'Network.policyUpdated';

    public const EVENT_REPORTING_API_REPORT_ADDED = 'Network.reportingApiReportAdded';

    public const EVENT_REPORTING_API_REPORT_UPDATED = 'Network.reportingApiReportUpdated';

    public const EVENT_REPORTING_API_ENDPOINTS_CHANGED_FOR_ORIGIN = 'Network.reportingApiEndpointsChangedForOrigin';
}
