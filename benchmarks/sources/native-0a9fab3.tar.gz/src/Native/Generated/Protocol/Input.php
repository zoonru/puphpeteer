<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Input
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function dispatchDragEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.dispatchDragEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dispatchKeyEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.dispatchKeyEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function insertText(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.insertText', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function imeSetComposition(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.imeSetComposition', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dispatchMouseEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.dispatchMouseEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dispatchTouchEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.dispatchTouchEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function cancelDragging(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.cancelDragging', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function emulateTouchFromMouseEvent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.emulateTouchFromMouseEvent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setIgnoreInputEvents(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.setIgnoreInputEvents', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInterceptDrags(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.setInterceptDrags', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function synthesizePinchGesture(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.synthesizePinchGesture', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function synthesizeScrollGesture(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.synthesizeScrollGesture', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function synthesizeTapGesture(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Input.synthesizeTapGesture', $params, $cancellation);
    }

    public const EVENT_DRAG_INTERCEPTED = 'Input.dragIntercepted';
}
