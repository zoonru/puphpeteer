<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Preload
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Preload.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Preload.disable', $params, $cancellation);
    }

    public const EVENT_RULE_SET_UPDATED = 'Preload.ruleSetUpdated';

    public const EVENT_RULE_SET_REMOVED = 'Preload.ruleSetRemoved';

    public const EVENT_PRELOAD_ENABLED_STATE_UPDATED = 'Preload.preloadEnabledStateUpdated';

    public const EVENT_PREFETCH_STATUS_UPDATED = 'Preload.prefetchStatusUpdated';

    public const EVENT_PRERENDER_STATUS_UPDATED = 'Preload.prerenderStatusUpdated';

    public const EVENT_PRELOADING_ATTEMPT_SOURCES_UPDATED = 'Preload.preloadingAttemptSourcesUpdated';
}
