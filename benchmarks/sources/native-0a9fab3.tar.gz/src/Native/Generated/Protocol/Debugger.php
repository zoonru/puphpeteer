<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/js_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Debugger
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function continueToLocation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.continueToLocation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function evaluateOnCallFrame(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.evaluateOnCallFrame', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getPossibleBreakpoints(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.getPossibleBreakpoints', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getScriptSource(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.getScriptSource', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disassembleWasmModule(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.disassembleWasmModule', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function nextWasmDisassemblyChunk(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.nextWasmDisassemblyChunk', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getWasmBytecode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.getWasmBytecode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getStackTrace(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.getStackTrace', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function pause(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.pause', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function pauseOnAsyncCall(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.pauseOnAsyncCall', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.removeBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function restartFrame(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.restartFrame', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resume(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.resume', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function searchInContent(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.searchInContent', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAsyncCallStackDepth(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setAsyncCallStackDepth', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBlackboxExecutionContexts(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBlackboxExecutionContexts', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBlackboxPatterns(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBlackboxPatterns', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBlackboxedRanges(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBlackboxedRanges', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setInstrumentationBreakpoint(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setInstrumentationBreakpoint', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBreakpointByUrl(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBreakpointByUrl', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBreakpointOnFunctionCall(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBreakpointOnFunctionCall', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setBreakpointsActive(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setBreakpointsActive', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPauseOnExceptions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setPauseOnExceptions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setReturnValue(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setReturnValue', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setScriptSource(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setScriptSource', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSkipAllPauses(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setSkipAllPauses', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setVariableValue(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.setVariableValue', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stepInto(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.stepInto', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stepOut(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.stepOut', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stepOver(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Debugger.stepOver', $params, $cancellation);
    }

    public const EVENT_BREAKPOINT_RESOLVED = 'Debugger.breakpointResolved';

    public const EVENT_PAUSED = 'Debugger.paused';

    public const EVENT_RESUMED = 'Debugger.resumed';

    public const EVENT_SCRIPT_FAILED_TO_PARSE = 'Debugger.scriptFailedToParse';

    public const EVENT_SCRIPT_PARSED = 'Debugger.scriptParsed';
}
