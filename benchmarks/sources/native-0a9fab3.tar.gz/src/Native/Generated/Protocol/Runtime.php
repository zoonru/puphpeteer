<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/js_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Runtime
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function awaitPromise(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.awaitPromise', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function callFunctionOn(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.callFunctionOn', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function compileScript(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.compileScript', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function discardConsoleEntries(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.discardConsoleEntries', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function evaluate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.evaluate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getIsolateId(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.getIsolateId', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getHeapUsage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.getHeapUsage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getProperties(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.getProperties', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function globalLexicalScopeNames(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.globalLexicalScopeNames', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function queryObjects(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.queryObjects', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function releaseObject(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.releaseObject', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function releaseObjectGroup(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.releaseObjectGroup', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function runIfWaitingForDebugger(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.runIfWaitingForDebugger', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function runScript(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.runScript', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAsyncCallStackDepth(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.setAsyncCallStackDepth', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setCustomObjectFormatterEnabled(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.setCustomObjectFormatterEnabled', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setMaxCallStackSizeToCapture(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.setMaxCallStackSizeToCapture', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function terminateExecution(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.terminateExecution', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addBinding(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.addBinding', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function removeBinding(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.removeBinding', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getExceptionDetails(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Runtime.getExceptionDetails', $params, $cancellation);
    }

    public const EVENT_BINDING_CALLED = 'Runtime.bindingCalled';

    public const EVENT_CONSOLE_A_P_I_CALLED = 'Runtime.consoleAPICalled';

    public const EVENT_EXCEPTION_REVOKED = 'Runtime.exceptionRevoked';

    public const EVENT_EXCEPTION_THROWN = 'Runtime.exceptionThrown';

    public const EVENT_EXECUTION_CONTEXT_CREATED = 'Runtime.executionContextCreated';

    public const EVENT_EXECUTION_CONTEXT_DESTROYED = 'Runtime.executionContextDestroyed';

    public const EVENT_EXECUTION_CONTEXTS_CLEARED = 'Runtime.executionContextsCleared';

    public const EVENT_INSPECT_REQUESTED = 'Runtime.inspectRequested';
}
