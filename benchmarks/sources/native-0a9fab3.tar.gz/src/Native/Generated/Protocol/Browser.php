<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Browser
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function setPermission(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.setPermission', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function grantPermissions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.grantPermissions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resetPermissions(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.resetPermissions', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDownloadBehavior(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.setDownloadBehavior', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function cancelDownload(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.cancelDownload', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function close(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.close', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function crash(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.crash', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function crashGpuProcess(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.crashGpuProcess', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getVersion(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getVersion', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBrowserCommandLine(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getBrowserCommandLine', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getHistograms(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getHistograms', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getHistogram(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getHistogram', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getWindowBounds(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getWindowBounds', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getWindowForTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.getWindowForTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setWindowBounds(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.setWindowBounds', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setContentsSize(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.setContentsSize', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDockTile(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.setDockTile', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function executeBrowserCommand(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.executeBrowserCommand', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addPrivacySandboxEnrollmentOverride(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.addPrivacySandboxEnrollmentOverride', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function addPrivacySandboxCoordinatorKeyConfig(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Browser.addPrivacySandboxCoordinatorKeyConfig', $params, $cancellation);
    }

    public const EVENT_DOWNLOAD_WILL_BEGIN = 'Browser.downloadWillBegin';

    public const EVENT_DOWNLOAD_PROGRESS = 'Browser.downloadProgress';
}
