<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class FedCm
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function selectAccount(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.selectAccount', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function clickDialogButton(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.clickDialogButton', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function openUrl(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.openUrl', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function dismissDialog(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.dismissDialog', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resetCooldown(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('FedCm.resetCooldown', $params, $cancellation);
    }

    public const EVENT_DIALOG_SHOWN = 'FedCm.dialogShown';

    public const EVENT_DIALOG_CLOSED = 'FedCm.dialogClosed';
}
