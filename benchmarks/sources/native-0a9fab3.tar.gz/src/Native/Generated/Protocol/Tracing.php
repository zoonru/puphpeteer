<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Tracing
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function end(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Tracing.end', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCategories(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Tracing.getCategories', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function recordClockSyncMarker(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Tracing.recordClockSyncMarker', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestMemoryDump(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Tracing.requestMemoryDump', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function start(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Tracing.start', $params, $cancellation);
    }

    public const EVENT_BUFFER_USAGE = 'Tracing.bufferUsage';

    public const EVENT_DATA_COLLECTED = 'Tracing.dataCollected';

    public const EVENT_TRACING_COMPLETE = 'Tracing.tracingComplete';
}
