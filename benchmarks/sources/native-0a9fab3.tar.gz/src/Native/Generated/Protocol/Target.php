<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Target
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function activateTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.activateTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function attachToTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.attachToTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function attachToBrowserTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.attachToBrowserTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function closeTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.closeTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function exposeDevToolsProtocol(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.exposeDevToolsProtocol', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function createBrowserContext(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.createBrowserContext', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getBrowserContexts(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.getBrowserContexts', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function createTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.createTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function detachFromTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.detachFromTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disposeBrowserContext(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.disposeBrowserContext', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getTargetInfo(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.getTargetInfo', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getTargets(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.getTargets', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function sendMessageToTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.sendMessageToTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setAutoAttach(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.setAutoAttach', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function autoAttachRelated(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.autoAttachRelated', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setDiscoverTargets(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.setDiscoverTargets', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setRemoteLocations(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.setRemoteLocations', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getDevToolsTarget(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.getDevToolsTarget', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function openDevTools(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Target.openDevTools', $params, $cancellation);
    }

    public const EVENT_ATTACHED_TO_TARGET = 'Target.attachedToTarget';

    public const EVENT_DETACHED_FROM_TARGET = 'Target.detachedFromTarget';

    public const EVENT_RECEIVED_MESSAGE_FROM_TARGET = 'Target.receivedMessageFromTarget';

    public const EVENT_TARGET_CREATED = 'Target.targetCreated';

    public const EVENT_TARGET_DESTROYED = 'Target.targetDestroyed';

    public const EVENT_TARGET_CRASHED = 'Target.targetCrashed';

    public const EVENT_TARGET_INFO_CHANGED = 'Target.targetInfoChanged';
}
