<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/js_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class HeapProfiler
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function addInspectedHeapObject(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.addInspectedHeapObject', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function collectGarbage(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.collectGarbage', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getHeapObjectId(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.getHeapObjectId', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getObjectByHeapObjectId(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.getObjectByHeapObjectId', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getSamplingProfile(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.getSamplingProfile', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startSampling(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.startSampling', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startTrackingHeapObjects(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.startTrackingHeapObjects', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopSampling(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.stopSampling', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopTrackingHeapObjects(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.stopTrackingHeapObjects', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function takeHeapSnapshot(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('HeapProfiler.takeHeapSnapshot', $params, $cancellation);
    }

    public const EVENT_ADD_HEAP_SNAPSHOT_CHUNK = 'HeapProfiler.addHeapSnapshotChunk';

    public const EVENT_HEAP_STATS_UPDATE = 'HeapProfiler.heapStatsUpdate';

    public const EVENT_LAST_SEEN_OBJECT_ID = 'HeapProfiler.lastSeenObjectId';

    public const EVENT_REPORT_HEAP_SNAPSHOT_PROGRESS = 'HeapProfiler.reportHeapSnapshotProgress';

    public const EVENT_RESET_PROFILES = 'HeapProfiler.resetProfiles';
}
