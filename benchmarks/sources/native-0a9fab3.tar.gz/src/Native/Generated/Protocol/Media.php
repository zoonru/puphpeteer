<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Media
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Media.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Media.disable', $params, $cancellation);
    }

    public const EVENT_PLAYER_PROPERTIES_CHANGED = 'Media.playerPropertiesChanged';

    public const EVENT_PLAYER_EVENTS_ADDED = 'Media.playerEventsAdded';

    public const EVENT_PLAYER_MESSAGES_LOGGED = 'Media.playerMessagesLogged';

    public const EVENT_PLAYER_ERRORS_RAISED = 'Media.playerErrorsRaised';

    public const EVENT_PLAYER_CREATED = 'Media.playerCreated';
}
