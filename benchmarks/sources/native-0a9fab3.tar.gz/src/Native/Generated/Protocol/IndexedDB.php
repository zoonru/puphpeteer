<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class IndexedDB
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function clearObjectStore(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.clearObjectStore', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteDatabase(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.deleteDatabase', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function deleteObjectStoreEntries(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.deleteObjectStoreEntries', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestData(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.requestData', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getMetadata(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.getMetadata', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestDatabase(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.requestDatabase', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function requestDatabaseNames(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('IndexedDB.requestDatabaseNames', $params, $cancellation);
    }
}
