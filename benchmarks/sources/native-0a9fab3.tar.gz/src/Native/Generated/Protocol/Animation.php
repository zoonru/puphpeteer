<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Animation
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getCurrentTime(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.getCurrentTime', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getPlaybackRate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.getPlaybackRate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function releaseAnimations(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.releaseAnimations', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function resolveAnimation(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.resolveAnimation', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function seekAnimations(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.seekAnimations', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPaused(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.setPaused', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setPlaybackRate(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.setPlaybackRate', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setTiming(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Animation.setTiming', $params, $cancellation);
    }

    public const EVENT_ANIMATION_CANCELED = 'Animation.animationCanceled';

    public const EVENT_ANIMATION_CREATED = 'Animation.animationCreated';

    public const EVENT_ANIMATION_STARTED = 'Animation.animationStarted';

    public const EVENT_ANIMATION_UPDATED = 'Animation.animationUpdated';
}
