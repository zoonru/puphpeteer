<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class PWA
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function getOsAppState(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.getOsAppState', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function install(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.install', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function uninstall(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.uninstall', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function launch(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.launch', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function launchFilesInApp(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.launchFilesInApp', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function openCurrentPageInApp(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.openCurrentPageInApp', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function changeAppUserSettings(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('PWA.changeAppUserSettings', $params, $cancellation);
    }
}
