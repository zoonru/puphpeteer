<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Cast
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setSinkToUse(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.setSinkToUse', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startDesktopMirroring(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.startDesktopMirroring', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function startTabMirroring(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.startTabMirroring', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function stopCasting(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Cast.stopCasting', $params, $cancellation);
    }

    public const EVENT_SINKS_UPDATED = 'Cast.sinksUpdated';

    public const EVENT_ISSUE_UPDATED = 'Cast.issueUpdated';
}
