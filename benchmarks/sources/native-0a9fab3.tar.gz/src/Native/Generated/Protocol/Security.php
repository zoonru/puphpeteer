<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Security
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Security.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Security.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setIgnoreCertificateErrors(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Security.setIgnoreCertificateErrors', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function handleCertificateError(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Security.handleCertificateError', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function setOverrideCertificateErrors(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Security.setOverrideCertificateErrors', $params, $cancellation);
    }

    public const EVENT_CERTIFICATE_ERROR = 'Security.certificateError';

    public const EVENT_VISIBLE_SECURITY_STATE_CHANGED = 'Security.visibleSecurityStateChanged';

    public const EVENT_SECURITY_STATE_CHANGED = 'Security.securityStateChanged';
}
