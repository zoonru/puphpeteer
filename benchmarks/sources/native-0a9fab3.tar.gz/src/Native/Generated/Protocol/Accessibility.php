<?php

declare(strict_types=1);

// Copyright 2014 The Chromium Authors. All rights reserved.
// BSD-style license: see LICENSE-CDP.
// Generated from puppeteer-core 24.36.1: devtools-protocol/json/browser_protocol.json. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Protocol;

use Amp\Cancellation;
use Amp\Future;
use Nesk\Puphpeteer\Native\Session;

final class Accessibility
{
    public function __construct(private Session $session) {}

    /** @return Future<array<string, mixed>> */
    public function disable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.disable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function enable(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.enable', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getPartialAXTree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.getPartialAXTree', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getFullAXTree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.getFullAXTree', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getRootAXNode(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.getRootAXNode', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getAXNodeAndAncestors(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.getAXNodeAndAncestors', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function getChildAXNodes(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.getChildAXNodes', $params, $cancellation);
    }

    /** @return Future<array<string, mixed>> */
    public function queryAXTree(array $params = [], ?Cancellation $cancellation = null): Future
    {
        return $this->session->send('Accessibility.queryAXTree', $params, $cancellation);
    }

    public const EVENT_LOAD_COMPLETE = 'Accessibility.loadComplete';

    public const EVENT_NODES_UPDATED = 'Accessibility.nodesUpdated';
}
