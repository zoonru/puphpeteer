<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Input.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait MouseCommands
{
    private static function getFlag(mixed $button): mixed
    {
        $_nativeSwitch1 = $button;
        if (Js::strictEqual($_nativeSwitch1, Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Left'))) {
            return Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Left');
        }
        else if (Js::strictEqual($_nativeSwitch1, Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Right'))) {
            return Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Right');
        }
        else if (Js::strictEqual($_nativeSwitch1, Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Middle'))) {
            return Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Middle');
        }
        else if (Js::strictEqual($_nativeSwitch1, Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Back'))) {
            return Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Back');
        }
        else if (Js::strictEqual($_nativeSwitch1, Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Forward'))) {
            return Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Forward');
        }
        return UndefinedValue::Value;
    }
    private static function getButtonFromPressedButtons(mixed $buttons): mixed
    {
        if (Js::truthy(Js::bitwise('&', $buttons, Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Left')))) {
            return Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Left');
        } else {
            if (Js::truthy(Js::bitwise('&', $buttons, Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Right')))) {
                return Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Right');
            } else {
                if (Js::truthy(Js::bitwise('&', $buttons, Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Middle')))) {
                    return Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Middle');
                } else {
                    if (Js::truthy(Js::bitwise('&', $buttons, Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Back')))) {
                        return Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Back');
                    } else {
                        if (Js::truthy(Js::bitwise('&', $buttons, Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Forward')))) {
                            return Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Forward');
                        }
                    }
                }
            }
        }
        return 'none';
    }
    private function initializeMouseState(): void
    {
        $this->mouseState = Js::object(['position' => Js::object(['x' => 0, 'y' => 0]), 'buttons' => Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'None')]);
        $this->transactions = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
    }

    public function updateClient(mixed $client): mixed
    {
        $this->client = $client;
        return UndefinedValue::Value;
    }

    private function CdpMouse_state(): mixed
    {
        return Js::assign(Js::assign(Js::object([]), $this->mouseState), ...Js::iterate($this->transactions));
    }

    private function CdpMouse_createTransaction(): mixed
    {
        $transaction = Js::object([]);
        Js::invoke($this->transactions, 'push', [$transaction]);
        $popTransaction = function () use ($transaction) {
    Js::invoke($this->transactions, 'splice', [Js::invoke($this->transactions, 'indexOf', [$transaction]), 1]);
    return UndefinedValue::Value;
};
        return Js::object(['update' => function (mixed $updates) use ($transaction) {
    Js::assign($transaction, $updates);
    return UndefinedValue::Value;
}, 'commit' => function () use ($transaction, $popTransaction) {
    $this->mouseState = Js::assign(Js::object([]), $this->mouseState, $transaction);
    $popTransaction();
    return UndefinedValue::Value;
}, 'rollback' => $popTransaction]);
    }

    private function CdpMouse_withTransaction(mixed $action): mixed
    {
        return Js::async(function () use ($action) {
            $_nativeBinding1 = $this->CdpMouse_createTransaction();
            $update = Js::get($_nativeBinding1, 'update');
            $commit = Js::get($_nativeBinding1, 'commit');
            $rollback = Js::get($_nativeBinding1, 'rollback');
            try {
                Js::await($action($update));
                $commit();
            } catch (\Throwable $error) {
                $rollback();
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    public function reset(): mixed
    {
        return Js::async(function () {
            $actions = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
            foreach (Js::iterate((new \Nesk\Puphpeteer\Native\Runtime\JsArray([new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Left'), Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Left')]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Middle'), Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Middle')]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Right'), Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Right')]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Forward'), Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Forward')]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(['None' => 0, 'Left' => 1, 'Right' => 2, 'Middle' => 4, 'Back' => 8, 'Forward' => 16], 'Back'), Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Back')])]))) as $_nativeItem2) {
                $flag = Js::get($_nativeItem2, 0);
                $button = Js::get($_nativeItem2, 1);
                if (Js::truthy(Js::bitwise('&', Js::get($this->CdpMouse_state(), 'buttons'), $flag))) {
                    Js::invoke($actions, 'push', [$this->up(Js::object(['button' => $button]))]);
                }
            }
            if (Js::truthy(Js::logicalOr(!Js::strictEqual(Js::get(Js::get($this->CdpMouse_state(), 'position'), 'x'), 0), fn () => !Js::strictEqual(Js::get(Js::get($this->CdpMouse_state(), 'position'), 'y'), 0)))) {
                Js::invoke($actions, 'push', [$this->move(0, 0)]);
            }
            Js::await(Js::all($actions));
            return UndefinedValue::Value;
        });
    }

    public function move(mixed $x, mixed $y, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($x, $y, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding3 = $options;
            $steps = Js::defaultValue(Js::get($_nativeBinding3, 'steps'), fn () => 1);
            $from = Js::get($this->CdpMouse_state(), 'position');
            $to = Js::object(['x' => $x, 'y' => $y]);
            for ($i = 1; Js::truthy(Js::numeric('<=', $i, $steps)); $i++) {
                Js::await($this->CdpMouse_withTransaction(function (mixed $updateState) use ($steps, $from, $to, $i) {
    $updateState(Js::object(['position' => Js::object(['x' => Js::add(Js::get($from, 'x'), Js::numeric('*', (Js::numeric('-', Js::get($to, 'x'), Js::get($from, 'x'))), (Js::numeric('/', $i, $steps)))), 'y' => Js::add(Js::get($from, 'y'), Js::numeric('*', (Js::numeric('-', Js::get($to, 'y'), Js::get($from, 'y'))), (Js::numeric('/', $i, $steps))))])]));
    $_nativeBinding4 = $this->CdpMouse_state();
    $buttons = Js::get($_nativeBinding4, 'buttons');
    $position = Js::get($_nativeBinding4, 'position');
    return Js::invoke($this->client, 'send', ['Input.dispatchMouseEvent', Js::assign(Js::object([]), Js::object(['type' => 'mouseMoved']), Js::object(['modifiers' => Js::get($this->keyboard, '_modifiers')]), Js::object(['buttons' => $buttons]), Js::object(['button' => self::getButtonFromPressedButtons($buttons)]), $position)]);
}));
            }
            return UndefinedValue::Value;
        });
    }

    public function down(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding5 = $options;
            $button = Js::defaultValue(Js::get($_nativeBinding5, 'button'), fn () => Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Left'));
            $clickCount = Js::defaultValue(Js::get($_nativeBinding5, 'clickCount'), fn () => 1);
            $flag = self::getFlag($button);
            if (Js::truthy(!Js::truthy($flag))) {
                throw new \RuntimeException(('Unsupported mouse button: ' . Js::string($button) . ''));
            }
            if (Js::truthy(Js::bitwise('&', Js::get($this->CdpMouse_state(), 'buttons'), $flag))) {
                throw new \RuntimeException(('\'' . Js::string($button) . '\' is already pressed.'));
            }
            Js::await($this->CdpMouse_withTransaction(function (mixed $updateState) use ($button, $clickCount, $flag) {
    $updateState(Js::object(['buttons' => Js::bitwise('|', Js::get($this->CdpMouse_state(), 'buttons'), $flag)]));
    $_nativeBinding6 = $this->CdpMouse_state();
    $buttons = Js::get($_nativeBinding6, 'buttons');
    $position = Js::get($_nativeBinding6, 'position');
    return Js::invoke($this->client, 'send', ['Input.dispatchMouseEvent', Js::assign(Js::object([]), Js::object(['type' => 'mousePressed']), Js::object(['modifiers' => Js::get($this->keyboard, '_modifiers')]), Js::object(['clickCount' => $clickCount]), Js::object(['buttons' => $buttons]), Js::object(['button' => $button]), $position)]);
}));
            return UndefinedValue::Value;
        });
    }

    public function up(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding7 = $options;
            $button = Js::defaultValue(Js::get($_nativeBinding7, 'button'), fn () => Js::get(['Left' => 'left', 'Right' => 'right', 'Middle' => 'middle', 'Back' => 'back', 'Forward' => 'forward'], 'Left'));
            $clickCount = Js::defaultValue(Js::get($_nativeBinding7, 'clickCount'), fn () => 1);
            $flag = self::getFlag($button);
            if (Js::truthy(!Js::truthy($flag))) {
                throw new \RuntimeException(('Unsupported mouse button: ' . Js::string($button) . ''));
            }
            if (Js::truthy(!Js::truthy((Js::bitwise('&', Js::get($this->CdpMouse_state(), 'buttons'), $flag))))) {
                throw new \RuntimeException(('\'' . Js::string($button) . '\' is not pressed.'));
            }
            Js::await($this->CdpMouse_withTransaction(function (mixed $updateState) use ($button, $clickCount, $flag) {
    $updateState(Js::object(['buttons' => Js::bitwise('&', Js::get($this->CdpMouse_state(), 'buttons'), Js::bitNot($flag))]));
    $_nativeBinding8 = $this->CdpMouse_state();
    $buttons = Js::get($_nativeBinding8, 'buttons');
    $position = Js::get($_nativeBinding8, 'position');
    return Js::invoke($this->client, 'send', ['Input.dispatchMouseEvent', Js::assign(Js::object([]), Js::object(['type' => 'mouseReleased']), Js::object(['modifiers' => Js::get($this->keyboard, '_modifiers')]), Js::object(['clickCount' => $clickCount]), Js::object(['buttons' => $buttons]), Js::object(['button' => $button]), $position)]);
}));
            return UndefinedValue::Value;
        });
    }

    public function click(mixed $x, mixed $y, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($x, $y, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding9 = $options;
            $delay = Js::get($_nativeBinding9, 'delay');
            $count = Js::defaultValue(Js::get($_nativeBinding9, 'count'), fn () => 1);
            $clickCount = Js::defaultValue(Js::get($_nativeBinding9, 'clickCount'), fn () => $count);
            if (Js::truthy(Js::numeric('<', $count, 1))) {
                throw new \RuntimeException('Click must occur a positive number of times.');
            }
            $actions = new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->move($x, $y)]);
            if (Js::truthy(Js::strictEqual($clickCount, $count))) {
                for ($i = 1; Js::truthy(Js::numeric('<', $i, $count)); ++$i) {
                    Js::invoke($actions, 'push', [$this->down(Js::assign(Js::object([]), $options, Js::object(['clickCount' => $i]))), $this->up(Js::assign(Js::object([]), $options, Js::object(['clickCount' => $i])))]);
                }
            }
            Js::invoke($actions, 'push', [$this->down(Js::assign(Js::object([]), $options, Js::object(['clickCount' => $clickCount])))]);
            if (Js::truthy(Js::strictEqual(Js::typeOf($delay), 'number'))) {
                Js::await(Js::all($actions));
                Js::set($actions, 'length', 0);
                Js::await(Js::delay($delay));
            }
            Js::invoke($actions, 'push', [$this->up(Js::assign(Js::object([]), $options, Js::object(['clickCount' => $clickCount])))]);
            Js::await(Js::all($actions));
            return UndefinedValue::Value;
        });
    }

    public function wheel(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding10 = $options;
            $deltaX = Js::defaultValue(Js::get($_nativeBinding10, 'deltaX'), fn () => 0);
            $deltaY = Js::defaultValue(Js::get($_nativeBinding10, 'deltaY'), fn () => 0);
            $_nativeBinding11 = $this->CdpMouse_state();
            $position = Js::get($_nativeBinding11, 'position');
            $buttons = Js::get($_nativeBinding11, 'buttons');
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchMouseEvent', Js::assign(Js::object([]), Js::object(['type' => 'mouseWheel']), Js::object(['pointerType' => 'mouse']), Js::object(['modifiers' => Js::get($this->keyboard, '_modifiers')]), Js::object(['deltaY' => $deltaY]), Js::object(['deltaX' => $deltaX]), Js::object(['buttons' => $buttons]), $position)]));
            return UndefinedValue::Value;
        });
    }

    public function drag(mixed $start, mixed $target): mixed
    {
        return Js::async(function () use ($start, $target) {
            $promise = Js::eventOnce($this->client, 'Input.dragIntercepted', 'data');
            Js::await($this->move(Js::get($start, 'x'), Js::get($start, 'y')));
            Js::await($this->down());
            Js::await($this->move(Js::get($target, 'x'), Js::get($target, 'y')));
            return Js::await($promise);
        });
    }

    public function dragEnter(mixed $target, mixed $data): mixed
    {
        return Js::async(function () use ($target, $data) {
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchDragEvent', Js::object(['type' => 'dragEnter', 'x' => Js::get($target, 'x'), 'y' => Js::get($target, 'y'), 'modifiers' => Js::get($this->keyboard, '_modifiers'), 'data' => $data])]));
            return UndefinedValue::Value;
        });
    }

    public function dragOver(mixed $target, mixed $data): mixed
    {
        return Js::async(function () use ($target, $data) {
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchDragEvent', Js::object(['type' => 'dragOver', 'x' => Js::get($target, 'x'), 'y' => Js::get($target, 'y'), 'modifiers' => Js::get($this->keyboard, '_modifiers'), 'data' => $data])]));
            return UndefinedValue::Value;
        });
    }

    public function drop(mixed $target, mixed $data): mixed
    {
        return Js::async(function () use ($target, $data) {
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchDragEvent', Js::object(['type' => 'drop', 'x' => Js::get($target, 'x'), 'y' => Js::get($target, 'y'), 'modifiers' => Js::get($this->keyboard, '_modifiers'), 'data' => $data])]));
            return UndefinedValue::Value;
        });
    }

    public function dragAndDrop(mixed $start, mixed $target, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($start, $target, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding12 = $options;
            $delay = Js::defaultValue(Js::get($_nativeBinding12, 'delay'), fn () => null);
            $data = Js::await($this->drag($start, $target));
            Js::await($this->dragEnter($target, $data));
            Js::await($this->dragOver($target, $data));
            if (Js::truthy($delay)) {
                Js::await(Js::delay($delay));
            }
            Js::await($this->drop($target, $data));
            Js::await($this->up());
            return UndefinedValue::Value;
        });
    }
}
