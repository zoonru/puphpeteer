<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Browser.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait BrowserVersionCommands
{

    public function version(): mixed
    {
        return Js::async(function () {
            $version = Js::await($this->CdpBrowser_getVersion());
            return Js::get($version, 'product');
        });
    }

    public function userAgent(): mixed
    {
        return Js::async(function () {
            $version = Js::await($this->CdpBrowser_getVersion());
            return Js::get($version, 'userAgent');
        });
    }

    private function CdpBrowser_getVersion(): mixed
    {
        return Js::invoke($this->connection, 'send', ['Browser.getVersion']);
    }
}
