<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait ExecutionUtilityCommands
{
    private mixed $utilityBindingsInstalled = false;
    private mixed $utility = UndefinedValue::Value;
    public function sourceUtility(): mixed
    {
        $promise = (Js::resolve());
        if (Js::truthy(!Js::truthy($this->utilityBindingsInstalled))) {
            $promise = Js::all([$this->ExecutionContext_addBindingWithoutThrowing(\Nesk\Puphpeteer\Native\Runtime\InjectedUtility::queryOneBinding()), $this->ExecutionContext_addBindingWithoutThrowing(\Nesk\Puphpeteer\Native\Runtime\InjectedUtility::queryAllBinding())]);
            $this->utilityBindingsInstalled = true;
        }
        Js::invoke(\Nesk\Puphpeteer\Native\Runtime\InjectedUtility::injector(), 'inject', [function (mixed $script) use ($promise) {
    if (Js::truthy($this->utility)) {
        Js::discard(Js::invoke($this->utility, 'then', [function (mixed $handle) {
    Js::discard(Js::invoke($handle, 'dispose', []));
    return UndefinedValue::Value;
}]));
    }
    $this->utility = Js::invoke($promise, 'then', [function () use ($script) {
    return ($this->evaluateHandle($script));
}]);
    return UndefinedValue::Value;
}, !Js::truthy($this->utility)]);
        return ($this->utility);
    }
    private function ExecutionContext_addBindingWithoutThrowing(mixed $binding): mixed
    {
        return Js::async(function () use ($binding) {
            try {
                Js::await($this->installUtilityBinding($binding));
            } catch (\Throwable $err) {
                Js::debugError($err);
            }
            return UndefinedValue::Value;
        });
    }
}
