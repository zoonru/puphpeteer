<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageNetworkCommands
{

    public function setExtraHTTPHeaders(mixed $headers): mixed
    {
        return Js::async(function () use ($headers) {
            return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setExtraHTTPHeaders', [$headers]));
        });
    }

    public function setOfflineMode(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setOfflineMode', [$enabled]));
        });
    }

    public function emulateNetworkConditions(mixed $networkConditions): mixed
    {
        return Js::async(function () use ($networkConditions) {
            return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'emulateNetworkConditions', [$networkConditions]));
        });
    }

    public function setUserAgent(mixed $userAgentOrOptions, mixed $userAgentMetadata = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($userAgentOrOptions, $userAgentMetadata) {
            if (Js::truthy(Js::strictEqual(Js::typeOf($userAgentOrOptions), 'string'))) {
                return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setUserAgent', [$userAgentOrOptions, $userAgentMetadata]));
            } else {
                $userAgent = Js::coalesce(Js::get($userAgentOrOptions, 'userAgent'), fn () => (Js::await(Js::invoke($this->browser(), 'userAgent', []))));
                return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setUserAgent', [$userAgent, Js::get($userAgentOrOptions, 'userAgentMetadata'), Js::get($userAgentOrOptions, 'platform')]));
            }
        });
    }

    public function setCacheEnabled(mixed $enabled = true): mixed
    {
        return Js::async(function () use ($enabled) {
            Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setCacheEnabled', [$enabled]));
            return UndefinedValue::Value;
        });
    }

    public function setBypassServiceWorker(mixed $bypass): mixed
    {
        return Js::async(function () use ($bypass) {
            $this->serviceWorkerBypassed = $bypass;
            return Js::await(Js::invoke($this->session, 'send', ['Network.setBypassServiceWorker', Js::object(['bypass' => $bypass])]));
        });
    }

    public function isServiceWorkerBypassed(): mixed
    {
        return $this->serviceWorkerBypassed;
    }

    public function authenticate(mixed $credentials): mixed
    {
        return Js::async(function () use ($credentials) {
            return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'authenticate', [$credentials]));
        });
    }

    public function setRequestInterception(mixed $value): mixed
    {
        return Js::async(function () use ($value) {
            return Js::await(Js::invoke(Js::get($this->frameManager, 'networkManager'), 'setRequestInterception', [$value]));
        });
    }
}
