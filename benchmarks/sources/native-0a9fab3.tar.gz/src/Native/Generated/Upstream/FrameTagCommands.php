<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameTagCommands
{

    public function addScriptTag(mixed $options): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($options) {
            $_nativeBinding1 = $options;
            $content = Js::defaultValue(Js::get($_nativeBinding1, 'content'), fn () => '');
            $type = Js::get($_nativeBinding1, 'type');
            $_nativeBinding2 = $options;
            $path = Js::get($_nativeBinding2, 'path');
            if (Js::truthy(!Js::strictEqual(Js::add(Js::add((int) (!Js::truthy(!Js::truthy(Js::get($options, 'url')))), (int) (!Js::truthy(!Js::truthy($path)))), (int) (!Js::truthy(!Js::truthy($content)))), 1))) {
                throw new \Nesk\Puphpeteer\Native\Runtime\JsError('Exactly one of `url`, `path`, or `content` must be specified.');
            }
            if (Js::truthy($path)) {
                $content = Js::await(\Nesk\Puphpeteer\Native\Runtime\NodeFileSystem::readFile($path, 'utf8'));
                $content = Js::add($content, ('//# sourceURL=' . Js::string(Js::invoke($path, 'replace', [new \Nesk\Puphpeteer\Native\Runtime\JsRegExp('/\\n/', true), ''])) . ''));
            }
            $type = Js::coalesce($type, fn () => 'text/javascript');
            return Js::await(Js::invoke($this->mainRealm(), 'transferHandle', [Js::await(Js::invoke($this->isolatedRealm(), 'evaluateHandle', [new \Nesk\Puphpeteer\Native\JsFunction('async ({ url, id, type, content }) => {
    return await new Promise((resolve, reject) => {
        const script = document.createElement(\'script\');
        script.type = type;
        script.text = content;
        script.addEventListener(\'error\', event => {
            reject(new Error(event.message ?? \'Could not load script\'));
        }, { once: true });
        if (id) {
            script.id = id;
        }
        if (url) {
            script.src = url;
            script.addEventListener(\'load\', () => {
                resolve(script);
            }, { once: true });
            document.head.appendChild(script);
        }
        else {
            document.head.appendChild(script);
            resolve(script);
        }
    });
}'), Js::assign(Js::object([]), $options, Js::object(['type' => $type]), Js::object(['content' => $content]))]))]));
        });
    }

    public function addStyleTag(mixed $options): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($options) {
            if (is_array($options)) { $options = (object) $options; }
            $_nativeBinding3 = $options;
            $content = Js::defaultValue(Js::get($_nativeBinding3, 'content'), fn () => '');
            $_nativeBinding4 = $options;
            $path = Js::get($_nativeBinding4, 'path');
            if (Js::truthy(!Js::strictEqual(Js::add(Js::add((int) (!Js::truthy(!Js::truthy(Js::get($options, 'url')))), (int) (!Js::truthy(!Js::truthy($path)))), (int) (!Js::truthy(!Js::truthy($content)))), 1))) {
                throw new \Nesk\Puphpeteer\Native\Runtime\JsError('Exactly one of `url`, `path`, or `content` must be specified.');
            }
            if (Js::truthy($path)) {
                $content = Js::await(\Nesk\Puphpeteer\Native\Runtime\NodeFileSystem::readFile($path, 'utf8'));
                $content = Js::add($content, Js::add(Js::add('/*# sourceURL=', Js::invoke($path, 'replace', [new \Nesk\Puphpeteer\Native\Runtime\JsRegExp('/\\n/', true), ''])), '*/'));
                Js::set($options, 'content', $content);
            }
            return Js::await(Js::invoke($this->mainRealm(), 'transferHandle', [Js::await(Js::invoke($this->isolatedRealm(), 'evaluateHandle', [new \Nesk\Puphpeteer\Native\JsFunction('async ({ url, content }) => {
    return await new Promise((resolve, reject) => {
        let element;
        if (!url) {
            element = document.createElement(\'style\');
            element.appendChild(document.createTextNode(content));
        }
        else {
            const link = document.createElement(\'link\');
            link.rel = \'stylesheet\';
            link.href = url;
            element = link;
        }
        element.addEventListener(\'load\', () => {
            resolve(element);
        }, { once: true });
        element.addEventListener(\'error\', event => {
            reject(new Error(event.message ?? \'Could not load style\'));
        }, { once: true });
        document.head.appendChild(element);
        return element;
    });
}'), $options]))]));
        });
    }
}
