<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/ElementHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait ElementInputCommands
{

    public function type(mixed $text, mixed $options = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($text, $options) {
            Js::await($this->focus());
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'keyboard'), 'type', [$text, $options]));
            return UndefinedValue::Value;
        });
    }

    public function press(mixed $key, mixed $options = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($key, $options) {
            Js::await($this->focus());
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'keyboard'), 'press', [$key, $options]));
            return UndefinedValue::Value;
        });
    }
}
