<?php

declare(strict_types=1);

/**
MIT License

Copyright (c) 2021 Jason Miller

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
// Generated from puppeteer-core 24.36.1: ../lib/esm/third_party/mitt/mitt.js. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class Mitt
{
    public static function mitt_default(mixed $n): mixed
    {
        return Js::object(['all' => $n = Js::logicalOr($n, fn () => new \Nesk\Puphpeteer\Native\Runtime\JsMap()), 'on' => function (mixed $t, mixed $e) use ($n) {
    $i = Js::invoke($n, 'get', [$t]);
    (Js::truthy($i) ? Js::invoke($i, 'push', [$e]) : Js::invoke($n, 'set', [$t, new \Nesk\Puphpeteer\Native\Runtime\JsArray([$e])]));
    return UndefinedValue::Value;
}, 'off' => function (mixed $t, mixed $e) use ($n) {
    $i = Js::invoke($n, 'get', [$t]);
    Js::logicalAnd($i, fn () => ((Js::truthy($e) ? Js::invoke($i, 'splice', [Js::unsignedShift(Js::invoke($i, 'indexOf', [$e]), 0), 1]) : Js::invoke($n, 'set', [$t, new \Nesk\Puphpeteer\Native\Runtime\JsArray([])]))));
    return UndefinedValue::Value;
}, 'emit' => function (mixed $t, mixed $e) use ($n) {
    $i = Js::invoke($n, 'get', [$t]);
    Js::logicalAnd($i, fn () => Js::invoke(Js::invoke($i, 'slice', []), 'map', [function (mixed $n2) use ($e) {
    Js::call($n2, [$e]);
    return UndefinedValue::Value;
}]));
    Js::logicalAnd(($i = Js::invoke($n, 'get', ['*'])), fn () => Js::invoke(Js::invoke($i, 'slice', []), 'map', [function (mixed $n2) use ($t, $e) {
    Js::call($n2, [$t, $e]);
    return UndefinedValue::Value;
}]));
    return UndefinedValue::Value;
}]);
    }
}
