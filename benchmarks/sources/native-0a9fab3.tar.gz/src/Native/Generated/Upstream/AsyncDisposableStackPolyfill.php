<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/disposable.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class AsyncDisposableStackPolyfill implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject, \Nesk\Puphpeteer\Native\Runtime\JsSymbolObject
{
    private mixed $AsyncDisposableStackPolyfill_disposed;
    private mixed $AsyncDisposableStackPolyfill_stack;
    public mixed $sourceStringTag;

    public function disposed(): mixed
    {
        return $this->AsyncDisposableStackPolyfill_disposed;
    }

    public function disposeAsync(): mixed
    {
        return Js::async(function () {
            Js::await($this->disposeResourcesAsync());
            return UndefinedValue::Value;
        });
    }

    public function use(mixed $value): mixed
    {
        if (Js::truthy($value)) {
            $asyncDispose = Js::get((($value)), \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose);
            $dispose = Js::get((($value)), \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose);
            if (Js::truthy(Js::strictEqual(Js::typeOf($asyncDispose), 'function'))) {
                Js::invoke($this->AsyncDisposableStackPolyfill_stack, 'push', [($value)]);
            } else {
                if (Js::truthy(Js::strictEqual(Js::typeOf($dispose), 'function'))) {
                    Js::invoke($this->AsyncDisposableStackPolyfill_stack, 'push', [new \Nesk\Puphpeteer\Native\Runtime\SymbolObject([[\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose, function () use ($value) {
    return Js::async(function () use ($value) {
    Js::call(Js::get((($value)), \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose), []);
    return UndefinedValue::Value;
    });
}]])]);
                }
            }
        }
        return $value;
    }

    public function adopt(mixed $value, mixed $onDispose): mixed
    {
        Js::invoke($this->AsyncDisposableStackPolyfill_stack, 'push', [new \Nesk\Puphpeteer\Native\Runtime\SymbolObject([[\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose, function () use ($value, $onDispose) {
    return $onDispose($value);
}]])]);
        return $value;
    }

    public function defer(mixed $onDispose): mixed
    {
        Js::invoke($this->AsyncDisposableStackPolyfill_stack, 'push', [new \Nesk\Puphpeteer\Native\Runtime\SymbolObject([[\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose, function () use ($onDispose) {
    return $onDispose();
}]])]);
        return UndefinedValue::Value;
    }

    public function move(): mixed
    {
        if (Js::truthy($this->AsyncDisposableStackPolyfill_disposed)) {
            throw new \Nesk\Puphpeteer\Native\Runtime\ReferenceError('A disposed stack can not use anything new');
        }
        $stack = new AsyncDisposableStackPolyfill();
        ($stack)->AsyncDisposableStackPolyfill_stack = $this->AsyncDisposableStackPolyfill_stack;
        $this->AsyncDisposableStackPolyfill_stack = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->AsyncDisposableStackPolyfill_disposed = true;
        return $stack;
    }

    public function disposeResourcesAsync(): mixed
    {
        return Js::async(function () {
            if (Js::truthy($this->AsyncDisposableStackPolyfill_disposed)) {
                return UndefinedValue::Value;
            }
            $this->AsyncDisposableStackPolyfill_disposed = true;
            $errors = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
            foreach (Js::iterate(Js::invoke($this->AsyncDisposableStackPolyfill_stack, 'reverse', [])) as $resource) {
                try {
                    Js::await(Js::call(Js::get($resource, \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose), []));
                } catch (\Throwable $e) {
                    Js::invoke($errors, 'push', [$e]);
                }
            }
            if (Js::truthy(Js::strictEqual(Js::get($errors, 'length'), 1))) {
                throw Js::get($errors, 0);
            } else {
                if (Js::truthy(Js::numeric('>', Js::get($errors, 'length'), 1))) {
                    $suppressed = null;
                    foreach (Js::iterate($errors) as $error) {
                        if (Js::truthy(Js::strictEqual($suppressed, null))) {
                            $suppressed = $error;
                        } else {
                            $suppressed = new SuppressedErrorPolyfill($error, $suppressed);
                        }
                    }
                    throw $suppressed;
                }
            }
            return UndefinedValue::Value;
        });
    }

    public function __construct()
    {
        $this->AsyncDisposableStackPolyfill_disposed = false;
        $this->AsyncDisposableStackPolyfill_stack = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->sourceStringTag = 'AsyncDisposableStack';
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'disposed' => $this->disposed(),
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }

    public function getJsSymbol(\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol $symbol): mixed
    {
        return match ($symbol) {
            \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::AsyncDispose => $this->disposeResourcesAsync(...),
            \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::ToStringTag => $this->sourceStringTag,
            default => UndefinedValue::Value,
        };
    }
}
