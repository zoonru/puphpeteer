<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameNavigationCommands
{

    public function goto(mixed $url, mixed $options = UndefinedValue::Value): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($url, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $navigate = function (mixed $client, mixed $url, mixed $referrer, mixed $referrerPolicy, mixed $frameId) use (&$ensureNewDocumentNavigation) {
    return Js::async(function () use (&$ensureNewDocumentNavigation, $client, $url, $referrer, $referrerPolicy, $frameId) {
    try {
        $response = Js::await(Js::invoke($client, 'send', ['Page.navigate', Js::object(['url' => $url, 'referrer' => $referrer, 'frameId' => $frameId, 'referrerPolicy' => $referrerPolicy])]));
        $ensureNewDocumentNavigation = !Js::truthy(!Js::truthy(Js::get($response, 'loaderId')));
        if (Js::truthy(Js::strictEqual(Js::get($response, 'errorText'), 'net::ERR_HTTP_RESPONSE_CODE_FAILURE'))) {
            return null;
        }
        return (Js::truthy(Js::get($response, 'errorText')) ? new \Nesk\Puphpeteer\Native\Runtime\JsError(('' . Js::string(Js::get($response, 'errorText')) . ' at ' . Js::string($url) . '')) : null);
    } catch (\Throwable $error) {
        if (Js::truthy(Js::isErrorLike($error))) {
            return $error;
        }
        throw $error;
    }
    });
};
            $_nativeBinding1 = $options;
            $referer = Js::defaultValue(Js::get($_nativeBinding1, 'referer'), fn () => Js::get(Js::invoke(Js::get($this->manager, 'networkManager'), 'extraHTTPHeaders', []), 'referer'));
            $referrerPolicy = Js::defaultValue(Js::get($_nativeBinding1, 'referrerPolicy'), fn () => Js::get(Js::invoke(Js::get($this->manager, 'networkManager'), 'extraHTTPHeaders', []), 'referer-policy'));
            $waitUntil = Js::defaultValue(Js::get($_nativeBinding1, 'waitUntil'), fn () => ['load']);
            $timeout = Js::defaultValue(Js::get($_nativeBinding1, 'timeout'), fn () => Js::invoke(Js::get($this->manager, 'timeoutSettings'), 'navigationTimeout', []));
            $ensureNewDocumentNavigation = false;
            $watcher = new \Nesk\Puphpeteer\Native\LifecycleWatcher(Js::get($this->manager, 'networkManager'), $this, $waitUntil, $timeout);
            $error = Js::await(Deferred::race([Js::functionValue($navigate)($this->client, $url, $referer, (Js::truthy($referrerPolicy) ? FrameNavigationHelpers::referrerPolicyToProtocol($referrerPolicy) : UndefinedValue::Value), $this->id), Js::invoke($watcher, 'terminationPromise', [])]));
            if (Js::truthy(!Js::truthy($error))) {
                $error = Js::await(Deferred::race([Js::invoke($watcher, 'terminationPromise', []), (Js::truthy($ensureNewDocumentNavigation) ? Js::invoke($watcher, 'newDocumentNavigationPromise', []) : Js::invoke($watcher, 'sameDocumentNavigationPromise', []))]));
            }
            try {
                if (Js::truthy($error)) {
                    throw $error;
                }
                return Js::await(Js::invoke($watcher, 'navigationResponse', []));
            } finally {
                Js::invoke($watcher, 'dispose', []);
            }
        });
    }

    public function waitForNavigation(mixed $options = UndefinedValue::Value): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding2 = $options;
            $waitUntil = Js::defaultValue(Js::get($_nativeBinding2, 'waitUntil'), fn () => ['load']);
            $timeout = Js::defaultValue(Js::get($_nativeBinding2, 'timeout'), fn () => Js::invoke(Js::get($this->manager, 'timeoutSettings'), 'navigationTimeout', []));
            $signal = Js::get($_nativeBinding2, 'signal');
            $watcher = new \Nesk\Puphpeteer\Native\LifecycleWatcher(Js::get($this->manager, 'networkManager'), $this, $waitUntil, $timeout, $signal);
            $error = Js::await(Deferred::race([Js::invoke($watcher, 'terminationPromise', []), ...Js::iterate(((Js::truthy(Js::get($options, 'ignoreSameDocumentNavigation')) ? [] : [Js::invoke($watcher, 'sameDocumentNavigationPromise', [])]))), Js::invoke($watcher, 'newDocumentNavigationPromise', [])]));
            try {
                if (Js::truthy($error)) {
                    throw $error;
                }
                $result = Js::await(Deferred::race([Js::invoke($watcher, 'terminationPromise', []), Js::invoke($watcher, 'navigationResponse', [])]));
                if (Js::truthy(($result instanceof \Throwable))) {
                    throw $error;
                }
                return Js::logicalOr($result, fn () => null);
            } finally {
                Js::invoke($watcher, 'dispose', []);
            }
        });
    }
}
