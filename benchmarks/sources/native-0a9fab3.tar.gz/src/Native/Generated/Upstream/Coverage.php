<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Coverage.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class Coverage implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $Coverage_jsCoverage;
    private mixed $Coverage_cssCoverage;

    public function __construct(mixed $client)
    {
        $this->Coverage_jsCoverage = UndefinedValue::Value;
        $this->Coverage_cssCoverage = UndefinedValue::Value;
        $this->Coverage_jsCoverage = new JSCoverage($client);
        $this->Coverage_cssCoverage = new CSSCoverage($client);
    }

    public function updateClient(mixed $client): mixed
    {
        Js::invoke($this->Coverage_jsCoverage, 'updateClient', [$client]);
        Js::invoke($this->Coverage_cssCoverage, 'updateClient', [$client]);
        return UndefinedValue::Value;
    }

    public function startJSCoverage(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            return Js::await(Js::invoke($this->Coverage_jsCoverage, 'start', [$options]));
        });
    }

    public function stopJSCoverage(): mixed
    {
        return Js::async(function () {
            return Js::await(Js::invoke($this->Coverage_jsCoverage, 'stop', []));
        });
    }

    public function startCSSCoverage(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            return Js::await(Js::invoke($this->Coverage_cssCoverage, 'start', [$options]));
        });
    }

    public function stopCSSCoverage(): mixed
    {
        return Js::async(function () {
            return Js::await(Js::invoke($this->Coverage_cssCoverage, 'stop', []));
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
