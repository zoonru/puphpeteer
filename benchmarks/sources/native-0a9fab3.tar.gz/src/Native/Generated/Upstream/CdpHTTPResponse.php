<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/HTTPResponse.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CdpHTTPResponse extends HTTPResponse
{
    private mixed $CdpHTTPResponse_request;
    private mixed $CdpHTTPResponse_contentPromise;
    private mixed $CdpHTTPResponse_bodyLoadedDeferred;
    private mixed $CdpHTTPResponse_remoteAddress;
    private mixed $CdpHTTPResponse_status;
    private mixed $CdpHTTPResponse_statusText;
    private mixed $CdpHTTPResponse_fromDiskCache;
    private mixed $CdpHTTPResponse_fromServiceWorker;
    private mixed $CdpHTTPResponse_headers;
    private mixed $CdpHTTPResponse_securityDetails;
    private mixed $CdpHTTPResponse_timing;

    public function __construct(mixed $request, mixed $responsePayload, mixed $extraInfo)
    {
        parent::__construct();
        $this->CdpHTTPResponse_request = UndefinedValue::Value;
        $this->CdpHTTPResponse_contentPromise = null;
        $this->CdpHTTPResponse_bodyLoadedDeferred = Deferred::create();
        $this->CdpHTTPResponse_remoteAddress = UndefinedValue::Value;
        $this->CdpHTTPResponse_status = UndefinedValue::Value;
        $this->CdpHTTPResponse_statusText = UndefinedValue::Value;
        $this->CdpHTTPResponse_fromDiskCache = UndefinedValue::Value;
        $this->CdpHTTPResponse_fromServiceWorker = UndefinedValue::Value;
        $this->CdpHTTPResponse_headers = Js::object([]);
        $this->CdpHTTPResponse_securityDetails = UndefinedValue::Value;
        $this->CdpHTTPResponse_timing = UndefinedValue::Value;
        $this->CdpHTTPResponse_request = $request;
        $this->CdpHTTPResponse_remoteAddress = Js::object(['ip' => Js::get($responsePayload, 'remoteIPAddress'), 'port' => Js::get($responsePayload, 'remotePort')]);
        $this->CdpHTTPResponse_statusText = Js::logicalOr($this->CdpHTTPResponse_parseStatusTextFromExtraInfo($extraInfo), fn () => Js::get($responsePayload, 'statusText'));
        $this->CdpHTTPResponse_fromDiskCache = !Js::truthy(!Js::truthy(Js::get($responsePayload, 'fromDiskCache')));
        $this->CdpHTTPResponse_fromServiceWorker = !Js::truthy(!Js::truthy(Js::get($responsePayload, 'fromServiceWorker')));
        $this->CdpHTTPResponse_status = (Js::truthy($extraInfo) ? Js::get($extraInfo, 'statusCode') : Js::get($responsePayload, 'status'));
        $headers = (Js::truthy($extraInfo) ? Js::get($extraInfo, 'headers') : Js::get($responsePayload, 'headers'));
        foreach (Js::iterate(Js::entries($headers)) as $_nativeItem1) {
            $key = Js::get($_nativeItem1, 0);
            $value = Js::get($_nativeItem1, 1);
            Js::set($this->CdpHTTPResponse_headers, Js::invoke($key, 'toLowerCase', []), $value);
        }
        $this->CdpHTTPResponse_securityDetails = (Js::truthy(Js::get($responsePayload, 'securityDetails')) ? new SecurityDetails(Js::get($responsePayload, 'securityDetails')) : null);
        $this->CdpHTTPResponse_timing = Js::logicalOr(Js::get($responsePayload, 'timing'), fn () => null);
    }

    private function CdpHTTPResponse_parseStatusTextFromExtraInfo(mixed $extraInfo): mixed
    {
        if (Js::truthy(Js::logicalOr(!Js::truthy($extraInfo), fn () => !Js::truthy(Js::get($extraInfo, 'headersText'))))) {
            return UndefinedValue::Value;
        }
        $firstLine = Js::get(Js::invoke(Js::get($extraInfo, 'headersText'), 'split', ['', 1]), 0);
        if (Js::truthy(Js::logicalOr(!Js::truthy($firstLine), fn () => Js::numeric('>', Js::get($firstLine, 'length'), 1000)))) {
            return UndefinedValue::Value;
        }
        $match = Js::invoke($firstLine, 'match', [new \Nesk\Puphpeteer\Native\Runtime\JsRegExp('/[^ ]* [^ ]* (.*)/')]);
        if (Js::truthy(!Js::truthy($match))) {
            return UndefinedValue::Value;
        }
        $statusText = Js::get($match, 1);
        if (Js::truthy(!Js::truthy($statusText))) {
            return UndefinedValue::Value;
        }
        return $statusText;
    }

    public function _resolveBody(mixed $err = UndefinedValue::Value): mixed
    {
        if (Js::truthy($err)) {
            return Js::invoke($this->CdpHTTPResponse_bodyLoadedDeferred, 'reject', [$err]);
        }
        return Js::invoke($this->CdpHTTPResponse_bodyLoadedDeferred, 'resolve', []);
    }

    public function remoteAddress(): mixed
    {
        return $this->CdpHTTPResponse_remoteAddress;
    }

    public function url(): mixed
    {
        return Js::invoke($this->CdpHTTPResponse_request, 'url', []);
    }

    public function status(): mixed
    {
        return $this->CdpHTTPResponse_status;
    }

    public function statusText(): mixed
    {
        return $this->CdpHTTPResponse_statusText;
    }

    public function headers(): mixed
    {
        return $this->CdpHTTPResponse_headers;
    }

    public function securityDetails(): mixed
    {
        return $this->CdpHTTPResponse_securityDetails;
    }

    public function timing(): mixed
    {
        return $this->CdpHTTPResponse_timing;
    }

    public function content(): mixed
    {
        if (Js::truthy(!Js::truthy($this->CdpHTTPResponse_contentPromise))) {
            $this->CdpHTTPResponse_contentPromise = Js::invoke(Js::invoke($this->CdpHTTPResponse_bodyLoadedDeferred, 'valueOrThrow', []), 'then', [function () {
    return Js::async(function () {
    try {
        $response = Js::await(Js::invoke(Js::get($this->CdpHTTPResponse_request, 'client'), 'send', ['Network.getResponseBody', Js::object(['requestId' => Js::get($this->CdpHTTPResponse_request, 'id')])]));
        return Js::stringToTypedArray(Js::get($response, 'body'), Js::get($response, 'base64Encoded'));
    } catch (\Throwable $error) {
        if (Js::truthy(Js::logicalAnd(($error instanceof \Nesk\Puphpeteer\Native\ProtocolError), fn () => Js::strictEqual(Js::get($error, 'originalMessage'), 'No resource with given identifier found')))) {
            throw new \Nesk\Puphpeteer\Native\ProtocolError('Could not load response body for this request. This might happen if the request is a preflight request.');
        }
        throw $error;
    }
    });
}]);
        }
        return $this->CdpHTTPResponse_contentPromise;
    }

    public function request(): mixed
    {
        return $this->CdpHTTPResponse_request;
    }

    public function fromCache(): mixed
    {
        return Js::logicalOr($this->CdpHTTPResponse_fromDiskCache, fn () => Js::get($this->CdpHTTPResponse_request, '_fromMemoryCache'));
    }

    public function fromServiceWorker(): mixed
    {
        return $this->CdpHTTPResponse_fromServiceWorker;
    }

    public function frame(): mixed
    {
        return Js::invoke($this->CdpHTTPResponse_request, 'frame', []);
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => parent::getJsProperty($name),
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: return parent::setJsProperty($name, $value);
        }
    }
}
