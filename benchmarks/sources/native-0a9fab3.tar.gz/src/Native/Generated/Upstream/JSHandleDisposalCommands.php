<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/JSHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait JSHandleDisposalCommands
{
    public function disposeSource(): mixed
    {
        return Js::discard(Js::invoke($this->dispose(), 'catch', [Js::debugError(...)]));
    }
    public function disposeSourceAsync(): mixed
    {
        return $this->dispose();
    }
}
