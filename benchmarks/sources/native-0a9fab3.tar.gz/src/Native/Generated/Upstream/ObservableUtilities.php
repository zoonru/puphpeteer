<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/util.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class ObservableUtilities
{

    public static function fromEmitterEvent(mixed $emitter, mixed $eventName): mixed
    {
        return new \Nesk\Puphpeteer\Native\Runtime\Observable\Observable(function (mixed $subscriber) use ($emitter, $eventName) {
    $listener = function (mixed $event) use ($subscriber) {
    Js::invoke($subscriber, 'next', [$event]);
    return UndefinedValue::Value;
};
    Js::invoke($emitter, 'on', [$eventName, $listener]);
    return function () use ($emitter, $eventName, $listener) {
    Js::invoke($emitter, 'off', [$eventName, $listener]);
    return UndefinedValue::Value;
};
});
    }

    public static function timeout(mixed $ms, mixed $cause = UndefinedValue::Value): mixed
    {
        return (Js::truthy(Js::strictEqual($ms, 0)) ? \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::never() : Js::invoke(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::timer($ms), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () use ($ms, $cause) {
    throw new \Nesk\Puphpeteer\Native\Runtime\Observable\TimeoutError(('Timed out after waiting ' . Js::string($ms) . 'ms'), Js::object(['cause' => $cause]));
})]));
    }

    public static function filterAsync(mixed $predicate): mixed
    {
        return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::mergeMap(function (mixed $value) use ($predicate) {
    return Js::invoke(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::from(Js::resolve(Js::callAwaitable($predicate, [$value]))), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::filter(function (mixed $isMatch) {
    return $isMatch;
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () use ($value) {
    return $value;
})]);
});
    }
}
