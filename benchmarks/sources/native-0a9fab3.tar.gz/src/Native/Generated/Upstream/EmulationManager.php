<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/EmulationManager.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class EmulationManager implements \Nesk\Puphpeteer\Native\Runtime\JsObject
{
    private mixed $EmulationManager_client = UndefinedValue::Value;
    private mixed $EmulationManager_emulatingMobile = UndefinedValue::Value;
    private mixed $EmulationManager_hasTouch = UndefinedValue::Value;
    private mixed $EmulationManager_states = UndefinedValue::Value;
    private mixed $EmulationManager_viewportState = UndefinedValue::Value;
    private mixed $EmulationManager_idleOverridesState = UndefinedValue::Value;
    private mixed $EmulationManager_timezoneState = UndefinedValue::Value;
    private mixed $EmulationManager_visionDeficiencyState = UndefinedValue::Value;
    private mixed $EmulationManager_cpuThrottlingState = UndefinedValue::Value;
    private mixed $EmulationManager_mediaFeaturesState = UndefinedValue::Value;
    private mixed $EmulationManager_mediaTypeState = UndefinedValue::Value;
    private mixed $EmulationManager_geoLocationState = UndefinedValue::Value;
    private mixed $EmulationManager_defaultBackgroundColorState = UndefinedValue::Value;
    private mixed $EmulationManager_javascriptEnabledState = UndefinedValue::Value;
    private mixed $EmulationManager_focusState = UndefinedValue::Value;
    private mixed $EmulationManager_secondaryClients = UndefinedValue::Value;

    public function __construct(mixed $client)
    {
        $this->EmulationManager_emulatingMobile = false;
        $this->EmulationManager_hasTouch = false;
        $this->EmulationManager_states = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->EmulationManager_viewportState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_applyViewport(...));
        $this->EmulationManager_idleOverridesState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateIdleState(...));
        $this->EmulationManager_timezoneState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateTimezone(...));
        $this->EmulationManager_visionDeficiencyState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateVisionDeficiency(...));
        $this->EmulationManager_cpuThrottlingState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateCpuThrottling(...));
        $this->EmulationManager_mediaFeaturesState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateMediaFeatures(...));
        $this->EmulationManager_mediaTypeState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_emulateMediaType(...));
        $this->EmulationManager_geoLocationState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_setGeolocation(...));
        $this->EmulationManager_defaultBackgroundColorState = new EmulatedState(Js::object(['active' => false]), $this, $this->EmulationManager_setDefaultBackgroundColor(...));
        $this->EmulationManager_javascriptEnabledState = new EmulatedState(Js::object(['javaScriptEnabled' => true, 'active' => false]), $this, $this->EmulationManager_setJavaScriptEnabled(...));
        $this->EmulationManager_focusState = new EmulatedState(Js::object(['enabled' => true, 'active' => false]), $this, $this->EmulationManager_emulateFocus(...));
        $this->EmulationManager_secondaryClients = new \Nesk\Puphpeteer\Native\Runtime\JsSet();
        $this->EmulationManager_client = $client;
    }

    public function updateClient(mixed $client): mixed
    {
        $this->EmulationManager_client = $client;
        Js::invoke($this->EmulationManager_secondaryClients, 'delete', [$client]);
        return UndefinedValue::Value;
    }

    public function registerState(mixed $state): mixed
    {
        Js::invoke($this->EmulationManager_states, 'push', [$state]);
        return UndefinedValue::Value;
    }

    public function clients(): mixed
    {
        return new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->EmulationManager_client, ...Js::iterate(Js::arrayFrom($this->EmulationManager_secondaryClients))]);
    }

    public function registerSpeculativeSession(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            Js::invoke($this->EmulationManager_secondaryClients, 'add', [$client]);
            Js::invoke($client, 'once', [Js::get(Js::object(['Disconnected' => '__native_session_closed']), 'Disconnected'), function () use ($client) {
    Js::invoke($this->EmulationManager_secondaryClients, 'delete', [$client]);
    return UndefinedValue::Value;
}]);
            Js::discard(Js::all(Js::invoke($this->EmulationManager_states, 'map', [function (mixed $s) {
    return Js::invoke(Js::invoke($s, 'sync', []), 'catch', [Js::debugError(...)]);
}])));
            return UndefinedValue::Value;
        });
    }

    public function javascriptEnabled(): mixed
    {
        return Js::get(Js::get($this->EmulationManager_javascriptEnabledState, 'state'), 'javaScriptEnabled');
    }

    public function emulateViewport(mixed $viewport): mixed
    {
        return Js::async(function () use ($viewport) {
            $currentState = Js::get($this->EmulationManager_viewportState, 'state');
            if (Js::truthy(Js::logicalAnd(!Js::truthy($viewport), fn () => !Js::truthy(Js::get($currentState, 'active'))))) {
                return false;
            }
            Js::await(Js::invoke($this->EmulationManager_viewportState, 'setState', [(Js::truthy($viewport) ? Js::object(['viewport' => $viewport, 'active' => true]) : Js::object(['active' => false]))]));
            $mobile = Js::logicalOr(Js::optionalGet($viewport, 'isMobile'), fn () => false);
            $hasTouch = Js::logicalOr(Js::optionalGet($viewport, 'hasTouch'), fn () => false);
            $reloadNeeded = Js::logicalOr(!Js::strictEqual($this->EmulationManager_emulatingMobile, $mobile), fn () => !Js::strictEqual($this->EmulationManager_hasTouch, $hasTouch));
            $this->EmulationManager_emulatingMobile = $mobile;
            $this->EmulationManager_hasTouch = $hasTouch;
            return $reloadNeeded;
        });
    }

    private function EmulationManager_applyViewport(mixed $client, mixed $viewportState): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $viewportState], function () use ($client, $viewportState) {
        return Js::async(function () use ($client, $viewportState) {
            if (Js::truthy(!Js::truthy(Js::get($viewportState, 'viewport')))) {
                Js::await(Js::invoke(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($client, 'send', ['Emulation.clearDeviceMetricsOverride']), Js::invoke($client, 'send', ['Emulation.setTouchEmulationEnabled', Js::object(['enabled' => false])])])), 'catch', [Js::debugError(...)]));
                return UndefinedValue::Value;
            }
            $_nativeBinding1 = $viewportState;
            $viewport = Js::get($_nativeBinding1, 'viewport');
            $mobile = Js::logicalOr(Js::get($viewport, 'isMobile'), fn () => false);
            $width = Js::get($viewport, 'width');
            $height = Js::get($viewport, 'height');
            $deviceScaleFactor = Js::coalesce(Js::get($viewport, 'deviceScaleFactor'), fn () => 1);
            $screenOrientation = (Js::truthy(Js::get($viewport, 'isLandscape')) ? Js::object(['angle' => 90, 'type' => 'landscapePrimary']) : Js::object(['angle' => 0, 'type' => 'portraitPrimary']));
            $hasTouch = Js::logicalOr(Js::get($viewport, 'hasTouch'), fn () => false);
            Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke(Js::invoke($client, 'send', ['Emulation.setDeviceMetricsOverride', Js::object(['mobile' => $mobile, 'width' => $width, 'height' => $height, 'deviceScaleFactor' => $deviceScaleFactor, 'screenOrientation' => $screenOrientation])]), 'catch', [function (mixed $err) {
    if (Js::truthy(Js::invoke(Js::get($err, 'message'), 'includes', ['Target does not support metrics override']))) {
        Js::debugError($err);
        return UndefinedValue::Value;
    }
    throw $err;
}]), Js::invoke($client, 'send', ['Emulation.setTouchEmulationEnabled', Js::object(['enabled' => $hasTouch])])])));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateIdleState(mixed $overrides = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($overrides) {
            Js::await(Js::invoke($this->EmulationManager_idleOverridesState, 'setState', [Js::object(['active' => true, 'overrides' => $overrides])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateIdleState(mixed $client, mixed $idleStateState): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $idleStateState], function () use ($client, $idleStateState) {
        return Js::async(function () use ($client, $idleStateState) {
            if (Js::truthy(!Js::truthy(Js::get($idleStateState, 'active')))) {
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::get($idleStateState, 'overrides'))) {
                Js::await(Js::invoke($client, 'send', ['Emulation.setIdleOverride', Js::object(['isUserActive' => Js::get(Js::get($idleStateState, 'overrides'), 'isUserActive'), 'isScreenUnlocked' => Js::get(Js::get($idleStateState, 'overrides'), 'isScreenUnlocked')])]));
            } else {
                Js::await(Js::invoke($client, 'send', ['Emulation.clearIdleOverride']));
            }
            return UndefinedValue::Value;
        });
        });
    }

    private function EmulationManager_emulateTimezone(mixed $client, mixed $timezoneState): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $timezoneState], function () use ($client, $timezoneState) {
        return Js::async(function () use ($client, $timezoneState) {
            if (Js::truthy(!Js::truthy(Js::get($timezoneState, 'active')))) {
                return UndefinedValue::Value;
            }
            try {
                Js::await(Js::invoke($client, 'send', ['Emulation.setTimezoneOverride', Js::object(['timezoneId' => Js::logicalOr(Js::get($timezoneState, 'timezoneId'), fn () => '')])]));
            } catch (\Throwable $error) {
                if (Js::truthy(Js::logicalAnd(Js::isErrorLike($error), fn () => Js::invoke(Js::get($error, 'message'), 'includes', ['Invalid timezone'])))) {
                    throw new \RuntimeException(('Invalid timezone ID: ' . Js::string(Js::get($timezoneState, 'timezoneId')) . ''));
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateTimezone(mixed $timezoneId = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($timezoneId) {
            Js::await(Js::invoke($this->EmulationManager_timezoneState, 'setState', [Js::object(['timezoneId' => $timezoneId, 'active' => true])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateVisionDeficiency(mixed $client, mixed $visionDeficiency): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $visionDeficiency], function () use ($client, $visionDeficiency) {
        return Js::async(function () use ($client, $visionDeficiency) {
            if (Js::truthy(!Js::truthy(Js::get($visionDeficiency, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setEmulatedVisionDeficiency', Js::object(['type' => Js::logicalOr(Js::get($visionDeficiency, 'visionDeficiency'), fn () => 'none')])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateVisionDeficiency(mixed $type = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($type) {
            $visionDeficiencies = new \Nesk\Puphpeteer\Native\Runtime\JsSet(new \Nesk\Puphpeteer\Native\Runtime\JsArray(['none', 'achromatopsia', 'blurredVision', 'deuteranopia', 'protanopia', 'reducedContrast', 'tritanopia']));
            Js::assert(Js::logicalOr(!Js::truthy($type), fn () => Js::invoke($visionDeficiencies, 'has', [$type])), ('Unsupported vision deficiency: ' . Js::string($type) . ''));
            Js::await(Js::invoke($this->EmulationManager_visionDeficiencyState, 'setState', [Js::object(['active' => true, 'visionDeficiency' => $type])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateCpuThrottling(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setCPUThrottlingRate', Js::object(['rate' => Js::coalesce(Js::get($state, 'factor'), fn () => 1)])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateCPUThrottling(mixed $factor): mixed
    {
        return Js::async(function () use ($factor) {
            Js::assert(Js::logicalOr(Js::strictEqual($factor, null), fn () => Js::numeric('>=', $factor, 1)), 'Throttling rate should be greater or equal to 1');
            Js::await(Js::invoke($this->EmulationManager_cpuThrottlingState, 'setState', [Js::object(['active' => true, 'factor' => Js::coalesce($factor, fn () => UndefinedValue::Value)])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateMediaFeatures(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setEmulatedMedia', Js::object(['features' => Js::get($state, 'mediaFeatures')])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateMediaFeatures(mixed $features = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($features) {
            if (Js::truthy(Js::isArray($features))) {
                foreach (Js::iterate($features) as $mediaFeature) {
                    $name = Js::get($mediaFeature, 'name');
                    Js::assert(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\JsRegExp('/^(?:prefers-(?:color-scheme|reduced-motion)|color-gamut)$/'), 'test', [$name]), Js::add('Unsupported media feature: ', $name));
                }
            }
            Js::await(Js::invoke($this->EmulationManager_mediaFeaturesState, 'setState', [Js::object(['active' => true, 'mediaFeatures' => $features])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateMediaType(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setEmulatedMedia', Js::object(['media' => Js::logicalOr(Js::get($state, 'type'), fn () => '')])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateMediaType(mixed $type = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($type) {
            Js::assert(Js::logicalOr(Js::logicalOr(Js::strictEqual($type, 'screen'), fn () => Js::strictEqual($type, 'print')), fn () => Js::strictEqual((Js::coalesce($type, fn () => UndefinedValue::Value)), UndefinedValue::Value)), Js::add('Unsupported media type: ', $type));
            Js::await(Js::invoke($this->EmulationManager_mediaTypeState, 'setState', [Js::object(['type' => $type, 'active' => true])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_setGeolocation(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setGeolocationOverride', (Js::truthy(Js::get($state, 'geoLocation')) ? Js::object(['longitude' => Js::get(Js::get($state, 'geoLocation'), 'longitude'), 'latitude' => Js::get(Js::get($state, 'geoLocation'), 'latitude'), 'accuracy' => Js::get(Js::get($state, 'geoLocation'), 'accuracy')]) : UndefinedValue::Value)]));
            return UndefinedValue::Value;
        });
        });
    }

    public function setGeolocation(mixed $options): mixed
    {
        return Js::async(function () use ($options) {
            $_nativeBinding2 = $options;
            $longitude = Js::get($_nativeBinding2, 'longitude');
            $latitude = Js::get($_nativeBinding2, 'latitude');
            $accuracy = Js::defaultValue(Js::get($_nativeBinding2, 'accuracy'), fn () => 0);
            if (Js::truthy(Js::logicalOr(Js::numeric('<', $longitude, (-180)), fn () => Js::numeric('>', $longitude, 180)))) {
                throw new \RuntimeException(('Invalid longitude "' . Js::string($longitude) . '": precondition -180 <= LONGITUDE <= 180 failed.'));
            }
            if (Js::truthy(Js::logicalOr(Js::numeric('<', $latitude, (-90)), fn () => Js::numeric('>', $latitude, 90)))) {
                throw new \RuntimeException(('Invalid latitude "' . Js::string($latitude) . '": precondition -90 <= LATITUDE <= 90 failed.'));
            }
            if (Js::truthy(Js::numeric('<', $accuracy, 0))) {
                throw new \RuntimeException(('Invalid accuracy "' . Js::string($accuracy) . '": precondition 0 <= ACCURACY failed.'));
            }
            Js::await(Js::invoke($this->EmulationManager_geoLocationState, 'setState', [Js::object(['active' => true, 'geoLocation' => Js::object(['longitude' => $longitude, 'latitude' => $latitude, 'accuracy' => $accuracy])])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_setDefaultBackgroundColor(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setDefaultBackgroundColorOverride', Js::object(['color' => Js::get($state, 'color')])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function resetDefaultBackgroundColor(): mixed
    {
        return Js::async(function () {
            Js::await(Js::invoke($this->EmulationManager_defaultBackgroundColorState, 'setState', [Js::object(['active' => true, 'color' => UndefinedValue::Value])]));
            return UndefinedValue::Value;
        });
    }

    public function setTransparentBackgroundColor(): mixed
    {
        return Js::async(function () {
            Js::await(Js::invoke($this->EmulationManager_defaultBackgroundColorState, 'setState', [Js::object(['active' => true, 'color' => Js::object(['r' => 0, 'g' => 0, 'b' => 0, 'a' => 0])])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_setJavaScriptEnabled(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setScriptExecutionDisabled', Js::object(['value' => !Js::truthy(Js::get($state, 'javaScriptEnabled'))])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function setJavaScriptEnabled(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            Js::await(Js::invoke($this->EmulationManager_javascriptEnabledState, 'setState', [Js::object(['active' => true, 'javaScriptEnabled' => $enabled])]));
            return UndefinedValue::Value;
        });
    }

    private function EmulationManager_emulateFocus(mixed $client, mixed $state): mixed
    {
        return Js::onceForArguments(__METHOD__, [$client, $state], function () use ($client, $state) {
        return Js::async(function () use ($client, $state) {
            if (Js::truthy(!Js::truthy(Js::get($state, 'active')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke($client, 'send', ['Emulation.setFocusEmulationEnabled', Js::object(['enabled' => Js::get($state, 'enabled')])]));
            return UndefinedValue::Value;
        });
        });
    }

    public function emulateFocus(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            Js::await(Js::invoke($this->EmulationManager_focusState, 'setState', [Js::object(['active' => true, 'enabled' => $enabled])]));
            return UndefinedValue::Value;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'javascriptEnabled' => $this->javascriptEnabled(),
            default => UndefinedValue::Value,
        };
    }
}
