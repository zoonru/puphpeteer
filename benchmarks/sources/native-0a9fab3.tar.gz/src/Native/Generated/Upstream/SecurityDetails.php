<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/SecurityDetails.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class SecurityDetails
{
    protected mixed $SecurityDetails_subjectName = UndefinedValue::Value;
    protected mixed $SecurityDetails_issuer = UndefinedValue::Value;
    protected mixed $SecurityDetails_validFrom = UndefinedValue::Value;
    protected mixed $SecurityDetails_validTo = UndefinedValue::Value;
    protected mixed $SecurityDetails_protocol = UndefinedValue::Value;
    protected mixed $SecurityDetails_sanList = UndefinedValue::Value;

    public function __construct(mixed $securityPayload)
    {
        $this->SecurityDetails_subjectName = Js::get($securityPayload, 'subjectName');
        $this->SecurityDetails_issuer = Js::get($securityPayload, 'issuer');
        $this->SecurityDetails_validFrom = Js::get($securityPayload, 'validFrom');
        $this->SecurityDetails_validTo = Js::get($securityPayload, 'validTo');
        $this->SecurityDetails_protocol = Js::get($securityPayload, 'protocol');
        $this->SecurityDetails_sanList = Js::get($securityPayload, 'sanList');
    }

    public function issuer(): mixed
    {
        return $this->SecurityDetails_issuer;
    }

    public function validFrom(): mixed
    {
        return $this->SecurityDetails_validFrom;
    }

    public function validTo(): mixed
    {
        return $this->SecurityDetails_validTo;
    }

    public function protocol(): mixed
    {
        return $this->SecurityDetails_protocol;
    }

    public function subjectName(): mixed
    {
        return $this->SecurityDetails_subjectName;
    }

    public function subjectAlternativeNames(): mixed
    {
        return $this->SecurityDetails_sanList;
    }
}
