<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageEventCommands
{
    private mixed $Page_requestHandlers;
    private function initializePageEmitter(): void
    {
        $this->Page_requestHandlers = new \Nesk\Puphpeteer\Native\Runtime\WeakObjectMap();
    }

    public function on(mixed $type, mixed $handler): mixed
    {
        if (Js::truthy(!Js::strictEqual($type, Js::get(Js::object(['Request' => 'request']), 'Request')))) {
            return parent::on($type, $handler);
        }
        $wrapper = Js::invoke($this->Page_requestHandlers, 'get', [($handler)]);
        if (Js::truthy(Js::strictEqual($wrapper, UndefinedValue::Value))) {
            $wrapper = function (mixed $event) use ($handler) {
    Js::invoke($event, 'enqueueInterceptAction', [function () use ($handler, $event) {
    return Js::call($handler, [($event)]);
}]);
    return UndefinedValue::Value;
};
            Js::invoke($this->Page_requestHandlers, 'set', [($handler), $wrapper]);
        }
        return parent::on($type, ($wrapper));
    }

    public function off(mixed $type, mixed $handler = UndefinedValue::Value): mixed
    {
        if (Js::truthy(Js::strictEqual($type, Js::get(Js::object(['Request' => 'request']), 'Request')))) {
            $handler = Js::logicalOr(((Js::invoke($this->Page_requestHandlers, 'get', [($handler)]))), fn () => $handler);
        }
        return parent::off($type, $handler);
    }
}
