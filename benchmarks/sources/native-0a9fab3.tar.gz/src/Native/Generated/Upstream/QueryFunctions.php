<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/QueryHandler.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

final class QueryFunctions
{
    public const waitFor = 'async (PuppeteerUtil, query, selector, root, visible) => {
    const querySelector = PuppeteerUtil.createFunction(query);
    const node = await querySelector(root ?? document, selector, PuppeteerUtil);
    return PuppeteerUtil.checkVisibility(node, visible);
}';
    public const queryOneTemplate = 'async (node, selector, PuppeteerUtil) => {
    const querySelectorAll = __NATIVE_QUERY_ALL_FUNCTION__;
    const results = querySelectorAll(node, selector, PuppeteerUtil);
    for await (const result of results) {
        return result;
    }
    return null;
}';
}
