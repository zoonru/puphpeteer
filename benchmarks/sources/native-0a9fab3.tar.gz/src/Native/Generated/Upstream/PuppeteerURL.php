<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/util.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
class PuppeteerURL implements \Nesk\Puphpeteer\Native\Runtime\JsObject
{
    public static mixed $INTERNAL_URL = 'pptr:internal';
    public static function fromCallSite(mixed $functionName, mixed $site): mixed
    {
        $url = new PuppeteerURL();
        ($url)->PuppeteerURL_functionName = $functionName;
        ($url)->PuppeteerURL_siteString = Js::invoke($site, 'toString', []);
        return $url;
    }
    public static function parse(mixed $url): mixed
    {
        return (function (mixed $url) {
    $url = Js::invoke($url, 'slice', [Js::get('pptr:', 'length')]);
    $_nativeBinding1 = Js::invoke($url, 'split', [';']);
    $functionName = Js::defaultValue(Js::get($_nativeBinding1, 0), fn () => '');
    $siteString = Js::defaultValue(Js::get($_nativeBinding1, 1), fn () => '');
    $puppeteerUrl = new PuppeteerURL();
    ($puppeteerUrl)->PuppeteerURL_functionName = $functionName;
    ($puppeteerUrl)->PuppeteerURL_siteString = \Nesk\Puphpeteer\Native\Runtime\Uri::decodeComponent($siteString);
    return $puppeteerUrl;
})($url);
    }
    public static function isPuppeteerURL(mixed $url): mixed
    {
        return (function (mixed $url) {
    return Js::invoke($url, 'startsWith', ['pptr:']);
})($url);
    }
    private mixed $PuppeteerURL_functionName = UndefinedValue::Value;
    private mixed $PuppeteerURL_siteString = UndefinedValue::Value;
    public function functionName(): mixed
    {
        return $this->PuppeteerURL_functionName;
    }
    public function siteString(): mixed
    {
        return $this->PuppeteerURL_siteString;
    }
    public function toString(): mixed
    {
        return ('pptr:' . Js::string(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->PuppeteerURL_functionName, \Nesk\Puphpeteer\Native\Runtime\Uri::encodeComponent($this->PuppeteerURL_siteString)]), 'join', [';'])) . '');
    }
    public function getJsProperty(string $name): mixed { return match ($name) {'functionName'=>$this->functionName(),'siteString'=>$this->siteString(),default=>UndefinedValue::Value}; }
}
