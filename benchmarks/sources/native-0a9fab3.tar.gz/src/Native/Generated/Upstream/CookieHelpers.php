<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class CookieHelpers
{
    public static function convertCookiesPartitionKeyFromPuppeteerToCdp(mixed $partitionKey): mixed
    {
        if (Js::truthy(Js::strictEqual($partitionKey, UndefinedValue::Value))) {
            return UndefinedValue::Value;
        }
        if (Js::truthy(Js::strictEqual(Js::typeOf($partitionKey), 'string'))) {
            return Js::object(['topLevelSite' => $partitionKey, 'hasCrossSiteAncestor' => false]);
        }
        return Js::object(['topLevelSite' => Js::get($partitionKey, 'sourceOrigin'), 'hasCrossSiteAncestor' => Js::coalesce(Js::get($partitionKey, 'hasCrossSiteAncestor'), fn () => false)]);
    }
}
