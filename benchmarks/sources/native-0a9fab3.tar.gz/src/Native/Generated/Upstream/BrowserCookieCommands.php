<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Browser.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait BrowserCookieCommands
{

    public function cookies(): mixed
    {
        return Js::async(function () {
            return Js::await(Js::invoke($this->defaultBrowserContext(), 'cookies', []));
        });
    }

    public function setCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            return Js::await(Js::invoke($this->defaultBrowserContext(), 'setCookie', [...Js::iterate($cookies)]));
        });
    }

    public function deleteCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            return Js::await(Js::invoke($this->defaultBrowserContext(), 'deleteCookie', [...Js::iterate($cookies)]));
        });
    }

    public function deleteMatchingCookies(mixed ...$filters): mixed
    {
        return Js::async(function () use ($filters) {
            $filters = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($filters));
            return Js::await(Js::invoke($this->defaultBrowserContext(), 'deleteMatchingCookies', [...Js::iterate($filters)]));
        });
    }
}
