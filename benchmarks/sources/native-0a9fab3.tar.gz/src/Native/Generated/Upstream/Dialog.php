<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Dialog.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

abstract class Dialog
{
    protected mixed $Dialog_type = UndefinedValue::Value;
    protected mixed $Dialog_message = UndefinedValue::Value;
    protected mixed $Dialog_defaultValue = UndefinedValue::Value;
    protected mixed $handled = false;

    public function __construct(mixed $type, mixed $message, mixed $defaultValue = '')
    {
        $this->Dialog_type = $type;
        $this->Dialog_message = $message;
        $this->Dialog_defaultValue = $defaultValue;
    }

    public function type(): mixed
    {
        return $this->Dialog_type;
    }

    public function message(): mixed
    {
        return $this->Dialog_message;
    }

    public function defaultValue(): mixed
    {
        return $this->Dialog_defaultValue;
    }

    abstract protected function handle(mixed $options): mixed;

    public function accept(mixed $promptText = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($promptText) {
            Js::assert(!Js::truthy($this->handled), 'Cannot accept dialog which is already handled!');
            $this->handled = true;
            Js::await($this->handle(Js::object(['accept' => true, 'text' => $promptText])));
            return UndefinedValue::Value;
        });
    }

    public function dismiss(): mixed
    {
        return Js::async(function () {
            Js::assert(!Js::truthy($this->handled), 'Cannot dismiss dialog which is already handled!');
            $this->handled = true;
            Js::await($this->handle(Js::object(['accept' => false])));
            return UndefinedValue::Value;
        });
    }
}
