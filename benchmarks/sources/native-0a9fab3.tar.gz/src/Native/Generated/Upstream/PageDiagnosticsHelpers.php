<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class PageDiagnosticsHelpers
{
    public static function supportedMetrics(): \Nesk\Puphpeteer\Native\Runtime\JsSet
    {
        static $metrics;
        return $metrics ??= new \Nesk\Puphpeteer\Native\Runtime\JsSet(new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Timestamp', 'Documents', 'Frames', 'JSEventListeners', 'Nodes', 'LayoutCount', 'RecalcStyleCount', 'LayoutDuration', 'RecalcStyleDuration', 'ScriptDuration', 'TaskDuration', 'JSHeapUsedSize', 'JSHeapTotalSize']));
    }
    public static function convertConsoleMessageLevel(mixed $method): mixed
    {
        $_nativeSwitch1 = $method;
        if (Js::strictEqual($_nativeSwitch1, 'warning')) {
            return 'warn';
        }
        else {
            return ($method);
        }
    }

    // releaseObject body from cdp/JSHandle.ts.
    public static function releaseObject(mixed $client, mixed $remoteObject): mixed
    {
        return Js::async(function () use ($client, $remoteObject) {
            if (Js::truthy(!Js::truthy(Js::get($remoteObject, 'objectId')))) {
                return UndefinedValue::Value;
            }
            Js::await(Js::invoke(Js::invoke($client, 'send', ['Runtime.releaseObject', Js::object(['objectId' => Js::get($remoteObject, 'objectId')])]), 'catch', [function (mixed $error) {
    Js::debugError($error);
    return UndefinedValue::Value;
}]));
            return UndefinedValue::Value;
        });
    }
}
