<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/HTTPRequest.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CdpHTTPRequest extends HTTPRequest
{
    public mixed $id;
    private mixed $CdpHTTPRequest_client;
    private mixed $CdpHTTPRequest_isNavigationRequest;
    private mixed $CdpHTTPRequest_url;
    private mixed $CdpHTTPRequest_resourceType;
    private mixed $CdpHTTPRequest_method;
    private mixed $CdpHTTPRequest_hasPostData;
    private mixed $CdpHTTPRequest_postData;
    private mixed $CdpHTTPRequest_headers;
    private mixed $CdpHTTPRequest_frame;
    private mixed $CdpHTTPRequest_initiator;

    public function client(): mixed
    {
        return $this->CdpHTTPRequest_client;
    }

    public function __nativeSet_client(mixed $newClient): mixed
    {
        $this->CdpHTTPRequest_client = $newClient;
        return UndefinedValue::Value;
    }

    public function __construct(mixed $client, mixed $frame, mixed $interceptionId, mixed $allowInterception, mixed $data, mixed $redirectChain)
    {
        parent::__construct();
        $this->id = UndefinedValue::Value;
        $this->CdpHTTPRequest_client = UndefinedValue::Value;
        $this->CdpHTTPRequest_isNavigationRequest = UndefinedValue::Value;
        $this->CdpHTTPRequest_url = UndefinedValue::Value;
        $this->CdpHTTPRequest_resourceType = UndefinedValue::Value;
        $this->CdpHTTPRequest_method = UndefinedValue::Value;
        $this->CdpHTTPRequest_hasPostData = false;
        $this->CdpHTTPRequest_postData = UndefinedValue::Value;
        $this->CdpHTTPRequest_headers = Js::object([]);
        $this->CdpHTTPRequest_frame = UndefinedValue::Value;
        $this->CdpHTTPRequest_initiator = UndefinedValue::Value;
        $this->CdpHTTPRequest_client = $client;
        $this->id = Js::get($data, 'requestId');
        $this->CdpHTTPRequest_isNavigationRequest = Js::logicalAnd(Js::strictEqual(Js::get($data, 'requestId'), Js::get($data, 'loaderId')), fn () => Js::strictEqual(Js::get($data, 'type'), 'Document'));
        $this->_interceptionId = $interceptionId;
        $this->CdpHTTPRequest_url = Js::add(Js::get(Js::get($data, 'request'), 'url'), (Js::coalesce(Js::get(Js::get($data, 'request'), 'urlFragment'), fn () => '')));
        $this->CdpHTTPRequest_resourceType = (Js::invoke((Js::logicalOr(Js::get($data, 'type'), fn () => 'other')), 'toLowerCase', []));
        $this->CdpHTTPRequest_method = Js::get(Js::get($data, 'request'), 'method');
        $this->CdpHTTPRequest_postData = Js::get(Js::get($data, 'request'), 'postData');
        $this->CdpHTTPRequest_hasPostData = Js::coalesce(Js::get(Js::get($data, 'request'), 'hasPostData'), fn () => false);
        $this->CdpHTTPRequest_frame = $frame;
        $this->_redirectChain = $redirectChain;
        $this->CdpHTTPRequest_initiator = Js::get($data, 'initiator');
        Js::set($this->interception, 'enabled', $allowInterception);
        $this->updateHeaders(Js::get(Js::get($data, 'request'), 'headers'));
    }

    public function updateHeaders(mixed $headers): mixed
    {
        foreach (Js::iterate(Js::entries($headers)) as $_nativeItem1) {
            $key = Js::get($_nativeItem1, 0);
            $value = Js::get($_nativeItem1, 1);
            Js::set($this->CdpHTTPRequest_headers, Js::invoke($key, 'toLowerCase', []), $value);
        }
        return UndefinedValue::Value;
    }

    public function url(): mixed
    {
        return $this->CdpHTTPRequest_url;
    }

    public function resourceType(): mixed
    {
        return $this->CdpHTTPRequest_resourceType;
    }

    public function method(): mixed
    {
        return $this->CdpHTTPRequest_method;
    }

    public function postData(): mixed
    {
        return $this->CdpHTTPRequest_postData;
    }

    public function hasPostData(): mixed
    {
        return $this->CdpHTTPRequest_hasPostData;
    }

    public function fetchPostData(): mixed
    {
        return Js::async(function () {
            try {
                $result = Js::await(Js::invoke($this->CdpHTTPRequest_client, 'send', ['Network.getRequestPostData', Js::object(['requestId' => $this->id])]));
                return Js::get($result, 'postData');
            } catch (\Throwable $err) {
                Js::debugError($err);
                return UndefinedValue::Value;
            }
        });
    }

    public function headers(): mixed
    {
        return Js::cloneValue($this->CdpHTTPRequest_headers);
    }

    public function response(): mixed
    {
        return $this->_response;
    }

    public function frame(): mixed
    {
        return $this->CdpHTTPRequest_frame;
    }

    public function isNavigationRequest(): mixed
    {
        return $this->CdpHTTPRequest_isNavigationRequest;
    }

    public function initiator(): mixed
    {
        return $this->CdpHTTPRequest_initiator;
    }

    public function redirectChain(): mixed
    {
        return Js::invoke($this->_redirectChain, 'slice', []);
    }

    public function failure(): mixed
    {
        if (Js::truthy(!Js::truthy($this->_failureText))) {
            return null;
        }
        return Js::object(['errorText' => $this->_failureText]);
    }

    protected function canBeIntercepted(): mixed
    {
        return Js::logicalAnd(!Js::truthy(Js::invoke($this->url(), 'startsWith', ['data:'])), fn () => !Js::truthy($this->_fromMemoryCache));
    }

    public function _continue(mixed $overrides = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($overrides) {
            if ($overrides === UndefinedValue::Value) { $overrides = Js::object([]); }
            $_nativeBinding2 = $overrides;
            $url = Js::get($_nativeBinding2, 'url');
            $method = Js::get($_nativeBinding2, 'method');
            $postData = Js::get($_nativeBinding2, 'postData');
            $headers = Js::get($_nativeBinding2, 'headers');
            Js::set($this->interception, 'handled', true);
            $postDataBinaryBase64 = (Js::truthy($postData) ? Js::stringToBase64($postData) : UndefinedValue::Value);
            if (Js::truthy(Js::strictEqual($this->_interceptionId, UndefinedValue::Value))) {
                throw new \RuntimeException('HTTPRequest is missing _interceptionId needed for Fetch.continueRequest');
            }
            Js::await(Js::invoke(Js::invoke($this->CdpHTTPRequest_client, 'send', ['Fetch.continueRequest', Js::object(['requestId' => $this->_interceptionId, 'url' => $url, 'method' => $method, 'postData' => $postDataBinaryBase64, 'headers' => (Js::truthy($headers) ? RequestHelpers::headersArray($headers) : UndefinedValue::Value)])]), 'catch', [function (mixed $error) {
    Js::set($this->interception, 'handled', false);
    return RequestHelpers::handleError($error);
}]));
            return UndefinedValue::Value;
        });
    }

    public function _respond(mixed $response): mixed
    {
        return Js::async(function () use ($response) {
            Js::set($this->interception, 'handled', true);
            $parsedBody = UndefinedValue::Value;
            if (Js::truthy(Js::get($response, 'body'))) {
                $parsedBody = self::getResponse(Js::get($response, 'body'));
            }
            $responseHeaders = Js::object([]);
            if (Js::truthy(Js::get($response, 'headers'))) {
                foreach (Js::iterate(Js::keys(Js::get($response, 'headers'))) as $header) {
                    $value = Js::get(Js::get($response, 'headers'), $header);
                    Js::set($responseHeaders, Js::invoke($header, 'toLowerCase', []), (Js::truthy(Js::isArray($value)) ? Js::invoke($value, 'map', [function (mixed $item) {
    return Js::string($item);
}]) : Js::string($value)));
                }
            }
            if (Js::truthy(Js::get($response, 'contentType'))) {
                Js::set($responseHeaders, 'content-type', Js::get($response, 'contentType'));
            }
            if (Js::truthy(Js::logicalAnd(Js::optionalGet($parsedBody, 'contentLength'), fn () => !Js::truthy((Js::hasProperty($responseHeaders, 'content-length')))))) {
                Js::set($responseHeaders, 'content-length', Js::string(Js::get($parsedBody, 'contentLength')));
            }
            $status = Js::logicalOr(Js::get($response, 'status'), fn () => 200);
            if (Js::truthy(Js::strictEqual($this->_interceptionId, UndefinedValue::Value))) {
                throw new \RuntimeException('HTTPRequest is missing _interceptionId needed for Fetch.fulfillRequest');
            }
            Js::await(Js::invoke(Js::invoke($this->CdpHTTPRequest_client, 'send', ['Fetch.fulfillRequest', Js::object(['requestId' => $this->_interceptionId, 'responseCode' => $status, 'responsePhrase' => Js::get((Js::object(['100' => 'Continue', '101' => 'Switching Protocols', '102' => 'Processing', '103' => 'Early Hints', '200' => 'OK', '201' => 'Created', '202' => 'Accepted', '203' => 'Non-Authoritative Information', '204' => 'No Content', '205' => 'Reset Content', '206' => 'Partial Content', '207' => 'Multi-Status', '208' => 'Already Reported', '226' => 'IM Used', '300' => 'Multiple Choices', '301' => 'Moved Permanently', '302' => 'Found', '303' => 'See Other', '304' => 'Not Modified', '305' => 'Use Proxy', '306' => 'Switch Proxy', '307' => 'Temporary Redirect', '308' => 'Permanent Redirect', '400' => 'Bad Request', '401' => 'Unauthorized', '402' => 'Payment Required', '403' => 'Forbidden', '404' => 'Not Found', '405' => 'Method Not Allowed', '406' => 'Not Acceptable', '407' => 'Proxy Authentication Required', '408' => 'Request Timeout', '409' => 'Conflict', '410' => 'Gone', '411' => 'Length Required', '412' => 'Precondition Failed', '413' => 'Payload Too Large', '414' => 'URI Too Long', '415' => 'Unsupported Media Type', '416' => 'Range Not Satisfiable', '417' => 'Expectation Failed', '418' => 'I\'m a teapot', '421' => 'Misdirected Request', '422' => 'Unprocessable Entity', '423' => 'Locked', '424' => 'Failed Dependency', '425' => 'Too Early', '426' => 'Upgrade Required', '428' => 'Precondition Required', '429' => 'Too Many Requests', '431' => 'Request Header Fields Too Large', '451' => 'Unavailable For Legal Reasons', '500' => 'Internal Server Error', '501' => 'Not Implemented', '502' => 'Bad Gateway', '503' => 'Service Unavailable', '504' => 'Gateway Timeout', '505' => 'HTTP Version Not Supported', '506' => 'Variant Also Negotiates', '507' => 'Insufficient Storage', '508' => 'Loop Detected', '510' => 'Not Extended', '511' => 'Network Authentication Required'])), $status), 'responseHeaders' => RequestHelpers::headersArray($responseHeaders), 'body' => Js::optionalGet($parsedBody, 'base64')])]), 'catch', [function (mixed $error) {
    Js::set($this->interception, 'handled', false);
    return RequestHelpers::handleError($error);
}]));
            return UndefinedValue::Value;
        });
    }

    public function _abort(mixed $errorReason): mixed
    {
        return Js::async(function () use ($errorReason) {
            Js::set($this->interception, 'handled', true);
            if (Js::truthy(Js::strictEqual($this->_interceptionId, UndefinedValue::Value))) {
                throw new \RuntimeException('HTTPRequest is missing _interceptionId needed for Fetch.failRequest');
            }
            Js::await(Js::invoke(Js::invoke($this->CdpHTTPRequest_client, 'send', ['Fetch.failRequest', Js::object(['requestId' => $this->_interceptionId, 'errorReason' => Js::logicalOr($errorReason, fn () => 'Failed')])]), 'catch', [RequestHelpers::handleError(...)]));
            return UndefinedValue::Value;
        });
    }

    public function id(): mixed
    {
        return $this->id;
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'id' => $this->id,
            'client' => $this->client(),
            default => parent::getJsProperty($name),
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            case 'id': return $this->id = $value;
            case 'client': $this->__nativeSet_client($value); return $value;
            default: return parent::setJsProperty($name, $value);
        }
    }
}
