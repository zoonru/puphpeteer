<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/utils.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class RemoteValues
{
    public static function valueFromRemoteObject(mixed $remoteObject): mixed
    {
        Js::assert(!Js::truthy(Js::get($remoteObject, 'objectId')), 'Cannot extract value when objectId is given');
        if (Js::truthy(Js::get($remoteObject, 'unserializableValue'))) {
            if (Js::truthy(Js::strictEqual(Js::get($remoteObject, 'type'), 'bigint'))) {
                return \Nesk\Puphpeteer\Native\BigInt::fromDecimal(Js::invoke(Js::get($remoteObject, 'unserializableValue'), 'replace', ['n', '']));
            }
            $_nativeSwitch1 = Js::get($remoteObject, 'unserializableValue');
            if (Js::strictEqual($_nativeSwitch1, '-0')) {
                return (-0.0);
            }
            else if (Js::strictEqual($_nativeSwitch1, 'NaN')) {
                return NAN;
            }
            else if (Js::strictEqual($_nativeSwitch1, 'Infinity')) {
                return INF;
            }
            else if (Js::strictEqual($_nativeSwitch1, '-Infinity')) {
                return (-INF);
            }
            else {
                throw new \RuntimeException(Js::add('Unsupported unserializable value: ', Js::get($remoteObject, 'unserializableValue')));
            }
        }
        return Js::get($remoteObject, 'value');
    }
}
