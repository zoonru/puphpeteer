<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait ExecutionBindingCommands
{
    private mixed $sourceBindings;
    private mixed $bindingMutex;
    private function initializeSourceBindings(): void
    {
        $this->sourceBindings = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        $this->bindingMutex = new Mutex();
    }
    private function installUtilityBinding(mixed $binding): mixed
    {
        return Js::async(function () use ($binding) {
            if (Js::truthy(Js::invoke($this->sourceBindings, 'has', [Js::get($binding, 'name')]))) {
                return UndefinedValue::Value;
            }
            $_ = Js::await(Js::invoke($this->bindingMutex, 'acquire', []));
            $_nativeDisposer1 = Js::disposer($_);
            $_nativeUsingError1 = null;
            try {
                try {
                    Js::await(Js::invoke($this->session, 'send', ['Runtime.addBinding', (Js::truthy($this->name) ? Js::object(['name' => Js::add(BindingFunctions::prefix, Js::get($binding, 'name')), 'executionContextName' => $this->name]) : Js::object(['name' => Js::add(BindingFunctions::prefix, Js::get($binding, 'name')), 'executionContextId' => $this->id]))]));
                    Js::await($this->evaluateBinding(new \Nesk\Puphpeteer\Native\JsFunction(BindingFunctions::init), 'internal', Js::get($binding, 'name'), BindingFunctions::prefix));
                    Js::invoke($this->sourceBindings, 'set', [Js::get($binding, 'name'), $binding]);
                } catch (\Throwable $error) {
                    if (Js::truthy(Js::isErrorInstance($error))) {
                        if (Js::truthy(Js::invoke(Js::get($error, 'message'), 'includes', ['Execution context was destroyed']))) {
                            return UndefinedValue::Value;
                        }
                        if (Js::truthy(Js::invoke(Js::get($error, 'message'), 'includes', ['Cannot find context with specified id']))) {
                            return UndefinedValue::Value;
                        }
                    }
                    Js::debugError($error);
                }
            } catch (\Throwable $_nativeUsingCaught1) {
                $_nativeUsingError1 = $_nativeUsingCaught1;
                throw $_nativeUsingCaught1;
            } finally {
                Js::disposeUsing($_nativeDisposer1, $_nativeUsingError1);
            }
            return UndefinedValue::Value;
        });
    }
}
