<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/EmulationManager.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class EmulatedState implements \Nesk\Puphpeteer\Native\Runtime\JsObject
{
    private mixed $EmulatedState_state = UndefinedValue::Value;
    private mixed $EmulatedState_clientProvider = UndefinedValue::Value;
    private mixed $EmulatedState_updater = UndefinedValue::Value;

    public function __construct(mixed $initialState, mixed $clientProvider, mixed $updater)
    {
        $this->EmulatedState_state = $initialState;
        $this->EmulatedState_clientProvider = $clientProvider;
        $this->EmulatedState_updater = $updater;
        Js::invoke($this->EmulatedState_clientProvider, 'registerState', [$this]);
    }

    public function setState(mixed $state): mixed
    {
        return Js::async(function () use ($state) {
            $this->EmulatedState_state = $state;
            Js::await($this->sync());
            return UndefinedValue::Value;
        });
    }

    public function state(): mixed
    {
        return $this->EmulatedState_state;
    }

    public function sync(): mixed
    {
        return Js::async(function () {
            Js::await(Js::all(Js::invoke(Js::invoke($this->EmulatedState_clientProvider, 'clients', []), 'map', [function (mixed $client) {
    return ($this->EmulatedState_updater)($client, $this->EmulatedState_state);
}])));
            return UndefinedValue::Value;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'state' => $this->state(),
            default => UndefinedValue::Value,
        };
    }
}
