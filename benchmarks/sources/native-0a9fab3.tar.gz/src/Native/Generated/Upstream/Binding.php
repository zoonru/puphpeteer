<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Binding.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class Binding implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $Binding_name;
    private mixed $Binding_fn;
    private mixed $Binding_initSource;

    public function __construct(mixed $name, mixed $fn, mixed $initSource)
    {
        $this->Binding_name = UndefinedValue::Value;
        $this->Binding_fn = UndefinedValue::Value;
        $this->Binding_initSource = UndefinedValue::Value;
        $this->Binding_name = $name;
        $this->Binding_fn = $fn;
        $this->Binding_initSource = $initSource;
    }

    public function name(): mixed
    {
        return $this->Binding_name;
    }

    public function initSource(): mixed
    {
        return $this->Binding_initSource;
    }

    public function run(mixed $context, mixed $id, mixed $args, mixed $isTrivial): mixed
    {
        return Js::async(function () use ($context, $id, $args, $isTrivial) {
            $stack = new DisposableStackPolyfill();
            try {
                if (Js::truthy(!Js::truthy($isTrivial))) {
                    $handles = Js::await(Js::invoke($context, 'evaluateHandle', [new \Nesk\Puphpeteer\Native\JsFunction('(name, seq) => {
    // @ts-expect-error Code is evaluated in a different context.
    return globalThis[name].args.get(seq);
}'), $this->Binding_name, $id]));
                    $_nativeDisposer1 = Js::disposer($handles);
                    $_nativeUsingError1 = null;
                    try {
                        $properties = Js::await(Js::invoke($handles, 'getProperties', []));
                        foreach (Js::iterate($properties) as $_nativeItem2) {
                            $index = Js::get($_nativeItem2, 0);
                            $handle = Js::get($_nativeItem2, 1);
                            if (Js::truthy(Js::hasProperty($args, $index))) {
                                $_nativeSwitch3 = Js::get(Js::invoke($handle, 'remoteObject', []), 'subtype');
                                if (Js::strictEqual($_nativeSwitch3, 'node')) {
                                    Js::set($args, Js::number($index), $handle);
                                }
                                else {
                                    Js::invoke($stack, 'use', [$handle]);
                                }
                            } else {
                                Js::invoke($stack, 'use', [$handle]);
                            }
                        }
                    } catch (\Throwable $_nativeUsingCaught1) {
                        $_nativeUsingError1 = $_nativeUsingCaught1;
                        throw $_nativeUsingCaught1;
                    } finally {
                        Js::disposeUsing($_nativeDisposer1, $_nativeUsingError1);
                    }
                }
                Js::await(Js::invoke($context, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('(name, seq, result) => {
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).resolve(result);
    callbacks.delete(seq);
}'), $this->Binding_name, $id, Js::await(($this->Binding_fn)(...Js::iterate($args)))]));
                foreach (Js::iterate($args) as $arg) {
                    if (Js::truthy(($arg instanceof \Nesk\Puphpeteer\Native\JSHandle))) {
                        Js::invoke($stack, 'use', [$arg]);
                    }
                }
            } catch (\Throwable $error) {
                $error = Js::catchValue($error);
                if (Js::truthy(ErrorLikeHelpers::isErrorLike($error))) {
                    Js::await(Js::invoke(Js::invoke($context, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('(name, seq, message, stack) => {
    const error = new Error(message);
    error.stack = stack;
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).reject(error);
    callbacks.delete(seq);
}'), $this->Binding_name, $id, Js::get($error, 'message'), Js::get($error, 'stack')]), 'catch', [Js::debugError(...)]));
                } else {
                    Js::await(Js::invoke(Js::invoke($context, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('(name, seq, error) => {
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).reject(error);
    callbacks.delete(seq);
}'), $this->Binding_name, $id, $error]), 'catch', [Js::debugError(...)]));
                }
            }
            return UndefinedValue::Value;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'name' => $this->name(),
            'initSource' => $this->initSource(),
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
