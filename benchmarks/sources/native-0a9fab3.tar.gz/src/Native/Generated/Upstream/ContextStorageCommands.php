<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/BrowserContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait ContextStorageCommands
{

    public function cookies(): mixed
    {
        return Js::async(function () {
            $_nativeBinding1 = Js::await(Js::invoke($this->connection, 'send', ['Storage.getCookies', Js::object(['browserContextId' => $this->contextId])]));
            $cookies = Js::get($_nativeBinding1, 'cookies');
            return Js::invoke($cookies, 'map', [function (mixed $cookie) {
    return Js::assign(Js::object([]), $cookie, Js::object(['partitionKey' => (Js::truthy(Js::get($cookie, 'partitionKey')) ? Js::object(['sourceOrigin' => Js::get(Js::get($cookie, 'partitionKey'), 'topLevelSite'), 'hasCrossSiteAncestor' => Js::get(Js::get($cookie, 'partitionKey'), 'hasCrossSiteAncestor')]) : UndefinedValue::Value)]), Js::object(['sameParty' => Js::coalesce(Js::get($cookie, 'sameParty'), fn () => false)]));
}]);
        });
    }

    public function setCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            return Js::await(Js::invoke($this->connection, 'send', ['Storage.setCookies', Js::object(['browserContextId' => $this->contextId, 'cookies' => Js::invoke($cookies, 'map', [function (mixed $cookie) {
    return Js::assign(Js::object([]), $cookie, Js::object(['partitionKey' => CookieHelpers::convertCookiesPartitionKeyFromPuppeteerToCdp(Js::get($cookie, 'partitionKey'))]));
}])])]));
        });
    }

    public function overridePermissions(mixed $origin, mixed $permissions): mixed
    {
        return Js::async(function () use ($origin, $permissions) {
            $protocolPermissions = Js::invoke($permissions, 'map', [function (mixed $permission) {
    $protocolPermission = Js::invoke(BrowserConstants::permissions(), 'get', [$permission]);
    if (Js::truthy(!Js::truthy($protocolPermission))) {
        throw new \RuntimeException(Js::add('Unknown permission: ', $permission));
    }
    return $protocolPermission;
}]);
            Js::await(Js::invoke($this->connection, 'send', ['Browser.grantPermissions', Js::object(['origin' => $origin, 'browserContextId' => Js::logicalOr($this->contextId, fn () => UndefinedValue::Value), 'permissions' => $protocolPermissions])]));
            return UndefinedValue::Value;
        });
    }

    public function clearPermissionOverrides(): mixed
    {
        return Js::async(function () {
            Js::await(Js::invoke($this->connection, 'send', ['Browser.resetPermissions', Js::object(['browserContextId' => Js::logicalOr($this->contextId, fn () => UndefinedValue::Value)])]));
            return UndefinedValue::Value;
        });
    }

    public function browser(): mixed
    {
        return $this->browser;
    }
}
