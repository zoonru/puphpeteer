<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/JSHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait JSHandleCommands
{
    public function disposed(): mixed
    {
        return $this->released;
    }

    public function jsonValue(): mixed
    {
        return Js::async(function () {
            if (Js::truthy(!Js::truthy(Js::get($this->remote, 'objectId')))) {
                return (\Nesk\Puphpeteer\Native\JSHandle::value($this->remote));
            }
            $value = Js::await($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('object => {
    return object;
}')));
            if (Js::truthy(Js::strictEqual($value, UndefinedValue::Value))) {
                throw new \RuntimeException('Could not serialize referenced object');
            }
            return $value;
        });
    }

    public function asElement(): mixed
    {
        return null;
    }

    public function toString(): mixed
    {
        if (Js::truthy(!Js::truthy(Js::get($this->remote, 'objectId')))) {
            return Js::add('JSHandle:', \Nesk\Puphpeteer\Native\JSHandle::value($this->remote));
        }
        $type = Js::logicalOr(Js::get($this->remote, 'subtype'), fn () => Js::get($this->remote, 'type'));
        return Js::add('JSHandle@', $type);
    }

    public function id(): mixed
    {
        return Js::get($this->remote, 'objectId');
    }

    public function remoteObject(): mixed
    {
        return $this->remote;
    }

    public function getProperties(): mixed
    {
        return Js::async(function () {
            $response = Js::await(Js::invoke($this->executionContext->session, 'send', ['Runtime.getProperties', Js::object(['objectId' => (Js::get($this->remote, 'objectId')), 'ownProperties' => true])]));
            $result = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
            foreach (Js::iterate(Js::get($response, 'result')) as $property) {
                if (Js::truthy(Js::logicalOr(!Js::truthy(Js::get($property, 'enumerable')), fn () => !Js::truthy(Js::get($property, 'value'))))) {
                    continue;
                }
                Js::invoke($result, 'set', [Js::get($property, 'name'), Js::invoke($this->executionContext, 'createCdpHandle', [Js::get($property, 'value')])]);
            }
            return $result;
        });
    }

    public function dispose(): mixed
    {
        return Js::async(function () {
            if (Js::truthy($this->released)) {
                return UndefinedValue::Value;
            }
            $this->released = true;
            Js::await(PageDiagnosticsHelpers::releaseObject($this->executionContext->session, $this->remote));
            return UndefinedValue::Value;
        });
    }
}
