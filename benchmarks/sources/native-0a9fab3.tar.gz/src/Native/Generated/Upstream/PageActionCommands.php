<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageActionCommands
{

    public function click(mixed $selector, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::invoke($this->mainFrame(), 'click', [$selector, $options]);
    }

    public function hover(mixed $selector): mixed
    {
        return Js::invoke($this->mainFrame(), 'hover', [$selector]);
    }

    public function tap(mixed $selector): mixed
    {
        return Js::invoke($this->mainFrame(), 'tap', [$selector]);
    }

    public function type(mixed $selector, mixed $text, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::invoke($this->mainFrame(), 'type', [$selector, $text, $options]);
    }

    public function focus(mixed $selector): mixed
    {
        return Js::invoke($this->mainFrame(), 'focus', [$selector]);
    }
}
