<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/disposable.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class DisposableStackPolyfill implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject, \Nesk\Puphpeteer\Native\Runtime\JsSymbolObject
{
    private mixed $DisposableStackPolyfill_disposed;
    private mixed $DisposableStackPolyfill_stack;
    public mixed $sourceStringTag;

    public function disposed(): mixed
    {
        return $this->DisposableStackPolyfill_disposed;
    }

    public function dispose(): mixed
    {
        $this->disposeResources();
        return UndefinedValue::Value;
    }

    public function use(mixed $value): mixed
    {
        if (Js::truthy(Js::logicalAnd($value, fn () => Js::strictEqual(Js::typeOf(Js::get($value, \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose)), 'function')))) {
            Js::invoke($this->DisposableStackPolyfill_stack, 'push', [$value]);
        }
        return $value;
    }

    public function adopt(mixed $value, mixed $onDispose): mixed
    {
        Js::invoke($this->DisposableStackPolyfill_stack, 'push', [new \Nesk\Puphpeteer\Native\Runtime\SymbolObject([[\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose, function () use ($value, $onDispose) {
    $onDispose($value);
    return UndefinedValue::Value;
}]])]);
        return $value;
    }

    public function defer(mixed $onDispose): mixed
    {
        Js::invoke($this->DisposableStackPolyfill_stack, 'push', [new \Nesk\Puphpeteer\Native\Runtime\SymbolObject([[\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose, function () use ($onDispose) {
    $onDispose();
    return UndefinedValue::Value;
}]])]);
        return UndefinedValue::Value;
    }

    public function move(): mixed
    {
        if (Js::truthy($this->DisposableStackPolyfill_disposed)) {
            throw new \Nesk\Puphpeteer\Native\Runtime\ReferenceError('A disposed stack can not use anything new');
        }
        $stack = new DisposableStackPolyfill();
        ($stack)->DisposableStackPolyfill_stack = $this->DisposableStackPolyfill_stack;
        $this->DisposableStackPolyfill_stack = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->DisposableStackPolyfill_disposed = true;
        return $stack;
    }

    public function disposeResources(): mixed
    {
        if (Js::truthy($this->DisposableStackPolyfill_disposed)) {
            return UndefinedValue::Value;
        }
        $this->DisposableStackPolyfill_disposed = true;
        $errors = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        foreach (Js::iterate(Js::invoke($this->DisposableStackPolyfill_stack, 'reverse', [])) as $resource) {
            try {
                Js::call(Js::get($resource, \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose), []);
            } catch (\Throwable $e) {
                Js::invoke($errors, 'push', [$e]);
            }
        }
        if (Js::truthy(Js::strictEqual(Js::get($errors, 'length'), 1))) {
            throw Js::get($errors, 0);
        } else {
            if (Js::truthy(Js::numeric('>', Js::get($errors, 'length'), 1))) {
                $suppressed = null;
                foreach (Js::iterate($errors) as $error) {
                    if (Js::truthy(Js::strictEqual($suppressed, null))) {
                        $suppressed = $error;
                    } else {
                        $suppressed = new SuppressedErrorPolyfill($error, $suppressed);
                    }
                }
                throw $suppressed;
            }
        }
        return UndefinedValue::Value;
    }

    public function __construct()
    {
        $this->DisposableStackPolyfill_disposed = false;
        $this->DisposableStackPolyfill_stack = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->sourceStringTag = 'DisposableStack';
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'disposed' => $this->disposed(),
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }

    public function getJsSymbol(\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol $symbol): mixed
    {
        return match ($symbol) {
            \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose => $this->disposeResources(...),
            \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::ToStringTag => $this->sourceStringTag,
            default => UndefinedValue::Value,
        };
    }
}
