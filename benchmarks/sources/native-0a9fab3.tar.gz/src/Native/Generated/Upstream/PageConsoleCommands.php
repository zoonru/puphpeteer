<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageConsoleCommands
{

    private function CdpPage_onConsoleAPI(mixed $world, mixed $event): mixed
    {
        $values = Js::invoke(Js::get($event, 'args'), 'map', [function (mixed $arg) use ($world) {
    return Js::invoke($world, 'createCdpHandle', [$arg]);
}]);
        if (Js::truthy(!Js::truthy($this->listenerCount(Js::get(Js::object(['Console'=>'console']), 'Console'))))) {
            Js::invoke($values, 'forEach', [function (mixed $arg) {
    return Js::invoke($arg, 'dispose', []);
}]);
            return UndefinedValue::Value;
        }
        $textTokens = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        foreach (Js::iterate($values) as $arg) {
            $remoteObject = Js::invoke($arg, 'remoteObject', []);
            if (Js::truthy(Js::get($remoteObject, 'objectId'))) {
                Js::invoke($textTokens, 'push', [Js::invoke($arg, 'toString', [])]);
            } else {
                Js::invoke($textTokens, 'push', [\Nesk\Puphpeteer\Native\JSHandle::value($remoteObject)]);
            }
        }
        $stackTraceLocations = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        if (Js::truthy(Js::get($event, 'stackTrace'))) {
            foreach (Js::iterate(Js::get(Js::get($event, 'stackTrace'), 'callFrames')) as $callFrame) {
                Js::invoke($stackTraceLocations, 'push', [Js::object(['url' => Js::get($callFrame, 'url'), 'lineNumber' => Js::get($callFrame, 'lineNumber'), 'columnNumber' => Js::get($callFrame, 'columnNumber')])]);
            }
        }
        $targetId = UndefinedValue::Value;
        if (Js::truthy((Js::get(Js::get($world, 'environment'), 'client') instanceof \Nesk\Puphpeteer\Native\Session))) {
            $targetId = Js::get(Js::invoke(Js::get(Js::get($world, 'environment'), 'client'), 'target', []), '_targetId');
        }
        $message = new \Nesk\Puphpeteer\Native\ConsoleMessage(PageDiagnosticsHelpers::convertConsoleMessageLevel(Js::get($event, 'type')), Js::invoke($textTokens, 'join', [' ']), $values, $stackTraceLocations, UndefinedValue::Value, Js::get($event, 'stackTrace'), $targetId);
        $this->emit(Js::get(Js::object(['Console'=>'console']), 'Console'), $message);
        return UndefinedValue::Value;
    }
}
