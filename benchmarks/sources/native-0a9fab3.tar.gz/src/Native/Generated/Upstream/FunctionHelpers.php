<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/Function.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class FunctionHelpers
{
    public static function stringifyFunction(mixed $fn): mixed
    {
        $value = Js::invoke($fn, 'toString', []);
        if (Js::truthy(Js::logicalOr(Js::invoke($value, 'match', [FunctionPatterns::get(0)]), fn () => Js::invoke($value, 'match', [FunctionPatterns::get(1)])))) {
            return $value;
        }
        $isArrow = Js::logicalOr(Js::logicalOr(Js::invoke($value, 'startsWith', ['(']), fn () => Js::invoke($value, 'match', [FunctionPatterns::get(2)])), fn () => Js::invoke($value, 'match', [FunctionPatterns::get(3)]));
        if (Js::truthy($isArrow)) {
            return $value;
        }
        $prefix = 'function ';
        if (Js::truthy(Js::invoke($value, 'startsWith', ['async ']))) {
            $prefix = ('async ' . Js::string($prefix) . '');
            $value = Js::invoke($value, 'substring', [Js::get('async ', 'length')]);
        }
        return ('' . Js::string($prefix) . '' . Js::string($value) . '');
    }
}
