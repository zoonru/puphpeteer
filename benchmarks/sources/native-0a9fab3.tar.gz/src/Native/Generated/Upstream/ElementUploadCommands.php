<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ElementHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait ElementUploadCommands
{
    public function uploadFile(mixed ...$files): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($files) {
            $files = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($files));
            $isMultiple = Js::await($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    return element.multiple;
}')));
            Js::assert(Js::logicalOr(Js::numeric('<=', Js::get($files, 'length'), 1), fn () => $isMultiple), 'Multiple file uploads only work with <input type=file multiple>');
            $path = Js::get(Js::get(Js::object(['value'=>Js::object(['path'=>new \Nesk\Puphpeteer\Native\Runtime\NodePath()])]), 'value'), 'path');
            if (Js::truthy($path)) {
                $files = Js::invoke($files, 'map', [function (mixed $filePath) use ($path) {
    if (Js::truthy(Js::logicalOr(Js::invoke(Js::get($path, 'win32'), 'isAbsolute', [$filePath]), fn () => Js::invoke(Js::get($path, 'posix'), 'isAbsolute', [$filePath])))) {
        return $filePath;
    } else {
        return Js::invoke($path, 'resolve', [$filePath]);
    }
}]);
            }
            if (Js::truthy(Js::strictEqual(Js::get($files, 'length'), 0))) {
                Js::await($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    element.files = new DataTransfer().files;
    // Dispatch events for this case because it should behave akin to a user action.
    element.dispatchEvent(new Event(\'input\', { bubbles: true, composed: true }));
    element.dispatchEvent(new Event(\'change\', { bubbles: true }));
}')));
                return UndefinedValue::Value;
            }
            $_nativeBinding1 = Js::await(Js::invoke($this->context()->session, 'send', ['DOM.describeNode', Js::object(['objectId' => $this->id()])]));
            $_nativeBinding2 = Js::get($_nativeBinding1, 'node');
            $backendNodeId = Js::get($_nativeBinding2, 'backendNodeId');
            Js::await(Js::invoke($this->context()->session, 'send', ['DOM.setFileInputFiles', Js::object(['objectId' => $this->id(), 'files' => $files, 'backendNodeId' => $backendNodeId])]));
            return UndefinedValue::Value;
        });
    }
}
