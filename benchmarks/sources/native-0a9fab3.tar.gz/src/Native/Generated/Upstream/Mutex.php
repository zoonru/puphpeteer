<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/Mutex.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
class Mutex
{
    public static mixed $Guard = MutexGuard::class;
    private mixed $Mutex_locked;
    private mixed $Mutex_acquirers;
    public function acquire(mixed $onRelease = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($onRelease) {
            if (Js::truthy(!Js::truthy($this->Mutex_locked))) {
                $this->Mutex_locked = true;
                return new (self::$Guard)($this);
            }
            $deferred = Deferred::create();
            Js::invoke($this->Mutex_acquirers, 'push', [Js::bindMethod($deferred, 'resolve')]);
            Js::await(Js::invoke($deferred, 'valueOrThrow', []));
            return new (self::$Guard)($this, $onRelease);
        });
    }
    public function release(): mixed
    {
        $resolve = Js::invoke($this->Mutex_acquirers, 'shift', []);
        if (Js::truthy(!Js::truthy($resolve))) {
            $this->Mutex_locked = false;
            return UndefinedValue::Value;
        }
        $resolve();
        return UndefinedValue::Value;
    }
    public function __construct()
    {
        $this->Mutex_locked = false;
        $this->Mutex_acquirers = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
    }
}
