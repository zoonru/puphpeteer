<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class EvaluationSource
{
    public static function getSourceUrlComment(mixed $url): mixed
    {
        return ('//# sourceURL=' . Js::string($url) . '');
    }

    public static function decorate(mixed $expression): mixed
    {
        $sourceUrlComment = self::getSourceUrlComment('pptr:internal');
        return (Js::truthy(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\SourceUrlPattern(), 'test', [$expression])) ? $expression : ('' . Js::string($expression) . '
' . Js::string($sourceUrlComment) . '
'));
    }
}
