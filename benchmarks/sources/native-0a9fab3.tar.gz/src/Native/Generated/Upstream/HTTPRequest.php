<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/HTTPRequest.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

abstract class HTTPRequest implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    public mixed $_interceptionId;
    public mixed $_failureText;
    public mixed $_response;
    public mixed $_fromMemoryCache;
    public mixed $_redirectChain;
    protected mixed $interception;

    abstract public function id(): mixed;

    abstract public function client(): mixed;

    public function __construct()
    {
        $this->_interceptionId = UndefinedValue::Value;
        $this->_failureText = null;
        $this->_response = null;
        $this->_fromMemoryCache = false;
        $this->_redirectChain = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $this->interception = Js::object(['enabled' => false, 'handled' => false, 'handlers' => new \Nesk\Puphpeteer\Native\Runtime\JsArray([]), 'resolutionState' => Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'None')]), 'requestOverrides' => Js::object([]), 'response' => null, 'abortReason' => null]);
    }

    abstract public function url(): mixed;

    public function continueRequestOverrides(): mixed
    {
        return Js::get($this->interception, 'requestOverrides');
    }

    public function responseForRequest(): mixed
    {
        return Js::get($this->interception, 'response');
    }

    public function abortErrorReason(): mixed
    {
        return Js::get($this->interception, 'abortReason');
    }

    public function interceptResolutionState(): mixed
    {
        if (Js::truthy(!Js::truthy(Js::get($this->interception, 'enabled')))) {
            return Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Disabled')]);
        }
        if (Js::truthy(Js::get($this->interception, 'handled'))) {
            return Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'AlreadyHandled')]);
        }
        return Js::assign(Js::object([]), Js::get($this->interception, 'resolutionState'));
    }

    public function isInterceptResolutionHandled(): mixed
    {
        return Js::get($this->interception, 'handled');
    }

    public function enqueueInterceptAction(mixed $pendingHandler): mixed
    {
        Js::invoke(Js::get($this->interception, 'handlers'), 'push', [$pendingHandler]);
        return UndefinedValue::Value;
    }

    abstract public function _abort(mixed $errorReason): mixed;

    abstract public function _respond(mixed $response): mixed;

    abstract public function _continue(mixed $overrides): mixed;

    public function finalizeInterceptions(): mixed
    {
        return Js::async(function () {
            Js::await(Js::invoke(Js::get($this->interception, 'handlers'), 'reduce', [function (mixed $promiseChain, mixed $interceptAction) {
    return Js::invoke($promiseChain, 'then', [$interceptAction]);
}, Js::resolve()]));
            Js::set($this->interception, 'handlers', new \Nesk\Puphpeteer\Native\Runtime\JsArray([]));
            $_nativeBinding1 = $this->interceptResolutionState();
            $action = Js::get($_nativeBinding1, 'action');
            $_nativeSwitch2 = $action;
            if (Js::strictEqual($_nativeSwitch2, 'abort')) {
                return Js::await($this->_abort(Js::get($this->interception, 'abortReason')));
            }
            else if (Js::strictEqual($_nativeSwitch2, 'respond')) {
                if (Js::truthy(Js::strictEqual(Js::get($this->interception, 'response'), null))) {
                    throw new \RuntimeException('Response is missing for the interception');
                }
                return Js::await($this->_respond(Js::get($this->interception, 'response')));
            }
            else if (Js::strictEqual($_nativeSwitch2, 'continue')) {
                return Js::await($this->_continue(Js::get($this->interception, 'requestOverrides')));
            }
            return UndefinedValue::Value;
        });
    }

    abstract public function resourceType(): mixed;

    abstract public function method(): mixed;

    abstract public function postData(): mixed;

    abstract public function hasPostData(): mixed;

    abstract public function fetchPostData(): mixed;

    abstract public function headers(): mixed;

    abstract public function response(): mixed;

    abstract public function frame(): mixed;

    abstract public function isNavigationRequest(): mixed;

    abstract public function initiator(): mixed;

    abstract public function redirectChain(): mixed;

    abstract public function failure(): mixed;

    protected function verifyInterception(): mixed
    {
        Js::assert(Js::get($this->interception, 'enabled'), 'Request Interception is not enabled!');
        Js::assert(!Js::truthy(Js::get($this->interception, 'handled')), 'Request is already handled!');
        return UndefinedValue::Value;
    }

    abstract protected function canBeIntercepted(): mixed;

    public function continue(mixed $overrides = UndefinedValue::Value, mixed $priority = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($overrides, $priority) {
            if ($overrides === UndefinedValue::Value) { $overrides = Js::object([]); }
            $this->verifyInterception();
            if (Js::truthy(!Js::truthy($this->canBeIntercepted()))) {
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::strictEqual($priority, UndefinedValue::Value))) {
                return Js::await($this->_continue($overrides));
            }
            Js::set($this->interception, 'requestOverrides', $overrides);
            if (Js::truthy(Js::logicalOr(Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'priority'), UndefinedValue::Value), fn () => Js::numeric('>', $priority, Js::get(Js::get($this->interception, 'resolutionState'), 'priority'))))) {
                Js::set($this->interception, 'resolutionState', Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Continue'), 'priority' => $priority]));
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::strictEqual($priority, Js::get(Js::get($this->interception, 'resolutionState'), 'priority')))) {
                if (Js::truthy(Js::logicalOr(Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'action'), 'abort'), fn () => Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'action'), 'respond')))) {
                    return UndefinedValue::Value;
                }
                Js::set(Js::get($this->interception, 'resolutionState'), 'action', Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Continue'));
            }
            return UndefinedValue::Value;
        });
    }

    public function respond(mixed $response, mixed $priority = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($response, $priority) {
            $this->verifyInterception();
            if (Js::truthy(!Js::truthy($this->canBeIntercepted()))) {
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::strictEqual($priority, UndefinedValue::Value))) {
                return Js::await($this->_respond($response));
            }
            Js::set($this->interception, 'response', $response);
            if (Js::truthy(Js::logicalOr(Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'priority'), UndefinedValue::Value), fn () => Js::numeric('>', $priority, Js::get(Js::get($this->interception, 'resolutionState'), 'priority'))))) {
                Js::set($this->interception, 'resolutionState', Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Respond'), 'priority' => $priority]));
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::strictEqual($priority, Js::get(Js::get($this->interception, 'resolutionState'), 'priority')))) {
                if (Js::truthy(Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'action'), 'abort'))) {
                    return UndefinedValue::Value;
                }
                Js::set(Js::get($this->interception, 'resolutionState'), 'action', Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Respond'));
            }
            return UndefinedValue::Value;
        });
    }

    public function abort(mixed $errorCode = 'failed', mixed $priority = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($errorCode, $priority) {
            $this->verifyInterception();
            if (Js::truthy(!Js::truthy($this->canBeIntercepted()))) {
                return UndefinedValue::Value;
            }
            $errorReason = Js::get((Js::object(['aborted' => 'Aborted', 'accessdenied' => 'AccessDenied', 'addressunreachable' => 'AddressUnreachable', 'blockedbyclient' => 'BlockedByClient', 'blockedbyresponse' => 'BlockedByResponse', 'connectionaborted' => 'ConnectionAborted', 'connectionclosed' => 'ConnectionClosed', 'connectionfailed' => 'ConnectionFailed', 'connectionrefused' => 'ConnectionRefused', 'connectionreset' => 'ConnectionReset', 'internetdisconnected' => 'InternetDisconnected', 'namenotresolved' => 'NameNotResolved', 'timedout' => 'TimedOut', 'failed' => 'Failed'])), $errorCode);
            Js::assert($errorReason, Js::add('Unknown error code: ', $errorCode));
            if (Js::truthy(Js::strictEqual($priority, UndefinedValue::Value))) {
                return Js::await($this->_abort($errorReason));
            }
            Js::set($this->interception, 'abortReason', $errorReason);
            if (Js::truthy(Js::logicalOr(Js::strictEqual(Js::get(Js::get($this->interception, 'resolutionState'), 'priority'), UndefinedValue::Value), fn () => Js::numeric('>=', $priority, Js::get(Js::get($this->interception, 'resolutionState'), 'priority'))))) {
                Js::set($this->interception, 'resolutionState', Js::object(['action' => Js::get(Js::object(['Abort' => 'abort', 'Respond' => 'respond', 'Continue' => 'continue', 'Disabled' => 'disabled', 'None' => 'none', 'AlreadyHandled' => 'already-handled']), 'Abort'), 'priority' => $priority]));
                return UndefinedValue::Value;
            }
            return UndefinedValue::Value;
        });
    }

    public static function getResponse(mixed $body): mixed
    {
        $byteBody = (Js::truthy(Js::isString($body)) ? Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\TextEncoder(), 'encode', [$body]) : $body);
        return Js::object(['contentLength' => Js::get($byteBody, 'byteLength'), 'base64' => Js::bytesToBase64($byteBody)]);
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            '_interceptionId' => $this->_interceptionId,
            '_failureText' => $this->_failureText,
            '_response' => $this->_response,
            '_fromMemoryCache' => $this->_fromMemoryCache,
            '_redirectChain' => $this->_redirectChain,
            'id' => $this->id(),
            'client' => $this->client(),
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            case '_interceptionId': return $this->_interceptionId = $value;
            case '_failureText': return $this->_failureText = $value;
            case '_response': return $this->_response = $value;
            case '_fromMemoryCache': return $this->_fromMemoryCache = $value;
            case '_redirectChain': return $this->_redirectChain = $value;
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
