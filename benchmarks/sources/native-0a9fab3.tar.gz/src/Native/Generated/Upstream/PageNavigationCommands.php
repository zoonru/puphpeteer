<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageNavigationCommands
{

    public function goBack(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            return Js::await($this->CdpPage_go((-1), $options));
        });
    }

    public function goForward(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            return Js::await($this->CdpPage_go(1, $options));
        });
    }

    private function CdpPage_go(mixed $delta, mixed $options): mixed
    {
        return Js::async(function () use ($delta, $options) {
            $history = Js::await(Js::invoke($this->session, 'send', ['Page.getNavigationHistory']));
            $entry = Js::get(Js::get($history, 'entries'), Js::add(Js::get($history, 'currentIndex'), $delta));
            if (Js::truthy(!Js::truthy($entry))) {
                throw new \RuntimeException('History entry to navigate to not found.');
            }
            $result = Js::await(Js::all([$this->waitForNavigation($options), Js::invoke($this->session, 'send', ['Page.navigateToHistoryEntry', Js::object(['entryId' => Js::get($entry, 'id')])])]));
            return Js::get($result, 0);
        });
    }
}
