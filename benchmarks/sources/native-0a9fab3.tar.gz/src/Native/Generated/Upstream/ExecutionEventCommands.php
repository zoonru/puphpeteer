<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait ExecutionEventCommands
{
    public function dispatchBindingEvent(mixed $event): mixed
    {
        return Js::async(function () use ($event) {
            if (Js::truthy(!Js::strictEqual(Js::get($event, 'executionContextId'), $this->id))) {
                return UndefinedValue::Value;
            }
            $payload = UndefinedValue::Value;
            try {
                $payload = Js::parseJsonValue(Js::get($event, 'payload'));
            } catch (\Throwable) {
                return UndefinedValue::Value;
            }
            $_nativeBinding1 = $payload;
            $type = Js::get($_nativeBinding1, 'type');
            $name = Js::get($_nativeBinding1, 'name');
            $seq = Js::get($_nativeBinding1, 'seq');
            $args = Js::get($_nativeBinding1, 'args');
            $isTrivial = Js::get($_nativeBinding1, 'isTrivial');
            if (Js::truthy(!Js::strictEqual($type, 'internal'))) {
                $this->emit('bindingcalled', $event);
                return UndefinedValue::Value;
            }
            if (Js::truthy(!Js::truthy(Js::invoke($this->sourceBindings, 'has', [$name])))) {
                $this->emit('bindingcalled', $event);
                return UndefinedValue::Value;
            }
            try {
                $binding = Js::invoke($this->sourceBindings, 'get', [$name]);
                Js::await(Js::optionalInvoke($binding, 'run', fn () => [$this, $seq, $args, $isTrivial]));
            } catch (\Throwable $err) {
                Js::debugError($err);
            }
            return UndefinedValue::Value;
        });
    }
    public function dispatchConsoleEvent(mixed $event): mixed
    {
        if (Js::truthy(!Js::strictEqual(Js::get($event, 'executionContextId'), $this->id))) {
            return UndefinedValue::Value;
        }
        $this->emit('consoleapicalled', $event);
        return UndefinedValue::Value;
    }
}
