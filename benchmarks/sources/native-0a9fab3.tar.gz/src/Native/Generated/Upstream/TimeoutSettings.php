<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/TimeoutSettings.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class TimeoutSettings
{
    protected mixed $TimeoutSettings_defaultTimeout = UndefinedValue::Value;
    protected mixed $TimeoutSettings_defaultNavigationTimeout = UndefinedValue::Value;

    public function __construct()
    {
        $this->TimeoutSettings_defaultTimeout = null;
        $this->TimeoutSettings_defaultNavigationTimeout = null;
    }

    public function setDefaultTimeout(mixed $timeout): mixed
    {
        $this->TimeoutSettings_defaultTimeout = $timeout;
        return UndefinedValue::Value;
    }

    public function setDefaultNavigationTimeout(mixed $timeout): mixed
    {
        $this->TimeoutSettings_defaultNavigationTimeout = $timeout;
        return UndefinedValue::Value;
    }

    public function navigationTimeout(): mixed
    {
        if (Js::truthy(!Js::strictEqual($this->TimeoutSettings_defaultNavigationTimeout, null))) {
            return $this->TimeoutSettings_defaultNavigationTimeout;
        }
        if (Js::truthy(!Js::strictEqual($this->TimeoutSettings_defaultTimeout, null))) {
            return $this->TimeoutSettings_defaultTimeout;
        }
        return 30000;
    }

    public function timeout(): mixed
    {
        if (Js::truthy(!Js::strictEqual($this->TimeoutSettings_defaultTimeout, null))) {
            return $this->TimeoutSettings_defaultTimeout;
        }
        return 30000;
    }
}
