<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Coverage.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class JSCoverage implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $JSCoverage_client;
    private mixed $JSCoverage_enabled;
    private mixed $JSCoverage_scriptURLs;
    private mixed $JSCoverage_scriptSources;
    private mixed $JSCoverage_subscriptions;
    private mixed $JSCoverage_resetOnNavigation;
    private mixed $JSCoverage_reportAnonymousScripts;
    private mixed $JSCoverage_includeRawScriptCoverage;

    public function __construct(mixed $client)
    {
        $this->JSCoverage_client = UndefinedValue::Value;
        $this->JSCoverage_enabled = false;
        $this->JSCoverage_scriptURLs = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        $this->JSCoverage_scriptSources = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        $this->JSCoverage_subscriptions = UndefinedValue::Value;
        $this->JSCoverage_resetOnNavigation = false;
        $this->JSCoverage_reportAnonymousScripts = false;
        $this->JSCoverage_includeRawScriptCoverage = false;
        $this->JSCoverage_client = $client;
    }

    public function updateClient(mixed $client): mixed
    {
        $this->JSCoverage_client = $client;
        return UndefinedValue::Value;
    }

    public function start(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            Js::assert(!Js::truthy($this->JSCoverage_enabled), 'JSCoverage is already enabled');
            $_nativeBinding1 = $options;
            $resetOnNavigation = Js::defaultValue(Js::get($_nativeBinding1, 'resetOnNavigation'), fn () => true);
            $reportAnonymousScripts = Js::defaultValue(Js::get($_nativeBinding1, 'reportAnonymousScripts'), fn () => false);
            $includeRawScriptCoverage = Js::defaultValue(Js::get($_nativeBinding1, 'includeRawScriptCoverage'), fn () => false);
            $useBlockCoverage = Js::defaultValue(Js::get($_nativeBinding1, 'useBlockCoverage'), fn () => true);
            $this->JSCoverage_resetOnNavigation = $resetOnNavigation;
            $this->JSCoverage_reportAnonymousScripts = $reportAnonymousScripts;
            $this->JSCoverage_includeRawScriptCoverage = $includeRawScriptCoverage;
            $this->JSCoverage_enabled = true;
            Js::invoke($this->JSCoverage_scriptURLs, 'clear', []);
            Js::invoke($this->JSCoverage_scriptSources, 'clear', []);
            $this->JSCoverage_subscriptions = new DisposableStackPolyfill();
            $clientEmitter = Js::invoke($this->JSCoverage_subscriptions, 'use', [new \Nesk\Puphpeteer\Native\Runtime\TransportEventEmitter($this->JSCoverage_client)]);
            Js::invoke($clientEmitter, 'on', ['Debugger.scriptParsed', $this->JSCoverage_onScriptParsed(...)]);
            Js::invoke($clientEmitter, 'on', ['Runtime.executionContextsCleared', $this->JSCoverage_onExecutionContextsCleared(...)]);
            Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($this->JSCoverage_client, 'send', ['Profiler.enable']), Js::invoke($this->JSCoverage_client, 'send', ['Profiler.startPreciseCoverage', Js::object(['callCount' => $this->JSCoverage_includeRawScriptCoverage, 'detailed' => $useBlockCoverage])]), Js::invoke($this->JSCoverage_client, 'send', ['Debugger.enable']), Js::invoke($this->JSCoverage_client, 'send', ['Debugger.setSkipAllPauses', Js::object(['skip' => true])])])));
            return UndefinedValue::Value;
        });
    }

    private function JSCoverage_onExecutionContextsCleared(): mixed
    {
        if (Js::truthy(!Js::truthy($this->JSCoverage_resetOnNavigation))) {
            return UndefinedValue::Value;
        }
        Js::invoke($this->JSCoverage_scriptURLs, 'clear', []);
        Js::invoke($this->JSCoverage_scriptSources, 'clear', []);
        return UndefinedValue::Value;
    }

    private function JSCoverage_onScriptParsed(mixed $event): mixed
    {
        return Js::async(function () use ($event) {
            if (Js::truthy(CoverageHelpers::isPuppeteerURL(Js::get($event, 'url')))) {
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::logicalAnd(!Js::truthy(Js::get($event, 'url')), fn () => !Js::truthy($this->JSCoverage_reportAnonymousScripts)))) {
                return UndefinedValue::Value;
            }
            try {
                $response = Js::await(Js::invoke($this->JSCoverage_client, 'send', ['Debugger.getScriptSource', Js::object(['scriptId' => Js::get($event, 'scriptId')])]));
                Js::invoke($this->JSCoverage_scriptURLs, 'set', [Js::get($event, 'scriptId'), Js::get($event, 'url')]);
                Js::invoke($this->JSCoverage_scriptSources, 'set', [Js::get($event, 'scriptId'), Js::get($response, 'scriptSource')]);
            } catch (\Throwable $error) {
                Js::debugError($error);
            }
            return UndefinedValue::Value;
        });
    }

    public function stop(): mixed
    {
        return Js::async(function () {
            Js::assert($this->JSCoverage_enabled, 'JSCoverage is not enabled');
            $this->JSCoverage_enabled = false;
            $result = Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($this->JSCoverage_client, 'send', ['Profiler.takePreciseCoverage']), Js::invoke($this->JSCoverage_client, 'send', ['Profiler.stopPreciseCoverage']), Js::invoke($this->JSCoverage_client, 'send', ['Profiler.disable']), Js::invoke($this->JSCoverage_client, 'send', ['Debugger.disable'])])));
            Js::optionalInvoke($this->JSCoverage_subscriptions, 'dispose', fn () => []);
            $coverage = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
            $profileResponse = Js::get($result, 0);
            foreach (Js::iterate(Js::get($profileResponse, 'result')) as $entry) {
                $url = Js::invoke($this->JSCoverage_scriptURLs, 'get', [Js::get($entry, 'scriptId')]);
                if (Js::truthy(Js::logicalAnd(!Js::truthy($url), fn () => $this->JSCoverage_reportAnonymousScripts))) {
                    $url = Js::add('debugger://VM', Js::get($entry, 'scriptId'));
                }
                $text = Js::invoke($this->JSCoverage_scriptSources, 'get', [Js::get($entry, 'scriptId')]);
                if (Js::truthy(Js::logicalOr(Js::strictEqual($text, UndefinedValue::Value), fn () => Js::strictEqual($url, UndefinedValue::Value)))) {
                    continue;
                }
                $flattenRanges = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
                foreach (Js::iterate(Js::get($entry, 'functions')) as $func) {
                    Js::invoke($flattenRanges, 'push', [...Js::iterate(Js::get($func, 'ranges'))]);
                }
                $ranges = CoverageHelpers::convertToDisjointRanges($flattenRanges);
                if (Js::truthy(!Js::truthy($this->JSCoverage_includeRawScriptCoverage))) {
                    Js::invoke($coverage, 'push', [Js::object(['url' => $url, 'ranges' => $ranges, 'text' => $text])]);
                } else {
                    Js::invoke($coverage, 'push', [Js::object(['url' => $url, 'ranges' => $ranges, 'text' => $text, 'rawScriptCoverage' => $entry])]);
                }
            }
            return $coverage;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
