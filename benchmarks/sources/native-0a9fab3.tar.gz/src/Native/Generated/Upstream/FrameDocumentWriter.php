<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameDocumentWriter
{

    public function setFrameContent(mixed $content): mixed
    {
        return Js::async(function () use ($content) {
            return Js::await($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('html => {
    document.open();
    document.write(html);
    document.close();
}'), $content));
        });
    }
}
