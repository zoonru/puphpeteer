<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageCookieCommands
{

    public function cookies(mixed ...$urls): mixed
    {
        return Js::async(function () use ($urls) {
            $urls = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($urls));
            $originalCookies = Js::get((Js::await(Js::invoke($this->session, 'send', ['Network.getCookies', Js::object(['urls' => (Js::truthy(Js::get($urls, 'length')) ? $urls : new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->url()]))])]))), 'cookies');
            $unsupportedCookieAttributes = new \Nesk\Puphpeteer\Native\Runtime\JsArray(['sourcePort']);
            $filterUnsupportedAttributes = function (mixed $cookie) use ($unsupportedCookieAttributes) {
    foreach (Js::iterate($unsupportedCookieAttributes) as $attr) {
        Js::deleteProperty($cookie, $attr);
    }
    return $cookie;
};
            return Js::invoke(Js::invoke($originalCookies, 'map', [$filterUnsupportedAttributes]), 'map', [function (mixed $cookie) {
    return Js::assign(Js::object([]), $cookie, Js::object(['partitionKey' => (Js::truthy(Js::get($cookie, 'partitionKey')) ? Js::get(Js::get($cookie, 'partitionKey'), 'topLevelSite') : UndefinedValue::Value)]), Js::object(['sameParty' => Js::coalesce(Js::get($cookie, 'sameParty'), fn () => false)]));
}]);
        });
    }

    public function setCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            $pageURL = $this->url();
            $startsWithHTTP = Js::invoke($pageURL, 'startsWith', ['http']);
            $items = Js::invoke($cookies, 'map', [function (mixed $cookie) use ($pageURL, $startsWithHTTP) {
    $item = Js::assign(Js::object([]), $cookie);
    if (Js::truthy(Js::logicalAnd(!Js::truthy(Js::get($item, 'url')), fn () => $startsWithHTTP))) {
        Js::set($item, 'url', $pageURL);
    }
    Js::assert(!Js::strictEqual(Js::get($item, 'url'), 'about:blank'), ('Blank page can not have cookie "' . Js::string(Js::get($item, 'name')) . '"'));
    Js::assert(!Js::truthy(Js::stringStartsWith(Js::logicalOr(Js::get($item, 'url'), fn () => ''), 'data:')), ('Data URL page can not have cookie "' . Js::string(Js::get($item, 'name')) . '"'));
    return $item;
}]);
            Js::await($this->deleteCookie(...Js::iterate($items)));
            if (Js::truthy(Js::get($items, 'length'))) {
                Js::await(Js::invoke($this->session, 'send', ['Network.setCookies', Js::object(['cookies' => Js::invoke($items, 'map', [function (mixed $cookieParam) {
    return Js::assign(Js::object([]), $cookieParam, Js::object(['partitionKey' => CookieHelpers::convertCookiesPartitionKeyFromPuppeteerToCdp(Js::get($cookieParam, 'partitionKey'))]));
}])])]));
            }
            return UndefinedValue::Value;
        });
    }

    public function deleteCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            $pageURL = $this->url();
            foreach (Js::iterate($cookies) as $cookie) {
                $item = Js::assign(Js::object([]), $cookie, Js::object(['partitionKey' => CookieHelpers::convertCookiesPartitionKeyFromPuppeteerToCdp(Js::get($cookie, 'partitionKey'))]));
                if (Js::truthy(Js::logicalAnd(!Js::truthy(Js::get($cookie, 'url')), fn () => Js::invoke($pageURL, 'startsWith', ['http'])))) {
                    Js::set($item, 'url', $pageURL);
                }
                Js::await(Js::invoke($this->session, 'send', ['Network.deleteCookies', $item]));
                if (Js::truthy(Js::logicalAnd(Js::invoke($pageURL, 'startsWith', ['http']), fn () => !Js::truthy(Js::get($item, 'partitionKey'))))) {
                    $url = new \Nesk\Puphpeteer\Native\Runtime\WhatwgUrl($pageURL);
                    Js::await(Js::invoke($this->session, 'send', ['Network.deleteCookies', Js::assign(Js::object([]), $item, Js::object(['partitionKey' => Js::object(['topLevelSite' => Js::invoke(Js::get($url, 'origin'), 'replace', [(':' . Js::string(Js::get($url, 'port')) . ''), '']), 'hasCrossSiteAncestor' => false])]))]));
                }
            }
            return UndefinedValue::Value;
        });
    }
}
