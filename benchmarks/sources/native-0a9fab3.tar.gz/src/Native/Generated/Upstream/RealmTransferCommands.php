<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/IsolatedWorld.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait RealmTransferCommands
{

    public function transferHandle(mixed $handle): mixed
    {
        return Js::async(function () use ($handle) {
            if (Js::truthy(Js::strictEqual(Js::get($handle, 'realm'), $this))) {
                return $handle;
            }
            if (Js::truthy(Js::strictEqual(Js::get(Js::invoke($handle, 'remoteObject', []), 'objectId'), UndefinedValue::Value))) {
                return $handle;
            }
            $info = Js::await(Js::invoke($this->session, 'send', ['DOM.describeNode', Js::object(['objectId' => Js::get(Js::invoke($handle, 'remoteObject', []), 'objectId')])]));
            $newHandle = ((Js::await($this->adoptBackendNode(Js::get(Js::get($info, 'node'), 'backendNodeId')))));
            Js::await(Js::invoke($handle, 'dispose', []));
            return $newHandle;
        });
    }
}
