<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/LifecycleWatcher.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait LifecycleCommands
{
    private mixed $navigationRequest = UndefinedValue::Value;
    private mixed $subscriptions = UndefinedValue::Value;
    private mixed $terminationDeferred = UndefinedValue::Value;
    private mixed $sameDocumentDeferred = UndefinedValue::Value;
    private mixed $lifecycleDeferred = UndefinedValue::Value;
    private mixed $newDocumentDeferred = UndefinedValue::Value;
    private mixed $lifecycleError = UndefinedValue::Value;
    private mixed $sameDocument = UndefinedValue::Value;
    private mixed $swapped = UndefinedValue::Value;
    private mixed $navigationResponseReceived = UndefinedValue::Value;
    private function initializeLifecycleState(): void
    {
        $this->navigationRequest = null;
        $this->subscriptions = new DisposableStackPolyfill();
        $this->sameDocumentDeferred = Deferred::create();
        $this->lifecycleDeferred = Deferred::create();
        $this->newDocumentDeferred = Deferred::create();
        $this->lifecycleError = new \Nesk\Puphpeteer\Native\Runtime\JsError('LifecycleWatcher terminated');
    }

    private function LifecycleWatcher_onRequest(mixed $request): mixed
    {
        if (Js::truthy(Js::logicalOr(!Js::strictEqual(Js::invoke($request, 'frame', []), $this->frame), fn () => !Js::truthy(Js::invoke($request, 'isNavigationRequest', []))))) {
            return UndefinedValue::Value;
        }
        $this->navigationRequest = $request;
        Js::optionalInvoke($this->navigationResponseReceived, 'resolve', fn () => []);
        $this->navigationResponseReceived = Deferred::create();
        if (Js::truthy(!Js::strictEqual(Js::invoke($request, 'response', []), null))) {
            Js::optionalInvoke($this->navigationResponseReceived, 'resolve', fn () => []);
        }
        return UndefinedValue::Value;
    }

    private function LifecycleWatcher_onRequestFailed(mixed $request): mixed
    {
        if (Js::truthy(!Js::strictEqual(Js::optionalGet($this->navigationRequest, 'id'), Js::get($request, 'id')))) {
            return UndefinedValue::Value;
        }
        Js::optionalInvoke($this->navigationResponseReceived, 'resolve', fn () => []);
        return UndefinedValue::Value;
    }

    private function LifecycleWatcher_onResponse(mixed $response): mixed
    {
        if (Js::truthy(!Js::strictEqual(Js::optionalGet($this->navigationRequest, 'id'), Js::get(Js::invoke($response, 'request', []), 'id')))) {
            return UndefinedValue::Value;
        }
        Js::optionalInvoke($this->navigationResponseReceived, 'resolve', fn () => []);
        return UndefinedValue::Value;
    }

    private function LifecycleWatcher_onFrameDetached(mixed $frame): mixed
    {
        if (Js::truthy(Js::strictEqual($this->frame, $frame))) {
            Js::set($this->lifecycleError, 'message', 'Navigating frame was detached');
            Js::invoke($this->terminationDeferred, 'resolve', [$this->lifecycleError]);
            return UndefinedValue::Value;
        }
        $this->check();
        return UndefinedValue::Value;
    }

    public function navigationResponse(): mixed
    {
        return Js::async(function () {
            Js::await(Js::optionalInvoke($this->navigationResponseReceived, 'valueOrThrow', fn () => []));
            return (Js::truthy($this->navigationRequest) ? Js::invoke($this->navigationRequest, 'response', []) : null);
        });
    }

    public function sameDocumentNavigationPromise(): mixed
    {
        return Js::invoke($this->sameDocumentDeferred, 'valueOrThrow', []);
    }

    public function newDocumentNavigationPromise(): mixed
    {
        return Js::invoke($this->newDocumentDeferred, 'valueOrThrow', []);
    }

    public function lifecyclePromise(): mixed
    {
        return Js::invoke($this->lifecycleDeferred, 'valueOrThrow', []);
    }

    public function terminationPromise(): mixed
    {
        return Js::invoke($this->terminationDeferred, 'valueOrThrow', []);
    }

    private function LifecycleWatcher_navigatedWithinDocument(): mixed
    {
        $this->sameDocument = true;
        $this->check();
        return UndefinedValue::Value;
    }

    private function LifecycleWatcher_navigated(mixed $navigationType): mixed
    {
        if (Js::truthy(Js::strictEqual($navigationType, 'BackForwardCacheRestore'))) {
            return $this->LifecycleWatcher_frameSwapped();
        }
        $this->check();
        return UndefinedValue::Value;
    }

    private function LifecycleWatcher_frameSwapped(): mixed
    {
        $this->swapped = true;
        $this->check();
        return UndefinedValue::Value;
    }

    private function check(): mixed
    {
        if (Js::truthy(!Js::truthy(Lifecycle::checkLifecycle($this->frame, $this->expected)))) {
            return UndefinedValue::Value;
        }
        Js::invoke($this->lifecycleDeferred, 'resolve', []);
        if (Js::truthy($this->sameDocument)) {
            Js::invoke($this->sameDocumentDeferred, 'resolve', [UndefinedValue::Value]);
        }
        if (Js::truthy(Js::logicalOr($this->swapped, fn () => !Js::strictEqual(Js::get($this->frame, '_loaderId'), $this->initialLoader)))) {
            Js::invoke($this->newDocumentDeferred, 'resolve', [UndefinedValue::Value]);
        }
        return UndefinedValue::Value;
    }

    public function dispose(): mixed
    {
        Js::invoke($this->subscriptions, 'dispose', []);
        Js::set($this->lifecycleError, 'cause', new \Nesk\Puphpeteer\Native\Runtime\JsError('LifecycleWatcher disposed'));
        Js::invoke($this->terminationDeferred, 'resolve', [$this->lifecycleError]);
        return UndefinedValue::Value;
    }
}
