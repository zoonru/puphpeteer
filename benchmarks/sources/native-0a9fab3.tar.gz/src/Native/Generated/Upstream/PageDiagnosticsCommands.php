<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageDiagnosticsCommands
{

    public function metrics(): mixed
    {
        return Js::async(function () {
            $response = Js::await(Js::invoke($this->session, 'send', ['Performance.getMetrics']));
            return $this->CdpPage_buildMetricsObject(Js::get($response, 'metrics'));
        });
    }

    private function CdpPage_emitMetrics(mixed $event): mixed
    {
        $this->emit(Js::get(Js::object(['Metrics'=>'metrics','Console'=>'console']), 'Metrics'), Js::object(['title' => Js::get($event, 'title'), 'metrics' => $this->CdpPage_buildMetricsObject(Js::get($event, 'metrics'))]));
        return UndefinedValue::Value;
    }

    private function CdpPage_buildMetricsObject(mixed $metrics = UndefinedValue::Value): mixed
    {
        $result = Js::object([]);
        foreach (Js::iterate(Js::logicalOr($metrics, fn () => new \Nesk\Puphpeteer\Native\Runtime\JsArray([]))) as $metric) {
            if (Js::truthy(Js::invoke(PageDiagnosticsHelpers::supportedMetrics(), 'has', [Js::get($metric, 'name')]))) {
                Js::set($result, Js::get($metric, 'name'), Js::get($metric, 'value'));
            }
        }
        return $result;
    }

    public function queryObjects(mixed $prototypeHandle): mixed
    {
        return Js::async(function () use ($prototypeHandle) {
            Js::assert(!Js::truthy(Js::get($prototypeHandle, 'disposed')), 'Prototype JSHandle is disposed!');
            Js::assert(Js::get($prototypeHandle, 'id'), 'Prototype JSHandle must not be referencing primitive value');
            $response = Js::await(Js::invoke(Js::get($this->mainFrame(), 'client'), 'send', ['Runtime.queryObjects', Js::object(['prototypeObjectId' => Js::get($prototypeHandle, 'id')])]));
            return (Js::invoke(Js::invoke($this->mainFrame(), 'mainRealm', []), 'createCdpHandle', [Js::get($response, 'objects')]));
        });
    }

    private function CdpPage_initialize(): mixed
    {
        return Js::async(function () {
            try {
                Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($this->frameManager, 'initialize', [$this->session]), Js::invoke($this->session, 'send', ['Performance.enable']), Js::invoke($this->session, 'send', ['Log.enable'])])));
            } catch (\Throwable $err) {
                if (Js::truthy(Js::logicalAnd(Js::isErrorLike($err), fn () => NetworkPredicates::isTargetClosedError($err)))) {
                    Js::debugError($err);
                } else {
                    throw $err;
                }
            }
            return UndefinedValue::Value;
        });
    }

    private function CdpPage_onLogEntryAdded(mixed $event): mixed
    {
        $_nativeBinding1 = Js::get($event, 'entry');
        $level = Js::get($_nativeBinding1, 'level');
        $text = Js::get($_nativeBinding1, 'text');
        $args = Js::get($_nativeBinding1, 'args');
        $source = Js::get($_nativeBinding1, 'source');
        $url = Js::get($_nativeBinding1, 'url');
        $lineNumber = Js::get($_nativeBinding1, 'lineNumber');
        $stackTrace = Js::get($_nativeBinding1, 'stackTrace');
        if (Js::truthy($args)) {
            Js::invoke($args, 'map', [function (mixed $arg) {
    Js::discard(PageDiagnosticsHelpers::releaseObject($this->session, $arg));
    return UndefinedValue::Value;
}]);
        }
        if (Js::truthy(!Js::strictEqual($source, 'worker'))) {
            $this->emit(Js::get(Js::object(['Metrics'=>'metrics','Console'=>'console']), 'Console'), new \Nesk\Puphpeteer\Native\ConsoleMessage(PageDiagnosticsHelpers::convertConsoleMessageLevel($level), $text, new \Nesk\Puphpeteer\Native\Runtime\JsArray([]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::object(['url' => $url, 'lineNumber' => $lineNumber])]), UndefinedValue::Value, $stackTrace, Js::get($this->primaryTargetMetadata, '_targetId')));
        }
        return UndefinedValue::Value;
    }
}
