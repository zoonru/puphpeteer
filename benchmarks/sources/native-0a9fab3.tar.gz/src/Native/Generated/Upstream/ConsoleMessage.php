<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/ConsoleMessage.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class ConsoleMessage
{
    protected mixed $ConsoleMessage_type = UndefinedValue::Value;
    protected mixed $ConsoleMessage_text = UndefinedValue::Value;
    protected mixed $ConsoleMessage_args = UndefinedValue::Value;
    protected mixed $ConsoleMessage_stackTraceLocations = UndefinedValue::Value;
    protected mixed $ConsoleMessage_frame = UndefinedValue::Value;
    protected mixed $ConsoleMessage_rawStackTrace = UndefinedValue::Value;
    protected mixed $ConsoleMessage_targetId = UndefinedValue::Value;

    public function __construct(mixed $type, mixed $text, mixed $args, mixed $stackTraceLocations, mixed $frame = UndefinedValue::Value, mixed $rawStackTrace = UndefinedValue::Value, mixed $targetId = UndefinedValue::Value)
    {
        $this->ConsoleMessage_type = $type;
        $this->ConsoleMessage_text = $text;
        $this->ConsoleMessage_args = $args;
        $this->ConsoleMessage_stackTraceLocations = $stackTraceLocations;
        $this->ConsoleMessage_frame = $frame;
        $this->ConsoleMessage_rawStackTrace = $rawStackTrace;
        $this->ConsoleMessage_targetId = $targetId;
    }

    public function type(): mixed
    {
        return $this->ConsoleMessage_type;
    }

    public function text(): mixed
    {
        return $this->ConsoleMessage_text;
    }

    public function args(): mixed
    {
        return $this->ConsoleMessage_args;
    }

    public function location(): mixed
    {
        return (Js::coalesce(Js::get($this->ConsoleMessage_stackTraceLocations, 0), fn () => ((Js::truthy($this->ConsoleMessage_frame) ? Js::object(['url' => Js::invoke($this->ConsoleMessage_frame, 'url', [])]) : Js::object([])))));
    }

    public function stackTrace(): mixed
    {
        return $this->ConsoleMessage_stackTraceLocations;
    }

    public function _rawStackTrace(): mixed
    {
        return $this->ConsoleMessage_rawStackTrace;
    }

    public function _targetId(): mixed
    {
        return $this->ConsoleMessage_targetId;
    }
}
