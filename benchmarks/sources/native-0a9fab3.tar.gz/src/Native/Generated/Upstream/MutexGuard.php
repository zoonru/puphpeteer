<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/Mutex.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
class MutexGuard implements \Nesk\Puphpeteer\Native\Runtime\JsSymbolObject
{
    private mixed $MutexGuard_mutex;
    private mixed $MutexGuard_onRelease;
    public function __construct(mixed $mutex, mixed $onRelease = UndefinedValue::Value)
    {
        $this->MutexGuard_mutex = UndefinedValue::Value;
        $this->MutexGuard_onRelease = UndefinedValue::Value;
        $this->MutexGuard_mutex = $mutex;
        $this->MutexGuard_onRelease = $onRelease;
    }
    public function disposeGuard(): mixed
    {
        Js::optionalCall($this->MutexGuard_onRelease, fn () => []);
        return Js::invoke($this->MutexGuard_mutex, 'release', []);
    }
    public function getJsSymbol(\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol $symbol): mixed { return $symbol === \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose ? $this->disposeGuard(...) : UndefinedValue::Value; }
}
