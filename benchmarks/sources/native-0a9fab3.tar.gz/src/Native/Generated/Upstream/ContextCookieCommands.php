<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/BrowserContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait ContextCookieCommands
{

    public function deleteCookie(mixed ...$cookies): mixed
    {
        return Js::async(function () use ($cookies) {
            $cookies = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($cookies));
            return Js::await($this->setCookie(...Js::iterate(Js::invoke($cookies, 'map', [function (mixed $cookie) {
    return Js::assign(Js::object([]), $cookie, Js::object(['expires' => 1]));
}]))));
        });
    }

    public function deleteMatchingCookies(mixed ...$filters): mixed
    {
        return Js::async(function () use ($filters) {
            $filters = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($filters));
            $cookies = Js::await($this->cookies());
            $cookiesToDelete = Js::invoke($cookies, 'filter', [function (mixed $cookie) use ($filters) {
    return Js::invoke($filters, 'some', [function (mixed $filter) use ($cookie) {
    if (Js::truthy(Js::strictEqual(Js::get($filter, 'name'), Js::get($cookie, 'name')))) {
        if (Js::truthy(Js::logicalAnd(!Js::strictEqual(Js::get($filter, 'domain'), UndefinedValue::Value), fn () => Js::strictEqual(Js::get($filter, 'domain'), Js::get($cookie, 'domain'))))) {
            return true;
        }
        if (Js::truthy(Js::logicalAnd(!Js::strictEqual(Js::get($filter, 'path'), UndefinedValue::Value), fn () => Js::strictEqual(Js::get($filter, 'path'), Js::get($cookie, 'path'))))) {
            return true;
        }
        if (Js::truthy(Js::logicalAnd(!Js::strictEqual(Js::get($filter, 'partitionKey'), UndefinedValue::Value), fn () => !Js::strictEqual(Js::get($cookie, 'partitionKey'), UndefinedValue::Value)))) {
            if (Js::truthy(!Js::strictEqual(Js::typeOf(Js::get($cookie, 'partitionKey')), 'object'))) {
                throw new \RuntimeException('Unexpected string partition key');
            }
            if (Js::truthy(Js::strictEqual(Js::typeOf(Js::get($filter, 'partitionKey')), 'string'))) {
                if (Js::truthy(Js::strictEqual(Js::get($filter, 'partitionKey'), Js::optionalGet(Js::get($cookie, 'partitionKey'), 'sourceOrigin')))) {
                    return true;
                }
            } else {
                if (Js::truthy(Js::strictEqual(Js::get(Js::get($filter, 'partitionKey'), 'sourceOrigin'), Js::optionalGet(Js::get($cookie, 'partitionKey'), 'sourceOrigin')))) {
                    return true;
                }
            }
        }
        if (Js::truthy(!Js::strictEqual(Js::get($filter, 'url'), UndefinedValue::Value))) {
            $url = new \Nesk\Puphpeteer\Native\Runtime\WhatwgUrl(Js::get($filter, 'url'));
            if (Js::truthy(Js::logicalAnd(Js::strictEqual(Js::get($url, 'hostname'), Js::get($cookie, 'domain')), fn () => Js::strictEqual(Js::get($url, 'pathname'), Js::get($cookie, 'path'))))) {
                return true;
            }
        }
        return true;
    }
    return false;
}]);
}]);
            Js::await($this->deleteCookie(...Js::iterate($cookiesToDelete)));
            return UndefinedValue::Value;
        });
    }
}
