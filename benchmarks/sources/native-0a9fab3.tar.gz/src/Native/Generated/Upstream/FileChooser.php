<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/FileChooser.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class FileChooser implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $FileChooser_element;
    private mixed $FileChooser_multiple;
    private mixed $FileChooser_handled;

    public function __construct(mixed $element, mixed $multiple)
    {
        $this->FileChooser_element = UndefinedValue::Value;
        $this->FileChooser_multiple = UndefinedValue::Value;
        $this->FileChooser_handled = false;
        $this->FileChooser_element = $element;
        $this->FileChooser_multiple = $multiple;
    }

    public function isMultiple(): mixed
    {
        return $this->FileChooser_multiple;
    }

    public function accept(mixed $paths): mixed
    {
        return Js::async(function () use ($paths) {
            Js::assert(!Js::truthy($this->FileChooser_handled), 'Cannot accept FileChooser which is already handled!');
            $this->FileChooser_handled = true;
            Js::await(Js::invoke($this->FileChooser_element, 'uploadFile', [...Js::iterate($paths)]));
            return UndefinedValue::Value;
        });
    }

    public function cancel(): mixed
    {
        return Js::async(function () {
            Js::assert(!Js::truthy($this->FileChooser_handled), 'Cannot cancel FileChooser which is already handled!');
            $this->FileChooser_handled = true;
            Js::await(Js::invoke($this->FileChooser_element, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('element => {
    element.dispatchEvent(new Event(\'cancel\', { bubbles: true }));
}')]));
            return UndefinedValue::Value;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
