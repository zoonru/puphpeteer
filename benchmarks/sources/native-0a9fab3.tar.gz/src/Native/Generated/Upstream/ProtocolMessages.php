<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/CallbackRegistry.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class ProtocolMessages
{
    // createProtocolErrorMessage from util/ErrorLike.ts.
    public static function createProtocolErrorMessage(mixed $object): mixed
    {
        $message = Js::get(Js::get($object, 'error'), 'message');
        if (Js::truthy(Js::logicalAnd(Js::logicalAnd(Js::get($object, 'error'), fn () => Js::strictEqual(Js::typeOf(Js::get($object, 'error')), 'object')), fn () => Js::hasProperty(Js::get($object, 'error'), 'data')))) {
            $message = Js::add($message, (' ' . Js::string(Js::get(Js::get($object, 'error'), 'data')) . ''));
        }
        return $message;
    }

    public static function format(mixed $label, mixed $error): mixed
    {
        $callback = Js::object(['label'=>$label]);
        $message = self::createProtocolErrorMessage(Js::object(['error'=>$error]));
        return ('Protocol error (' . Js::string(Js::get($callback, 'label')) . '): ' . Js::string($message) . '');
    }
}
