<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Binding.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

final class BindingFunctions
{
    public const prefix = 'puppeteer_';
    public const init = 'function addPageBinding(type, name, prefix) {
    // Depending on the frame loading state either Runtime.evaluate or
    // Page.addScriptToEvaluateOnNewDocument might succeed. Let\'s check that we
    // don\'t re-wrap Puppeteer\'s binding.
    // @ts-expect-error: In a different context.
    if (globalThis[name]) {
        return;
    }
    // We replace the CDP binding with a Puppeteer binding.
    Object.assign(globalThis, {
        [name](...args) {
            // This is the Puppeteer binding.
            // @ts-expect-error: In a different context.
            const callPuppeteer = globalThis[name];
            callPuppeteer.args ??= new Map();
            callPuppeteer.callbacks ??= new Map();
            const seq = (callPuppeteer.lastSeq ?? 0) + 1;
            callPuppeteer.lastSeq = seq;
            callPuppeteer.args.set(seq, args);
            // @ts-expect-error: In a different context.
            // Needs to be the same as CDP_BINDING_PREFIX.
            globalThis[prefix + name](JSON.stringify({
                type,
                name,
                seq,
                args,
                isTrivial: !args.some(value => {
                    return value instanceof Node;
                }),
            }));
            return new Promise((resolve, reject) => {
                callPuppeteer.callbacks.set(seq, {
                    resolve(value) {
                        callPuppeteer.args.delete(seq);
                        resolve(value);
                    },
                    reject(value) {
                        callPuppeteer.args.delete(seq);
                        reject(value);
                    },
                });
            });
        },
    });
}';
    public const ignoredAxRoles = ['StaticText', 'InlineTextBox'];
    public const readArguments = '(name, seq) => {
    // @ts-expect-error Code is evaluated in a different context.
    return globalThis[name].args.get(seq);
}';
    public const resolve = '(name, seq, result) => {
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).resolve(result);
    callbacks.delete(seq);
}';
    public const rejectError = '(name, seq, message, stack) => {
    const error = new Error(message);
    error.stack = stack;
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).reject(error);
    callbacks.delete(seq);
}';
    public const rejectValue = '(name, seq, error) => {
    // @ts-expect-error Code is evaluated in a different context.
    const callbacks = globalThis[name].callbacks;
    callbacks.get(seq).reject(error);
    callbacks.delete(seq);
}';
}
