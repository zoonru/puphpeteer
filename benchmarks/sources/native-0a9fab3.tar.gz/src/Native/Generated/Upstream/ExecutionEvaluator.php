<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class ExecutionEvaluator implements \Nesk\Puphpeteer\Native\Runtime\JsObject
{
    public function __construct(private object $world, private int $id) {}
    public function getJsProperty(string $name): mixed { return $name === 'puppeteerUtil' ? $this->world->utility() : UndefinedValue::Value; }
    public function run(mixed $_nativeEvaluationClient, mixed $returnByValue, mixed $pageFunction, mixed ...$args): mixed
    {
        return Js::async(function () use ($_nativeEvaluationClient, $returnByValue, $pageFunction, $args) {
            $args = new \Nesk\Puphpeteer\Native\Runtime\JsArray(array_values($args));
            $convertArgumentAsync = function (mixed $context, mixed $arg) use (&$convertArgument) {
    return Js::async(function () use (&$convertArgument, $context, $arg) {
    if (Js::truthy(($arg instanceof LazyArg))) {
        $arg = Js::await(Js::invoke($arg, 'get', [$context]));
    }
    return Js::functionValue($convertArgument)($context, $arg);
    });
};
            $convertArgument = function (mixed $context, mixed $arg) {
    if (Js::truthy(Js::strictEqual(Js::typeOf($arg), 'bigint'))) {
        return Js::object(['unserializableValue' => ('' . Js::string(Js::invoke($arg, 'toString', [])) . 'n')]);
    }
    if (Js::truthy(Js::objectIs($arg, (-0.0)))) {
        return Js::object(['unserializableValue' => '-0']);
    }
    if (Js::truthy(Js::objectIs($arg, INF))) {
        return Js::object(['unserializableValue' => 'Infinity']);
    }
    if (Js::truthy(Js::objectIs($arg, (-INF)))) {
        return Js::object(['unserializableValue' => '-Infinity']);
    }
    if (Js::truthy(Js::objectIs($arg, NAN))) {
        return Js::object(['unserializableValue' => 'NaN']);
    }
    $objectHandle = (Js::truthy(Js::logicalAnd($arg, fn () => (Js::logicalOr(($arg instanceof \Nesk\Puphpeteer\Native\JSHandle), fn () => ($arg instanceof \Nesk\Puphpeteer\Native\ElementHandle))))) ? $arg : null);
    if (Js::truthy($objectHandle)) {
        if (Js::truthy(!Js::strictEqual(Js::get($objectHandle, 'realm'), ($context)->world))) {
            Js::throwValue(new \Nesk\Puphpeteer\Native\Runtime\JsError('JSHandles can be evaluated only in the context they were created!'));
        }
        if (Js::truthy(Js::get($objectHandle, 'disposed'))) {
            Js::throwValue(new \Nesk\Puphpeteer\Native\Runtime\JsError('JSHandle is disposed!'));
        }
        if (Js::truthy(Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'unserializableValue'))) {
            return Js::object(['unserializableValue' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'unserializableValue')]);
        }
        if (Js::truthy(!Js::truthy(Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'objectId')))) {
            return Js::object(['value' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'value')]);
        }
        return Js::object(['objectId' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'objectId')]);
    }
    return Js::object(['value' => $arg]);
};
            $sourceUrlComment = EvaluationSource::getSourceUrlComment(Js::coalesce(Js::optionalInvoke(\Nesk\Puphpeteer\Native\JsFunction::sourceUrlFor($pageFunction), 'toString', fn () => []), fn () => Js::get(Js::object(['INTERNAL_URL'=>PuppeteerURL::$INTERNAL_URL]), 'INTERNAL_URL')));
            if (Js::truthy(Js::isString($pageFunction))) {
                $contextId = $this->id;
                $expression = $pageFunction;
                $expressionWithSourceUrl = (Js::truthy(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\SourceUrlPattern(), 'test', [$expression])) ? $expression : ('' . Js::string($expression) . '
' . Js::string($sourceUrlComment) . '
'));
                $_nativeBinding1 = Js::await(Js::invoke(Js::invoke($_nativeEvaluationClient, 'send', ['Runtime.evaluate', Js::object(['expression' => $expressionWithSourceUrl, 'contextId' => $contextId, 'returnByValue' => $returnByValue, 'awaitPromise' => true, 'userGesture' => true])]), 'catch', [ExecutionHelpers::rewriteError(...)]));
                $exceptionDetails = Js::get($_nativeBinding1, 'exceptionDetails');
                $remoteObject = Js::get($_nativeBinding1, 'result');
                if (Js::truthy($exceptionDetails)) {
                    Js::throwValue(EvaluationErrors::createEvaluationError($exceptionDetails));
                }
                if (Js::truthy($returnByValue)) {
                    return (RemoteValues::valueFromRemoteObject($remoteObject));
                }
                return (Js::invoke($this->world, 'createCdpHandle', [$remoteObject]));
            }
            $functionDeclaration = FunctionHelpers::stringifyFunction($pageFunction);
            $functionDeclarationWithSourceUrl = (Js::truthy(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\SourceUrlPattern(), 'test', [$functionDeclaration])) ? $functionDeclaration : ('' . Js::string($functionDeclaration) . '
' . Js::string($sourceUrlComment) . '
'));
            $callFunctionOnPromise = UndefinedValue::Value;
            try {
                $callFunctionOnPromise = Js::invoke($_nativeEvaluationClient, 'send', ['Runtime.callFunctionOn', Js::object(['functionDeclaration' => $functionDeclarationWithSourceUrl, 'executionContextId' => $this->id, 'arguments' => (Js::truthy(Js::invoke($args, 'some', [function (mixed $arg) {
    return ($arg instanceof LazyArg);
}])) ? Js::await(Js::all(Js::invoke($args, 'map', [function (mixed $arg) use ($convertArgumentAsync) {
    return Js::functionValue($convertArgumentAsync)($this, $arg);
}]))) : Js::invoke($args, 'map', [function (mixed $arg) use ($convertArgument) {
    return Js::functionValue($convertArgument)($this, $arg);
}])), 'returnByValue' => $returnByValue, 'awaitPromise' => true, 'userGesture' => true])]);
            } catch (\Throwable $error) {
                if (Js::truthy(Js::logicalAnd(($error instanceof \Nesk\Puphpeteer\Native\Runtime\TypeError), fn () => Js::invoke(Js::get($error, 'message'), 'startsWith', ['Converting circular structure to JSON'])))) {
                    Js::set($error, 'message', Js::add(Js::get($error, 'message'), ' Recursive objects are not allowed.'));
                }
                Js::throwValue($error);
            }
            $_nativeBinding2 = Js::await(Js::invoke($callFunctionOnPromise, 'catch', [ExecutionHelpers::rewriteError(...)]));
            $exceptionDetails = Js::get($_nativeBinding2, 'exceptionDetails');
            $remoteObject = Js::get($_nativeBinding2, 'result');
            if (Js::truthy($exceptionDetails)) {
                Js::throwValue(EvaluationErrors::createEvaluationError($exceptionDetails));
            }
            if (Js::truthy($returnByValue)) {
                return ((RemoteValues::valueFromRemoteObject($remoteObject)));
            }
            return (Js::invoke($this->world, 'createCdpHandle', [$remoteObject]));
        });
    }
}
