<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait PageFileChooserCommands
{
    private mixed $fileChooserDeferreds;
    private function initializeFileChooser(): void
    {
        $this->fileChooserDeferreds = new \Nesk\Puphpeteer\Native\Runtime\JsSet();
    }

    public function waitForFileChooser(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $needsEnable = Js::strictEqual(Js::get($this->fileChooserDeferreds, 'size'), 0);
            $_nativeBinding1 = $options;
            $timeout = Js::defaultValue(Js::get($_nativeBinding1, 'timeout'), fn () => Js::invoke($this->timeouts, 'timeout', []));
            $deferred = Deferred::create(Js::object(['message' => ('Waiting for `FileChooser` failed: ' . Js::string($timeout) . 'ms exceeded'), 'timeout' => $timeout]));
            if (Js::truthy(Js::get($options, 'signal'))) {
                Js::invoke(Js::get($options, 'signal'), 'addEventListener', ['abort', function () use ($options, $deferred) {
    Js::invoke($deferred, 'reject', [Js::optionalGet(Js::get($options, 'signal'), 'reason')]);
    return UndefinedValue::Value;
}, Js::object(['once' => true])]);
            }
            Js::invoke($this->fileChooserDeferreds, 'add', [$deferred]);
            $enablePromise = UndefinedValue::Value;
            if (Js::truthy($needsEnable)) {
                $enablePromise = Js::invoke($this->session, 'send', ['Page.setInterceptFileChooserDialog', Js::object(['enabled' => true])]);
            }
            try {
                $_nativeBinding2 = Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($deferred, 'valueOrThrow', []), $enablePromise])));
                $result = Js::get($_nativeBinding2, 0);
                return $result;
            } catch (\Throwable $error) {
                Js::invoke($this->fileChooserDeferreds, 'delete', [$deferred]);
                throw $error;
            }
        });
    }

    private function CdpPage_onFileChooser(mixed $event): mixed
    {
        return Js::async(function () use ($event) {
            if (Js::truthy(!Js::truthy(Js::get($this->fileChooserDeferreds, 'size')))) {
                return UndefinedValue::Value;
            }
            $frame = Js::invoke($this->frameManager, 'frame', [Js::get($event, 'frameId')]);
            Js::assert($frame, 'This should never happen.');
            $handle = ((Js::await(Js::invoke(Js::get(Js::get($frame, 'worlds'), 'main'), 'adoptBackendNode', [Js::get($event, 'backendNodeId')]))));
            try {
                $fileChooser = new FileChooser(Js::invoke($handle, 'move', []), !Js::strictEqual(Js::get($event, 'mode'), 'selectSingle'));
                foreach (Js::iterate($this->fileChooserDeferreds) as $promise) {
                    Js::invoke($promise, 'resolve', [$fileChooser]);
                }
                Js::invoke($this->fileChooserDeferreds, 'clear', []);
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }
}
