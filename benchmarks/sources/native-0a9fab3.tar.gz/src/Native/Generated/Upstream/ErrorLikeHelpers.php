<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/ErrorLike.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class ErrorLikeHelpers
{
    public static function isErrorLike(mixed $obj): mixed
    {
        return (Js::logicalAnd(Js::logicalAnd(Js::logicalAnd(Js::strictEqual(Js::typeOf($obj), 'object'), fn () => !Js::strictEqual($obj, null)), fn () => Js::hasProperty($obj, 'name')), fn () => Js::hasProperty($obj, 'message')));
    }
}
