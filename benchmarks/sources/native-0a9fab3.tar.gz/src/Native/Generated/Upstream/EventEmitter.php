<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/EventEmitter.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class EventEmitter implements \Nesk\Puphpeteer\Native\Runtime\JsSymbolObject
{
    private mixed $EventEmitter_emitter = UndefinedValue::Value;
    private mixed $EventEmitter_handlers = UndefinedValue::Value;

    public function __construct(mixed $emitter = UndefinedValue::Value)
    {
        $this->EventEmitter_handlers = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        if ($emitter === UndefinedValue::Value) { $emitter = Mitt::mitt_default(new \Nesk\Puphpeteer\Native\Runtime\JsMap()); }
        $this->EventEmitter_emitter = $emitter;
    }

    public function on(mixed $type, mixed $handler): mixed
    {
        $handlers = Js::invoke($this->EventEmitter_handlers, 'get', [$type]);
        if (Js::truthy(Js::strictEqual($handlers, UndefinedValue::Value))) {
            Js::invoke($this->EventEmitter_handlers, 'set', [$type, new \Nesk\Puphpeteer\Native\Runtime\JsArray([$handler])]);
        } else {
            Js::invoke($handlers, 'push', [$handler]);
        }
        Js::invoke($this->EventEmitter_emitter, 'on', [$type, $handler]);
        return $this;
    }

    public function off(mixed $type, mixed $handler = UndefinedValue::Value): mixed
    {
        $handlers = Js::coalesce(Js::invoke($this->EventEmitter_handlers, 'get', [$type]), fn () => new \Nesk\Puphpeteer\Native\Runtime\JsArray([]));
        if (Js::truthy(Js::strictEqual($handler, UndefinedValue::Value))) {
            foreach (Js::iterate($handlers) as $handler) {
                Js::invoke($this->EventEmitter_emitter, 'off', [$type, $handler]);
            }
            Js::invoke($this->EventEmitter_handlers, 'delete', [$type]);
            return $this;
        }
        $index = Js::invoke($handlers, 'lastIndexOf', [$handler]);
        if (Js::truthy(Js::numeric('>', $index, (-1)))) {
            Js::invoke($this->EventEmitter_emitter, 'off', [$type, ...Js::iterate(Js::invoke($handlers, 'splice', [$index, 1]))]);
        }
        return $this;
    }

    public function emit(mixed $type, mixed $event): mixed
    {
        Js::invoke($this->EventEmitter_emitter, 'emit', [$type, $event]);
        return Js::numeric('>', $this->listenerCount($type), 0);
    }

    public function once(mixed $type, mixed $handler): mixed
    {
        $onceHandler = UndefinedValue::Value;
        $onceHandler = function (mixed $eventData) use ($type, $handler, &$onceHandler) {
    Js::call($handler, [$eventData]);
    $this->off($type, $onceHandler);
    return UndefinedValue::Value;
};
        return $this->on($type, $onceHandler);
    }

    public function listenerCount(mixed $type): mixed
    {
        return Js::logicalOr(Js::optionalGet(Js::invoke($this->EventEmitter_handlers, 'get', [$type]), 'length'), fn () => 0);
    }

    public function removeAllListeners(mixed $type = UndefinedValue::Value): mixed
    {
        if (Js::truthy(!Js::strictEqual($type, UndefinedValue::Value))) {
            return $this->off($type);
        }
        $this->disposeEmitter();
        return $this;
    }

    public function disposeEmitter(): mixed
    {
        foreach (Js::iterate($this->EventEmitter_handlers) as $_nativeItem1) {
            $type = Js::get($_nativeItem1, 0);
            $handlers = Js::get($_nativeItem1, 1);
            foreach (Js::iterate($handlers) as $handler) {
                Js::invoke($this->EventEmitter_emitter, 'off', [$type, $handler]);
            }
        }
        Js::invoke($this->EventEmitter_handlers, 'clear', []);
        return UndefinedValue::Value;
    }

    public function getJsSymbol(\Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol $symbol): mixed
    {
        return $symbol === \Nesk\Puphpeteer\Native\Runtime\WellKnownSymbol::Dispose ? $this->disposeEmitter(...) : UndefinedValue::Value;
    }
}
