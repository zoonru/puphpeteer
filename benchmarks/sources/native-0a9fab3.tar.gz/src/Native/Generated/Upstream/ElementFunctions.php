<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/ElementHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

final class ElementFunctions
{
    public const focus = 'element => {
    if (!(element instanceof HTMLElement)) {
        throw new Error(\'Cannot focus non-HTMLElement\');
    }
    return element.focus();
}';
    public const select = '(element, vals) => {
    const values = new Set(vals);
    if (!(element instanceof HTMLSelectElement)) {
        throw new Error(\'Element is not a <select> element.\');
    }
    const selectedValues = new Set();
    if (!element.multiple) {
        for (const option of element.options) {
            option.selected = false;
        }
        for (const option of element.options) {
            if (values.has(option.value)) {
                option.selected = true;
                selectedValues.add(option.value);
                break;
            }
        }
    }
    else {
        for (const option of element.options) {
            option.selected = values.has(option.value);
            if (option.selected) {
                selectedValues.add(option.value);
            }
        }
    }
    element.dispatchEvent(new Event(\'input\', { bubbles: true }));
    element.dispatchEvent(new Event(\'change\', { bubbles: true }));
    return [...selectedValues.values()];
}';
    public const assertConnectedElement = 'async (element) => {
    if (!element.isConnected) {
        return \'Node is detached from document\';
    }
    if (element.nodeType !== Node.ELEMENT_NODE) {
        return \'Node is not of type HTMLElement\';
    }
    return;
}';
    public const scrollIntoView = 'async (element) => {
    element.scrollIntoView({
        block: \'center\',
        inline: \'center\',
        behavior: \'instant\',
    });
}';
}
