<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/LifecycleWatcher.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class Lifecycle
{
    public const EVENTS = ['load' => 'load', 'domcontentloaded' => 'DOMContentLoaded', 'networkidle0' => 'networkIdle', 'networkidle2' => 'networkAlmostIdle'];
    public static function checkLifecycle(mixed $frame, mixed $expectedLifecycle): mixed
    {
        foreach (Js::iterate($expectedLifecycle) as $event) {
            if (Js::truthy(!Js::truthy(Js::invoke(Js::get($frame, '_lifecycleEvents'), 'has', [$event])))) {
                return false;
            }
        }
        foreach (Js::iterate(Js::invoke($frame, 'childFrames', [])) as $child) {
            if (Js::truthy(Js::logicalAnd(Js::get($child, '_hasStartedLoading'), fn () => !Js::truthy(self::checkLifecycle($child, $expectedLifecycle))))) {
                return false;
            }
        }
        return true;
    }
}
