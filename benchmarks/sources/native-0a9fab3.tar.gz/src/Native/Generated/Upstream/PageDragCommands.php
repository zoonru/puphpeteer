<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageDragCommands
{

    public function setDragInterception(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            $this->dragInterceptionEnabled = $enabled;
            return Js::await(Js::invoke($this->session, 'send', ['Input.setInterceptDrags', Js::object(['enabled' => $enabled])]));
        });
    }

    public function isDragInterceptionEnabled(): mixed
    {
        return $this->dragInterceptionEnabled;
    }
}
