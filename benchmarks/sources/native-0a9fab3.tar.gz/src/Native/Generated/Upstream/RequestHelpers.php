<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/HTTPRequest.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class RequestHelpers
{

    public static function headersArray(mixed $headers): mixed
    {
        $result = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        foreach (Js::keys($headers) as $name) {
            $value = Js::get($headers, $name);
            if (Js::truthy(!Js::truthy(Js::objectIs($value, UndefinedValue::Value)))) {
                $values = (Js::truthy(Js::isArray($value)) ? $value : new \Nesk\Puphpeteer\Native\Runtime\JsArray([$value]));
                Js::invoke($result, 'push', [...Js::iterate(Js::invoke($values, 'map', [function (mixed $value) use ($name) {
    return Js::object(['name' => $name, 'value' => Js::add($value, '')]);
}]))]);
            }
        }
        return $result;
    }

    public static function handleError(mixed $error): mixed
    {
        if (Js::truthy(Js::logicalOr(Js::logicalOr(Js::logicalOr(Js::invoke(Js::get($error, 'originalMessage'), 'includes', ['Invalid header']), fn () => Js::invoke(Js::get($error, 'originalMessage'), 'includes', ['Unsafe header'])), fn () => Js::invoke(Js::get($error, 'originalMessage'), 'includes', ['Expected "header"'])), fn () => Js::invoke(Js::get($error, 'originalMessage'), 'includes', ['invalid argument'])))) {
            throw $error;
        }
        Js::debugError($error);
        return UndefinedValue::Value;
    }
}
