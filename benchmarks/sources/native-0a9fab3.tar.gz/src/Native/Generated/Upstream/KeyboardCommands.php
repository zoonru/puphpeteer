<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Input.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait KeyboardCommands
{

    public function updateClient(mixed $client): mixed
    {
        $this->client = $client;
        return UndefinedValue::Value;
    }

    public function down(mixed $key, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($key, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object(['text' => UndefinedValue::Value, 'commands' => []]); }
            $description = $this->CdpKeyboard_keyDescriptionForString($key);
            $autoRepeat = Js::invoke($this->pressedKeys, 'has', [Js::get($description, 'code')]);
            Js::invoke($this->pressedKeys, 'add', [Js::get($description, 'code')]);
            $this->_modifiers = Js::bitwise('|', $this->_modifiers, $this->CdpKeyboard_modifierBit(Js::get($description, 'key')));
            $text = (Js::truthy(Js::strictEqual(Js::get($options, 'text'), UndefinedValue::Value)) ? Js::get($description, 'text') : Js::get($options, 'text'));
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchKeyEvent', Js::object(['type' => (Js::truthy($text) ? 'keyDown' : 'rawKeyDown'), 'modifiers' => $this->_modifiers, 'windowsVirtualKeyCode' => Js::get($description, 'keyCode'), 'code' => Js::get($description, 'code'), 'key' => Js::get($description, 'key'), 'text' => $text, 'unmodifiedText' => $text, 'autoRepeat' => $autoRepeat, 'location' => Js::get($description, 'location'), 'isKeypad' => Js::strictEqual(Js::get($description, 'location'), 3), 'commands' => Js::get($options, 'commands')])]));
            return UndefinedValue::Value;
        });
    }

    private function CdpKeyboard_modifierBit(mixed $key): mixed
    {
        if (Js::truthy(Js::strictEqual($key, 'Alt'))) {
            return 1;
        }
        if (Js::truthy(Js::strictEqual($key, 'Control'))) {
            return 2;
        }
        if (Js::truthy(Js::strictEqual($key, 'Meta'))) {
            return 4;
        }
        if (Js::truthy(Js::strictEqual($key, 'Shift'))) {
            return 8;
        }
        return 0;
    }

    private function CdpKeyboard_keyDescriptionForString(mixed $keyString): mixed
    {
        $shift = Js::bitwise('&', $this->_modifiers, 8);
        $description = Js::object(['key' => '', 'keyCode' => 0, 'code' => '', 'text' => '', 'location' => 0]);
        $definition = Js::get(\Nesk\Puphpeteer\Native\Generated\Upstream\KeyboardLayout::DEFINITIONS, $keyString);
        Js::assert($definition, ('Unknown key: "' . Js::string($keyString) . '"'));
        if (Js::truthy(Js::get($definition, 'key'))) {
            Js::set($description, 'key', Js::get($definition, 'key'));
        }
        if (Js::truthy(Js::logicalAnd($shift, fn () => Js::get($definition, 'shiftKey')))) {
            Js::set($description, 'key', Js::get($definition, 'shiftKey'));
        }
        if (Js::truthy(Js::get($definition, 'keyCode'))) {
            Js::set($description, 'keyCode', Js::get($definition, 'keyCode'));
        }
        if (Js::truthy(Js::logicalAnd($shift, fn () => Js::get($definition, 'shiftKeyCode')))) {
            Js::set($description, 'keyCode', Js::get($definition, 'shiftKeyCode'));
        }
        if (Js::truthy(Js::get($definition, 'code'))) {
            Js::set($description, 'code', Js::get($definition, 'code'));
        }
        if (Js::truthy(Js::get($definition, 'location'))) {
            Js::set($description, 'location', Js::get($definition, 'location'));
        }
        if (Js::truthy(Js::strictEqual(Js::get(Js::get($description, 'key'), 'length'), 1))) {
            Js::set($description, 'text', Js::get($description, 'key'));
        }
        if (Js::truthy(Js::get($definition, 'text'))) {
            Js::set($description, 'text', Js::get($definition, 'text'));
        }
        if (Js::truthy(Js::logicalAnd($shift, fn () => Js::get($definition, 'shiftText')))) {
            Js::set($description, 'text', Js::get($definition, 'shiftText'));
        }
        if (Js::truthy(Js::bitwise('&', $this->_modifiers, Js::bitNot(8)))) {
            Js::set($description, 'text', '');
        }
        return $description;
    }

    public function up(mixed $key): mixed
    {
        return Js::async(function () use ($key) {
            $description = $this->CdpKeyboard_keyDescriptionForString($key);
            $this->_modifiers = Js::bitwise('&', $this->_modifiers, Js::bitNot($this->CdpKeyboard_modifierBit(Js::get($description, 'key'))));
            Js::invoke($this->pressedKeys, 'delete', [Js::get($description, 'code')]);
            Js::await(Js::invoke($this->client, 'send', ['Input.dispatchKeyEvent', Js::object(['type' => 'keyUp', 'modifiers' => $this->_modifiers, 'key' => Js::get($description, 'key'), 'windowsVirtualKeyCode' => Js::get($description, 'keyCode'), 'code' => Js::get($description, 'code'), 'location' => Js::get($description, 'location')])]));
            return UndefinedValue::Value;
        });
    }

    public function sendCharacter(mixed $char): mixed
    {
        return Js::async(function () use ($char) {
            Js::await(Js::invoke($this->client, 'send', ['Input.insertText', Js::object(['text' => $char])]));
            return UndefinedValue::Value;
        });
    }

    private function charIsKey(mixed $char): mixed
    {
        return !Js::truthy(!Js::truthy(Js::get(\Nesk\Puphpeteer\Native\Generated\Upstream\KeyboardLayout::DEFINITIONS, ($char))));
    }

    public function type(mixed $text, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($text, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $delay = Js::logicalOr(Js::get($options, 'delay'), fn () => UndefinedValue::Value);
            foreach (Js::iterate($text) as $char) {
                if (Js::truthy($this->charIsKey($char))) {
                    Js::await($this->press($char, Js::object(['delay' => $delay])));
                } else {
                    if (Js::truthy($delay)) {
                        Js::await(Js::delay($delay));
                    }
                    Js::await($this->sendCharacter($char));
                }
            }
            return UndefinedValue::Value;
        });
    }

    public function press(mixed $key, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($key, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding1 = $options;
            $delay = Js::defaultValue(Js::get($_nativeBinding1, 'delay'), fn () => null);
            Js::await($this->down($key, $options));
            if (Js::truthy($delay)) {
                Js::await(Js::delay(Js::get($options, 'delay')));
            }
            Js::await($this->up($key));
            return UndefinedValue::Value;
        });
    }
}
