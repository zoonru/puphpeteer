<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/Deferred.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class Deferred
{
    private mixed $Deferred_isResolved = UndefinedValue::Value;
    private mixed $Deferred_isRejected = UndefinedValue::Value;
    private mixed $Deferred_value = UndefinedValue::Value;
    private mixed $Deferred_resolve = UndefinedValue::Value;
    private mixed $Deferred_taskPromise = UndefinedValue::Value;
    private mixed $Deferred_timeoutId = UndefinedValue::Value;
    private mixed $Deferred_timeoutError = UndefinedValue::Value;
    private mixed $Deferred_promise = UndefinedValue::Value;

    public static function create(mixed $opts = UndefinedValue::Value): mixed
    {
        return new self($opts);
    }

    public static function race(mixed $awaitables): mixed
    {
        return Js::async(function () use ($awaitables) {
            $deferredWithTimeout = new \Nesk\Puphpeteer\Native\Runtime\JsSet();
            try {
                $promises = Js::invoke($awaitables, 'map', [function (mixed $value) use ($deferredWithTimeout) {
    if (Js::truthy(($value instanceof self))) {
        if (Js::truthy(($value)->Deferred_timeoutId)) {
            Js::invoke($deferredWithTimeout, 'add', [$value]);
        }
        return Js::invoke($value, 'valueOrThrow', []);
    }
    return $value;
}]);
                return Js::await(Js::race($promises));
            } finally {
                foreach (Js::iterate($deferredWithTimeout) as $deferred) {
                    Js::invoke($deferred, 'reject', [new \RuntimeException('Timeout cleared')]);
                }
            }
        });
    }

    public function __construct(mixed $opts = UndefinedValue::Value)
    {
        $this->Deferred_isResolved = false;
        $this->Deferred_isRejected = false;
        $this->Deferred_taskPromise = Js::promise(function (mixed $resolve) {
    $this->Deferred_resolve = $resolve;
    return UndefinedValue::Value;
});
        if (Js::truthy(Js::logicalAnd($opts, fn () => Js::numeric('>', Js::get($opts, 'timeout'), 0)))) {
            $this->Deferred_timeoutError = new \Nesk\Puphpeteer\Native\TimeoutError(Js::get($opts, 'message'));
            $this->Deferred_timeoutId = Js::setTimeout(function () {
    $this->reject(($this->Deferred_timeoutError));
    return UndefinedValue::Value;
}, Js::get($opts, 'timeout'));
        }
    }

    private function Deferred_finish(mixed $value): mixed
    {
        Js::clearTimeout($this->Deferred_timeoutId);
        $this->Deferred_value = $value;
        ($this->Deferred_resolve)();
        return UndefinedValue::Value;
    }

    public function resolve(mixed $value = UndefinedValue::Value): mixed
    {
        if (Js::truthy(Js::logicalOr($this->Deferred_isRejected, fn () => $this->Deferred_isResolved))) {
            return UndefinedValue::Value;
        }
        $this->Deferred_isResolved = true;
        $this->Deferred_finish($value);
        return UndefinedValue::Value;
    }

    public function reject(mixed $error): mixed
    {
        if (Js::truthy(Js::logicalOr($this->Deferred_isRejected, fn () => $this->Deferred_isResolved))) {
            return UndefinedValue::Value;
        }
        $this->Deferred_isRejected = true;
        $this->Deferred_finish($error);
        return UndefinedValue::Value;
    }

    public function resolved(): mixed
    {
        return $this->Deferred_isResolved;
    }

    public function finished(): mixed
    {
        return Js::logicalOr($this->Deferred_isResolved, fn () => $this->Deferred_isRejected);
    }

    public function value(): mixed
    {
        return $this->Deferred_value;
    }

    public function valueOrThrow(): mixed
    {
        if (Js::truthy(!Js::truthy($this->Deferred_promise))) {
            $this->Deferred_promise = ((function () {
    return Js::async(function () {
    Js::await($this->Deferred_taskPromise);
    if (Js::truthy($this->Deferred_isRejected)) {
        throw $this->Deferred_value;
    }
    return ($this->Deferred_value);
    });
}))();
        }
        return $this->Deferred_promise;
    }
}
