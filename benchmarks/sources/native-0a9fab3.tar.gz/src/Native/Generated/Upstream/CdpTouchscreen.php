<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Input.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CdpTouchscreen extends Touchscreen
{
    private mixed $CdpTouchscreen_client;
    private mixed $CdpTouchscreen_keyboard;

    public function __construct(mixed $client, mixed $keyboard)
    {
        parent::__construct();
        $this->CdpTouchscreen_client = $client;
        $this->CdpTouchscreen_keyboard = $keyboard;
    }

    public function updateClient(mixed $client): mixed
    {
        $this->CdpTouchscreen_client = $client;
        Js::invoke($this->touches, 'forEach', [function (mixed $t) use ($client) {
    Js::invoke($t, 'updateClient', [$client]);
    return UndefinedValue::Value;
}]);
        return UndefinedValue::Value;
    }

    public function touchStart(mixed $x, mixed $y): mixed
    {
        return Js::async(function () use ($x, $y) {
            $id = ($this->idGenerator)();
            $touchPoint = Js::object(['x' => Js::round($x), 'y' => Js::round($y), 'radiusX' => 0.5, 'radiusY' => 0.5, 'force' => 0.5, 'id' => $id]);
            $touch = new \Nesk\Puphpeteer\Native\TouchHandle($this->CdpTouchscreen_client, $this, $this->CdpTouchscreen_keyboard, $touchPoint);
            Js::await(Js::invoke($touch, 'start', []));
            Js::invoke($this->touches, 'push', [$touch]);
            return $touch;
        });
    }
}
