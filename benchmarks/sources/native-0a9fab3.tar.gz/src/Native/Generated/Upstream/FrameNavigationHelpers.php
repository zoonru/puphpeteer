<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class FrameNavigationHelpers
{
    public static function referrerPolicyToProtocol(mixed $referrerPolicy): mixed
    {
        return (Js::invoke($referrerPolicy, 'replaceAll', [new \Nesk\Puphpeteer\Native\Runtime\JsRegExp('/-./', true), function (mixed $match) {
    return Js::invoke((Js::get($match, 1)), 'toUpperCase', []);
}]));
    }
}
