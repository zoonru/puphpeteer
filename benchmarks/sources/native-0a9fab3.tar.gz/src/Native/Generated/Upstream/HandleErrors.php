<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/decorators.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class HandleErrors
{
    public static function assertActive(mixed $handle): void
    {
        if (Js::truthy(Js::get($handle, 'disposed'))) {
            throw new \RuntimeException(Js::call(function (mixed $value) {
    return ('Attempted to use disposed ' . Js::string(Js::get(Js::get($value, 'constructor'), 'name')) . '.');
}, [$handle]));
        }
    }
}
