<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageNetworkIdleCommands
{
    private mixed $Page_inflight;
    private function initializePageNetworkIdle(): void
    {
        $this->Page_inflight = new \Nesk\Puphpeteer\Native\Runtime\Observable\ReplaySubject(1);
        Js::invoke(Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Request')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::mergeMap(function (mixed $originalRequest) {
    return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::concat(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::of(1), Js::invoke(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::merge(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'RequestFailed')), ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'RequestFinished')), Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Response')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function (mixed $response) {
    return Js::invoke($response, 'request', []);
})])), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::filter(function (mixed $request) use ($originalRequest) {
    return Js::strictEqual(Js::get($request, 'id'), Js::get($originalRequest, 'id'));
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::take(1), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    return (-1);
})]));
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::mergeScan(function (mixed $acc, mixed $addend) {
    return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::of(Js::add($acc, $addend));
}, 0), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::takeUntil(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Close'))), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::startWith(0)]), 'subscribe', [$this->Page_inflight]);
    }

    public function waitForNetworkIdle(mixed $options = UndefinedValue::Value): mixed
    {
        if ($options === UndefinedValue::Value) { $options = Js::object([]); }
        return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::firstValueFrom($this->waitForNetworkIdleObservable($options));
    }

    public function waitForNetworkIdleObservable(mixed $options = UndefinedValue::Value): mixed
    {
        if ($options === UndefinedValue::Value) { $options = Js::object([]); }
        $_nativeBinding1 = $options;
        $ms = Js::defaultValue(Js::get($_nativeBinding1, 'timeout'), fn () => Js::invoke($this->timeouts, 'timeout', []));
        $idleTime = Js::defaultValue(Js::get($_nativeBinding1, 'idleTime'), fn () => 500);
        $concurrency = Js::defaultValue(Js::get($_nativeBinding1, 'concurrency'), fn () => 0);
        $signal = Js::get($_nativeBinding1, 'signal');
        return Js::invoke($this->Page_inflight, 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function (mixed $inflight) use ($concurrency) {
    return Js::numeric('>', $inflight, $concurrency);
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::distinctUntilChanged(), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::switchMap(function (mixed $isInflightOverConcurrency) use ($idleTime) {
    if (Js::truthy($isInflightOverConcurrency)) {
        return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::empty();
    }
    return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::timer($idleTime);
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    return UndefinedValue::Value;
}), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::raceWith(ObservableUtilities::timeout($ms), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::fromAbortSignal($signal), Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Close')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    throw new \Nesk\Puphpeteer\Native\TargetCloseError('Page closed!');
})]))]);
    }

    public function waitForRequest(mixed $urlOrPredicate, mixed $options = UndefinedValue::Value): mixed
    {
        if ($options === UndefinedValue::Value) { $options = Js::object([]); }
        $_nativeBinding2 = $options;
        $ms = Js::defaultValue(Js::get($_nativeBinding2, 'timeout'), fn () => Js::invoke($this->timeouts, 'timeout', []));
        $signal = Js::get($_nativeBinding2, 'signal');
        if (Js::truthy(Js::strictEqual(Js::typeOf($urlOrPredicate), 'string'))) {
            $url = $urlOrPredicate;
            $urlOrPredicate = function (mixed $request) use ($url) {
    return Js::strictEqual(Js::invoke($request, 'url', []), $url);
};
        }
        $_nativeJs6f627365727661626c6524 = Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Request')), 'pipe', [ObservableUtilities::filterAsync($urlOrPredicate), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::raceWith(ObservableUtilities::timeout($ms), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::fromAbortSignal($signal), Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Close')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    throw new \Nesk\Puphpeteer\Native\TargetCloseError('Page closed!');
})]))]);
        return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::firstValueFrom($_nativeJs6f627365727661626c6524);
    }

    public function waitForResponse(mixed $urlOrPredicate, mixed $options = UndefinedValue::Value): mixed
    {
        if ($options === UndefinedValue::Value) { $options = Js::object([]); }
        $_nativeBinding3 = $options;
        $ms = Js::defaultValue(Js::get($_nativeBinding3, 'timeout'), fn () => Js::invoke($this->timeouts, 'timeout', []));
        $signal = Js::get($_nativeBinding3, 'signal');
        if (Js::truthy(Js::strictEqual(Js::typeOf($urlOrPredicate), 'string'))) {
            $url = $urlOrPredicate;
            $urlOrPredicate = function (mixed $response) use ($url) {
    return Js::strictEqual(Js::invoke($response, 'url', []), $url);
};
        }
        $_nativeJs6f627365727661626c6524 = Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Response')), 'pipe', [ObservableUtilities::filterAsync($urlOrPredicate), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::raceWith(ObservableUtilities::timeout($ms), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::fromAbortSignal($signal), Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Close')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    throw new \Nesk\Puphpeteer\Native\TargetCloseError('Page closed!');
})]))]);
        return \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::firstValueFrom($_nativeJs6f627365727661626c6524);
    }

    public function waitForFrame(mixed $urlOrPredicate, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($urlOrPredicate, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding4 = $options;
            $ms = Js::defaultValue(Js::get($_nativeBinding4, 'timeout'), fn () => $this->getDefaultTimeout());
            $signal = Js::get($_nativeBinding4, 'signal');
            $predicate = (Js::truthy(Js::isString($urlOrPredicate)) ? function (mixed $frame) use ($urlOrPredicate) {
    return Js::strictEqual($urlOrPredicate, Js::invoke($frame, 'url', []));
} : $urlOrPredicate);
            return Js::await(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::firstValueFrom(Js::invoke(\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::merge(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'FrameAttached')), ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'FrameNavigated')), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::from($this->frames())), 'pipe', [ObservableUtilities::filterAsync($predicate), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::first(), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::raceWith(ObservableUtilities::timeout($ms), \Nesk\Puphpeteer\Native\Runtime\Observable\Rx::fromAbortSignal($signal), Js::invoke(ObservableUtilities::fromEmitterEvent($this, Js::get(Js::object(['Request'=>'request','RequestFailed'=>'requestfailed','RequestFinished'=>'requestfinished','Response'=>'response','Close'=>'close','FrameAttached'=>'frameattached','FrameNavigated'=>'framenavigated']), 'Close')), 'pipe', [\Nesk\Puphpeteer\Native\Runtime\Observable\Rx::map(function () {
    throw new \Nesk\Puphpeteer\Native\TargetCloseError('Page closed.');
})]))])));
        });
    }
}
