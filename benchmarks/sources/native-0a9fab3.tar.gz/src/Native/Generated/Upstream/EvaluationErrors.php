<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/utils.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class EvaluationErrors
{
    public static function createEvaluationError(mixed $details): mixed
    {
        $name = UndefinedValue::Value;
        $message = UndefinedValue::Value;
        if (Js::truthy(!Js::truthy(Js::get($details, 'exception')))) {
            $name = 'Error';
            $message = Js::get($details, 'text');
        } else {
            if (Js::truthy(Js::logicalAnd((Js::logicalOr(!Js::strictEqual(Js::get(Js::get($details, 'exception'), 'type'), 'object'), fn () => !Js::strictEqual(Js::get(Js::get($details, 'exception'), 'subtype'), 'error'))), fn () => !Js::truthy(Js::get(Js::get($details, 'exception'), 'objectId'))))) {
                return RemoteValues::valueFromRemoteObject(Js::get($details, 'exception'));
            } else {
                $detail = ClientErrors::getErrorDetails($details);
                $name = Js::get($detail, 'name');
                $message = Js::get($detail, 'message');
            }
        }
        $messageHeight = Js::get(Js::invoke($message, 'split', ['
']), 'length');
        $error = new \Nesk\Puphpeteer\Native\Runtime\BrowserError($message);
        Js::set($error, 'name', $name);
        $stackLines = Js::invoke((Js::get($error, 'stack')), 'split', ['
']);
        $messageLines = Js::invoke($stackLines, 'splice', [0, $messageHeight]);
        Js::invoke($stackLines, 'shift', []);
        if (Js::truthy(Js::logicalAnd(Js::get($details, 'stackTrace'), fn () => Js::numeric('<', Js::get($stackLines, 'length'), Js::get(Js::object(['stackTraceLimit'=>\Nesk\Puphpeteer\Native\Runtime\BrowserError::$stackTraceLimit]), 'stackTraceLimit'))))) {
            foreach (Js::iterate(Js::invoke(Js::get(Js::get($details, 'stackTrace'), 'callFrames'), 'reverse', [])) as $frame) {
                if (Js::truthy(Js::logicalAnd(PuppeteerURL::isPuppeteerURL(Js::get($frame, 'url')), fn () => !Js::strictEqual(Js::get($frame, 'url'), Js::get(Js::object(['INTERNAL_URL'=>PuppeteerURL::$INTERNAL_URL]), 'INTERNAL_URL'))))) {
                    $url = PuppeteerURL::parse(Js::get($frame, 'url'));
                    Js::invoke($stackLines, 'unshift', [('    at ' . Js::string(Js::logicalOr(Js::get($frame, 'functionName'), fn () => Js::get($url, 'functionName'))) . ' (' . Js::string(Js::get($url, 'functionName')) . ' at ' . Js::string(Js::get($url, 'siteString')) . ', <anonymous>:' . Js::string(Js::get($frame, 'lineNumber')) . ':' . Js::string(Js::get($frame, 'columnNumber')) . ')')]);
                } else {
                    Js::invoke($stackLines, 'push', [('    at ' . Js::string(Js::logicalOr(Js::get($frame, 'functionName'), fn () => '<anonymous>')) . ' (' . Js::string(Js::get($frame, 'url')) . ':' . Js::string(Js::get($frame, 'lineNumber')) . ':' . Js::string(Js::get($frame, 'columnNumber')) . ')')]);
                }
                if (Js::truthy(Js::numeric('>=', Js::get($stackLines, 'length'), Js::get(Js::object(['stackTraceLimit'=>\Nesk\Puphpeteer\Native\Runtime\BrowserError::$stackTraceLimit]), 'stackTraceLimit')))) {
                    break;
                }
            }
        }
        Js::set($error, 'stack', Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\JsArray([...Js::iterate($messageLines), ...Js::iterate($stackLines)]), 'join', ['
']));
        return $error;
    }
}
