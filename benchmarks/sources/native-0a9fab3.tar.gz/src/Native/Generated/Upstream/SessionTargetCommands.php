<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/CdpSession.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait SessionTargetCommands
{

    public function setTarget(mixed $target): mixed
    {
        $this->sourceTarget = $target;
        return UndefinedValue::Value;
    }

    public function target(): mixed
    {
        Js::assert($this->sourceTarget, 'Target must exist');
        return $this->sourceTarget;
    }
}
