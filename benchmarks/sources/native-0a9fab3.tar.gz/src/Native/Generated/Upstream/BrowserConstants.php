<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Browser.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;

final class BrowserConstants
{
    public static function permissions(): \Nesk\Puphpeteer\Native\Runtime\JsMap
    {
        static $map;
        return $map ??= new \Nesk\Puphpeteer\Native\Runtime\JsMap(new \Nesk\Puphpeteer\Native\Runtime\JsArray([new \Nesk\Puphpeteer\Native\Runtime\JsArray(['accelerometer', 'sensors']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['ambient-light-sensor', 'sensors']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['background-sync', 'backgroundSync']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['camera', 'videoCapture']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['clipboard-read', 'clipboardReadWrite']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['clipboard-sanitized-write', 'clipboardSanitizedWrite']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['clipboard-write', 'clipboardReadWrite']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['geolocation', 'geolocation']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['gyroscope', 'sensors']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['idle-detection', 'idleDetection']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['keyboard-lock', 'keyboardLock']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['magnetometer', 'sensors']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['microphone', 'audioCapture']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['midi', 'midi']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['notifications', 'notifications']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['payment-handler', 'paymentHandler']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['persistent-storage', 'durableStorage']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['pointer-lock', 'pointerLock']), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['midi-sysex', 'midiSysex'])]));
    }
}
