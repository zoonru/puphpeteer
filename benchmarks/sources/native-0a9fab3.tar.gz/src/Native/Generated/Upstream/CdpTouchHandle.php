<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Input.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CdpTouchHandle
{
    private mixed $CdpTouchHandle_started;
    private mixed $CdpTouchHandle_touchScreen;
    private mixed $CdpTouchHandle_touchPoint;
    private mixed $CdpTouchHandle_client;
    private mixed $CdpTouchHandle_keyboard;

    public function __construct(mixed $client, mixed $touchScreen, mixed $keyboard, mixed $touchPoint)
    {
        $this->CdpTouchHandle_started = false;
        $this->CdpTouchHandle_client = $client;
        $this->CdpTouchHandle_touchScreen = $touchScreen;
        $this->CdpTouchHandle_keyboard = $keyboard;
        $this->CdpTouchHandle_touchPoint = $touchPoint;
    }

    public function updateClient(mixed $client): mixed
    {
        $this->CdpTouchHandle_client = $client;
        return UndefinedValue::Value;
    }

    public function start(): mixed
    {
        return Js::async(function () {
            if (Js::truthy($this->CdpTouchHandle_started)) {
                throw new \Nesk\Puphpeteer\Native\TouchError('Touch has already started');
            }
            Js::await(Js::invoke($this->CdpTouchHandle_client, 'send', ['Input.dispatchTouchEvent', Js::object(['type' => 'touchStart', 'touchPoints' => new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->CdpTouchHandle_touchPoint]), 'modifiers' => Js::get($this->CdpTouchHandle_keyboard, '_modifiers')])]));
            $this->CdpTouchHandle_started = true;
            return UndefinedValue::Value;
        });
    }

    public function move(mixed $x, mixed $y): mixed
    {
        Js::set($this->CdpTouchHandle_touchPoint, 'x', Js::round($x));
        Js::set($this->CdpTouchHandle_touchPoint, 'y', Js::round($y));
        return Js::invoke($this->CdpTouchHandle_client, 'send', ['Input.dispatchTouchEvent', Js::object(['type' => 'touchMove', 'touchPoints' => new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->CdpTouchHandle_touchPoint]), 'modifiers' => Js::get($this->CdpTouchHandle_keyboard, '_modifiers')])]);
    }

    public function end(): mixed
    {
        return Js::async(function () {
            Js::await(Js::invoke($this->CdpTouchHandle_client, 'send', ['Input.dispatchTouchEvent', Js::object(['type' => 'touchEnd', 'touchPoints' => new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->CdpTouchHandle_touchPoint]), 'modifiers' => Js::get($this->CdpTouchHandle_keyboard, '_modifiers')])]));
            Js::invoke($this->CdpTouchHandle_touchScreen, 'removeHandle', [$this]);
            return UndefinedValue::Value;
        });
    }
}
