<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Coverage.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class CoverageHelpers
{
    public static function convertToDisjointRanges(mixed $nestedRanges): mixed
    {
        $points = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        foreach (Js::iterate($nestedRanges) as $range) {
            Js::invoke($points, 'push', [Js::object(['offset' => Js::get($range, 'startOffset'), 'type' => 0, 'range' => $range])]);
            Js::invoke($points, 'push', [Js::object(['offset' => Js::get($range, 'endOffset'), 'type' => 1, 'range' => $range])]);
        }
        Js::invoke($points, 'sort', [function (mixed $a, mixed $b) {
    if (Js::truthy(!Js::strictEqual(Js::get($a, 'offset'), Js::get($b, 'offset')))) {
        return Js::numeric('-', Js::get($a, 'offset'), Js::get($b, 'offset'));
    }
    if (Js::truthy(!Js::strictEqual(Js::get($a, 'type'), Js::get($b, 'type')))) {
        return Js::numeric('-', Js::get($b, 'type'), Js::get($a, 'type'));
    }
    $aLength = Js::numeric('-', Js::get(Js::get($a, 'range'), 'endOffset'), Js::get(Js::get($a, 'range'), 'startOffset'));
    $bLength = Js::numeric('-', Js::get(Js::get($b, 'range'), 'endOffset'), Js::get(Js::get($b, 'range'), 'startOffset'));
    if (Js::truthy(Js::strictEqual(Js::get($a, 'type'), 0))) {
        return Js::numeric('-', $bLength, $aLength);
    }
    return Js::numeric('-', $aLength, $bLength);
}]);
        $hitCountStack = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $results = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        $lastOffset = 0;
        foreach (Js::iterate($points) as $point) {
            if (Js::truthy(Js::logicalAnd(Js::logicalAnd(Js::get($hitCountStack, 'length'), fn () => Js::numeric('<', $lastOffset, Js::get($point, 'offset'))), fn () => Js::numeric('>', (Js::get($hitCountStack, Js::numeric('-', Js::get($hitCountStack, 'length'), 1))), 0)))) {
                $lastResult = Js::get($results, Js::numeric('-', Js::get($results, 'length'), 1));
                if (Js::truthy(Js::logicalAnd($lastResult, fn () => Js::strictEqual(Js::get($lastResult, 'end'), $lastOffset)))) {
                    Js::set($lastResult, 'end', Js::get($point, 'offset'));
                } else {
                    Js::invoke($results, 'push', [Js::object(['start' => $lastOffset, 'end' => Js::get($point, 'offset')])]);
                }
            }
            $lastOffset = Js::get($point, 'offset');
            if (Js::truthy(Js::strictEqual(Js::get($point, 'type'), 0))) {
                Js::invoke($hitCountStack, 'push', [Js::get(Js::get($point, 'range'), 'count')]);
            } else {
                Js::invoke($hitCountStack, 'pop', []);
            }
        }
        return Js::invoke($results, 'filter', [function (mixed $range) {
    return Js::numeric('>', Js::numeric('-', Js::get($range, 'end'), Js::get($range, 'start')), 0);
}]);
    }

    // Predicate body from common/util.ts, PuppeteerURL.isPuppeteerURL.
    public static function isPuppeteerURL(mixed $url): mixed
    {
        return (function (mixed $url) {
    return Js::invoke($url, 'startsWith', ['pptr:']);
})($url);
    }
}
