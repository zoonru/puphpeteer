<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Input.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

abstract class Touchscreen
{
    public mixed $idGenerator;
    public mixed $touches;

    public function __construct()
    {
        $this->idGenerator = IncrementalIdGenerator::createIncrementalIdGenerator();
        $this->touches = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
    }

    public function removeHandle(mixed $handle): mixed
    {
        $index = Js::invoke($this->touches, 'indexOf', [$handle]);
        if (Js::truthy(Js::strictEqual($index, (-1)))) {
            return UndefinedValue::Value;
        }
        Js::invoke($this->touches, 'splice', [$index, 1]);
        return UndefinedValue::Value;
    }

    public function tap(mixed $x, mixed $y): mixed
    {
        return Js::async(function () use ($x, $y) {
            $touch = Js::await($this->touchStart($x, $y));
            Js::await(Js::invoke($touch, 'end', []));
            return UndefinedValue::Value;
        });
    }

    abstract public function touchStart(mixed $x, mixed $y): mixed;

    public function touchMove(mixed $x, mixed $y): mixed
    {
        return Js::async(function () use ($x, $y) {
            $touch = Js::get($this->touches, 0);
            if (Js::truthy(!Js::truthy($touch))) {
                throw new \Nesk\Puphpeteer\Native\TouchError('Must start a new Touch first');
            }
            return Js::await(Js::invoke($touch, 'move', [$x, $y]));
        });
    }

    public function touchEnd(): mixed
    {
        return Js::async(function () {
            $touch = Js::invoke($this->touches, 'shift', []);
            if (Js::truthy(!Js::truthy($touch))) {
                throw new \Nesk\Puphpeteer\Native\TouchError('Must start a new Touch first');
            }
            Js::await(Js::invoke($touch, 'end', []));
            return UndefinedValue::Value;
        });
    }
}
