<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/ScriptInjector.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class ScriptInjector implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $ScriptInjector_updated;
    private mixed $ScriptInjector_amendments;

    public function append(mixed $statement): mixed
    {
        $this->ScriptInjector_update(function () use ($statement) {
    Js::invoke($this->ScriptInjector_amendments, 'add', [$statement]);
    return UndefinedValue::Value;
});
        return UndefinedValue::Value;
    }

    public function pop(mixed $statement): mixed
    {
        $this->ScriptInjector_update(function () use ($statement) {
    Js::invoke($this->ScriptInjector_amendments, 'delete', [$statement]);
    return UndefinedValue::Value;
});
        return UndefinedValue::Value;
    }

    public function inject(mixed $inject, mixed $force = false): mixed
    {
        if (Js::truthy(Js::logicalOr($this->ScriptInjector_updated, fn () => $force))) {
            $inject($this->ScriptInjector_get());
        }
        $this->ScriptInjector_updated = false;
        return UndefinedValue::Value;
    }

    private function ScriptInjector_update(mixed $callback): mixed
    {
        $callback();
        $this->ScriptInjector_updated = true;
        return UndefinedValue::Value;
    }

    private function ScriptInjector_get(): mixed
    {
        return ('(() => {
      const module = {};
      ' . Js::string(file_get_contents(__DIR__ . '/../injected.js')) . '
      ' . Js::string(Js::invoke(Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\JsArray([...Js::iterate($this->ScriptInjector_amendments)]), 'map', [function (mixed $statement) {
    return ('(' . Js::string($statement) . ')(module.exports.default);');
}]), 'join', [''])) . '
      return module.exports.default;
    })()');
    }

    public function __construct()
    {
        $this->ScriptInjector_updated = false;
        $this->ScriptInjector_amendments = new \Nesk\Puphpeteer\Native\Runtime\JsSet();
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
