<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: common/LazyArg.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
class LazyArg
{
    public static function create(mixed $get): mixed
    {
        return (function (mixed $get) {
    return ((new LazyArg($get)));
})($get);
    }
    private mixed $LazyArg_get = UndefinedValue::Value;
    private function __construct(mixed $get)
    {
        $this->LazyArg_get = $get;
    }
    public function get(mixed $context): mixed
    {
        return Js::async(function () use ($context) {
            return Js::await(($this->LazyArg_get)($context));
        });
    }
}
