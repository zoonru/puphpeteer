<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageDocumentCommands
{

    public function content(): mixed
    {
        return Js::async(function () {
            return Js::await(Js::invoke($this->mainFrame(), 'content', []));
        });
    }

    public function setContent(mixed $html, mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($html, $options) {
            Js::await(Js::invoke($this->mainFrame(), 'setContent', [$html, $options]));
            return UndefinedValue::Value;
        });
    }
}
