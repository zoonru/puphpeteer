<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameLifecycleCommands
{

    public function _onLifecycleEvent(mixed $loaderId, mixed $name): mixed
    {
        if (Js::truthy(Js::strictEqual($name, 'init'))) {
            $this->loaderId = $loaderId;
            Js::invoke($this->_lifecycleEvents, 'clear', []);
        }
        Js::invoke($this->_lifecycleEvents, 'add', [$name]);
        return UndefinedValue::Value;
    }

    public function _onLoadingStopped(): mixed
    {
        Js::invoke($this->_lifecycleEvents, 'add', ['DOMContentLoaded']);
        Js::invoke($this->_lifecycleEvents, 'add', ['load']);
        return UndefinedValue::Value;
    }

    public function _onLoadingStarted(): mixed
    {
        $this->_hasStartedLoading = true;
        return UndefinedValue::Value;
    }
}
