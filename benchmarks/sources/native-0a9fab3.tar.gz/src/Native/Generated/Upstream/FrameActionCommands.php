<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameActionCommands
{

    public function click(mixed $selector, mixed $options = UndefinedValue::Value): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($selector, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $handle = Js::await($this->querySelector($selector));
            try {
                Js::assert($handle, ('No element found for selector: ' . Js::string($selector) . ''));
                Js::await(Js::invoke($handle, 'click', [$options]));
                Js::await(Js::invoke($handle, 'dispose', []));
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }

    public function hover(mixed $selector): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($selector) {
            $handle = Js::await($this->querySelector($selector));
            try {
                Js::assert($handle, ('No element found for selector: ' . Js::string($selector) . ''));
                Js::await(Js::invoke($handle, 'hover', []));
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }

    public function tap(mixed $selector): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($selector) {
            $handle = Js::await($this->querySelector($selector));
            try {
                Js::assert($handle, ('No element found for selector: ' . Js::string($selector) . ''));
                Js::await(Js::invoke($handle, 'tap', []));
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }

    public function type(mixed $selector, mixed $text, mixed $options = UndefinedValue::Value): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($selector, $text, $options) {
            $handle = Js::await($this->querySelector($selector));
            try {
                Js::assert($handle, ('No element found for selector: ' . Js::string($selector) . ''));
                Js::await(Js::invoke($handle, 'type', [$text, $options]));
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }

    public function focus(mixed $selector): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($selector) {
            $handle = Js::await($this->querySelector($selector));
            try {
                Js::assert($handle, ('No element found for selector: ' . Js::string($selector) . ''));
                Js::await(Js::invoke($handle, 'focus', []));
            } finally {
                Js::disposeHandle($handle);
            }
            return UndefinedValue::Value;
        });
    }
}
