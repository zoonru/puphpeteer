<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Dialog.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CdpDialog extends Dialog
{
    protected mixed $CdpDialog_client = UndefinedValue::Value;

    public function __construct(mixed $client, mixed $type, mixed $message, mixed $defaultValue = '')
    {
        parent::__construct($type, $message, $defaultValue);
        $this->CdpDialog_client = $client;
    }

    public function handle(mixed $options): mixed
    {
        return Js::async(function () use ($options) {
            Js::await(Js::invoke($this->CdpDialog_client, 'send', ['Page.handleJavaScriptDialog', Js::object(['accept' => Js::get($options, 'accept'), 'promptText' => Js::get($options, 'text')])]));
            return UndefinedValue::Value;
        });
    }
}
