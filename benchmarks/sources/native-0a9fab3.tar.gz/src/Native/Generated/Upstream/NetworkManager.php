<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/NetworkManager.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class NetworkManager extends EventEmitter
{
    private mixed $frameProvider;
    protected mixed $networkEvents;
    private mixed $NetworkManager_extraHTTPHeaders;
    private mixed $NetworkManager_credentials;
    private mixed $NetworkManager_attemptedAuthentications;
    private mixed $NetworkManager_userRequestInterceptionEnabled;
    private mixed $NetworkManager_protocolRequestInterceptionEnabled;
    private mixed $NetworkManager_userCacheDisabled;
    private mixed $NetworkManager_emulatedNetworkConditions;
    private mixed $NetworkManager_userAgent;
    private mixed $NetworkManager_userAgentMetadata;
    private mixed $NetworkManager_platform;
    private mixed $NetworkManager_handlers;
    private mixed $NetworkManager_clients;
    private mixed $NetworkManager_networkEnabled;

    public function __construct(mixed $frameManager, mixed $networkEnabled = UndefinedValue::Value)
    {
        parent::__construct();
        $this->frameProvider = UndefinedValue::Value;
        $this->networkEvents = new NetworkEventStore();
        $this->NetworkManager_extraHTTPHeaders = UndefinedValue::Value;
        $this->NetworkManager_credentials = null;
        $this->NetworkManager_attemptedAuthentications = new \Nesk\Puphpeteer\Native\Runtime\JsSet();
        $this->NetworkManager_userRequestInterceptionEnabled = false;
        $this->NetworkManager_protocolRequestInterceptionEnabled = UndefinedValue::Value;
        $this->NetworkManager_userCacheDisabled = UndefinedValue::Value;
        $this->NetworkManager_emulatedNetworkConditions = UndefinedValue::Value;
        $this->NetworkManager_userAgent = UndefinedValue::Value;
        $this->NetworkManager_userAgentMetadata = UndefinedValue::Value;
        $this->NetworkManager_platform = UndefinedValue::Value;
        $this->NetworkManager_handlers = (new \Nesk\Puphpeteer\Native\Runtime\JsArray([new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Fetch.requestPaused', $this->NetworkManager_onRequestPaused(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Fetch.authRequired', $this->NetworkManager_onAuthRequired(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.requestWillBeSent', $this->NetworkManager_onRequestWillBeSent(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.requestWillBeSentExtraInfo', $this->NetworkManager_onRequestWillBeSentExtraInfo(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.requestServedFromCache', $this->NetworkManager_onRequestServedFromCache(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.responseReceived', $this->NetworkManager_onResponseReceived(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.loadingFinished', $this->NetworkManager_onLoadingFinished(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.loadingFailed', $this->NetworkManager_onLoadingFailed(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray(['Network.responseReceivedExtraInfo', $this->NetworkManager_onResponseReceivedExtraInfo(...)]), new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::get(Js::object(['Disconnected' => '__native_session_closed']), 'Disconnected'), $this->removeClient(...)])]));
        $this->NetworkManager_clients = new \Nesk\Puphpeteer\Native\Runtime\ObjectMap();
        $this->NetworkManager_networkEnabled = true;
        $this->frameProvider = $frameManager;
        $this->NetworkManager_networkEnabled = Js::coalesce($networkEnabled, fn () => true);
    }

    private function NetworkManager_canIgnoreError(mixed $error): mixed
    {
        return (Js::logicalAnd(Js::isErrorLike($error), fn () => (Js::logicalOr(Js::logicalOr(NetworkPredicates::isTargetClosedError($error), fn () => Js::invoke(Js::get($error, 'message'), 'includes', ['Not supported'])), fn () => Js::invoke(Js::get($error, 'message'), 'includes', ['wasn\'t found'])))));
    }

    public function addClient(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::logicalOr(!Js::truthy($this->NetworkManager_networkEnabled), fn () => Js::invoke($this->NetworkManager_clients, 'has', [$client])))) {
                return UndefinedValue::Value;
            }
            $subscriptions = new DisposableStackPolyfill();
            Js::invoke($this->NetworkManager_clients, 'set', [$client, $subscriptions]);
            $clientEmitter = Js::invoke($subscriptions, 'use', [new \Nesk\Puphpeteer\Native\Runtime\TransportEventEmitter($client)]);
            foreach (Js::iterate($this->NetworkManager_handlers) as $_nativeItem1) {
                $event = Js::get($_nativeItem1, 0);
                $handler = Js::get($_nativeItem1, 1);
                Js::invoke($clientEmitter, 'on', [$event, function (mixed $arg) use ($client, $handler) {
    return Js::callBoundMethod($handler, $this, [$client, $arg]);
}]);
            }
            try {
                Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($client, 'send', ['Network.enable']), $this->NetworkManager_applyExtraHTTPHeaders($client), $this->NetworkManager_applyNetworkConditions($client), $this->NetworkManager_applyProtocolCacheDisabled($client), $this->NetworkManager_applyProtocolRequestInterception($client), $this->NetworkManager_applyUserAgent($client)])));
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    private function removeClient(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            Js::optionalInvoke(Js::invoke($this->NetworkManager_clients, 'get', [$client]), 'dispose', fn () => []);
            Js::invoke($this->NetworkManager_clients, 'delete', [$client]);
            return UndefinedValue::Value;
        });
    }

    public function authenticate(mixed $credentials): mixed
    {
        return Js::async(function () use ($credentials) {
            $this->NetworkManager_credentials = $credentials;
            $enabled = Js::logicalOr($this->NetworkManager_userRequestInterceptionEnabled, fn () => !Js::truthy(!Js::truthy($this->NetworkManager_credentials)));
            if (Js::truthy(Js::strictEqual($enabled, $this->NetworkManager_protocolRequestInterceptionEnabled))) {
                return UndefinedValue::Value;
            }
            $this->NetworkManager_protocolRequestInterceptionEnabled = $enabled;
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyProtocolRequestInterception(...)));
            return UndefinedValue::Value;
        });
    }

    public function setExtraHTTPHeaders(mixed $headers): mixed
    {
        return Js::async(function () use ($headers) {
            $extraHTTPHeaders = Js::object([]);
            foreach (Js::iterate(Js::entries($headers)) as $_nativeItem2) {
                $key = Js::get($_nativeItem2, 0);
                $value = Js::get($_nativeItem2, 1);
                Js::assert(Js::isString($value), ('Expected value of header "' . Js::string($key) . '" to be String, but "' . Js::string(Js::typeOf($value)) . '" is found.'));
                Js::set($extraHTTPHeaders, Js::invoke($key, 'toLowerCase', []), $value);
            }
            $this->NetworkManager_extraHTTPHeaders = $extraHTTPHeaders;
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyExtraHTTPHeaders(...)));
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyExtraHTTPHeaders(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::strictEqual($this->NetworkManager_extraHTTPHeaders, UndefinedValue::Value))) {
                return UndefinedValue::Value;
            }
            try {
                Js::await(Js::invoke($client, 'send', ['Network.setExtraHTTPHeaders', Js::object(['headers' => $this->NetworkManager_extraHTTPHeaders])]));
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    public function extraHTTPHeaders(): mixed
    {
        return Js::assign(Js::object([]), $this->NetworkManager_extraHTTPHeaders);
    }

    public function inFlightRequestsCount(): mixed
    {
        return Js::invoke($this->networkEvents, 'inFlightRequestsCount', []);
    }

    public function setOfflineMode(mixed $value): mixed
    {
        return Js::async(function () use ($value) {
            if (Js::truthy(!Js::truthy($this->NetworkManager_emulatedNetworkConditions))) {
                $this->NetworkManager_emulatedNetworkConditions = Js::object(['offline' => false, 'upload' => (-1), 'download' => (-1), 'latency' => 0]);
            }
            Js::set($this->NetworkManager_emulatedNetworkConditions, 'offline', $value);
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyNetworkConditions(...)));
            return UndefinedValue::Value;
        });
    }

    public function emulateNetworkConditions(mixed $networkConditions): mixed
    {
        return Js::async(function () use ($networkConditions) {
            if (Js::truthy(!Js::truthy($this->NetworkManager_emulatedNetworkConditions))) {
                $this->NetworkManager_emulatedNetworkConditions = Js::object(['offline' => Js::coalesce(Js::optionalGet($networkConditions, 'offline'), fn () => false), 'upload' => (-1), 'download' => (-1), 'latency' => 0]);
            }
            Js::set($this->NetworkManager_emulatedNetworkConditions, 'upload', (Js::truthy($networkConditions) ? Js::get($networkConditions, 'upload') : (-1)));
            Js::set($this->NetworkManager_emulatedNetworkConditions, 'download', (Js::truthy($networkConditions) ? Js::get($networkConditions, 'download') : (-1)));
            Js::set($this->NetworkManager_emulatedNetworkConditions, 'latency', (Js::truthy($networkConditions) ? Js::get($networkConditions, 'latency') : 0));
            Js::set($this->NetworkManager_emulatedNetworkConditions, 'offline', Js::coalesce(Js::optionalGet($networkConditions, 'offline'), fn () => false));
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyNetworkConditions(...)));
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyToAllClients(mixed $fn): mixed
    {
        return Js::async(function () use ($fn) {
            Js::await(Js::all(Js::invoke(Js::arrayFrom(Js::invoke($this->NetworkManager_clients, 'keys', [])), 'map', [function (mixed $client) use ($fn) {
    return $fn($client);
}])));
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyNetworkConditions(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::strictEqual($this->NetworkManager_emulatedNetworkConditions, UndefinedValue::Value))) {
                return UndefinedValue::Value;
            }
            try {
                Js::await(Js::invoke($client, 'send', ['Network.emulateNetworkConditions', Js::object(['offline' => Js::get($this->NetworkManager_emulatedNetworkConditions, 'offline'), 'latency' => Js::get($this->NetworkManager_emulatedNetworkConditions, 'latency'), 'uploadThroughput' => Js::get($this->NetworkManager_emulatedNetworkConditions, 'upload'), 'downloadThroughput' => Js::get($this->NetworkManager_emulatedNetworkConditions, 'download')])]));
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    public function setUserAgent(mixed $userAgent, mixed $userAgentMetadata = UndefinedValue::Value, mixed $platform = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($userAgent, $userAgentMetadata, $platform) {
            $this->NetworkManager_userAgent = $userAgent;
            $this->NetworkManager_userAgentMetadata = $userAgentMetadata;
            $this->NetworkManager_platform = $platform;
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyUserAgent(...)));
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyUserAgent(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::strictEqual($this->NetworkManager_userAgent, UndefinedValue::Value))) {
                return UndefinedValue::Value;
            }
            try {
                Js::await(Js::invoke($client, 'send', ['Network.setUserAgentOverride', Js::object(['userAgent' => $this->NetworkManager_userAgent, 'userAgentMetadata' => $this->NetworkManager_userAgentMetadata, 'platform' => $this->NetworkManager_platform])]));
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    public function setCacheEnabled(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            $this->NetworkManager_userCacheDisabled = !Js::truthy($enabled);
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyProtocolCacheDisabled(...)));
            return UndefinedValue::Value;
        });
    }

    public function setRequestInterception(mixed $value): mixed
    {
        return Js::async(function () use ($value) {
            $this->NetworkManager_userRequestInterceptionEnabled = $value;
            $enabled = Js::logicalOr($this->NetworkManager_userRequestInterceptionEnabled, fn () => !Js::truthy(!Js::truthy($this->NetworkManager_credentials)));
            if (Js::truthy(Js::strictEqual($enabled, $this->NetworkManager_protocolRequestInterceptionEnabled))) {
                return UndefinedValue::Value;
            }
            $this->NetworkManager_protocolRequestInterceptionEnabled = $enabled;
            Js::await($this->NetworkManager_applyToAllClients($this->NetworkManager_applyProtocolRequestInterception(...)));
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyProtocolRequestInterception(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::strictEqual($this->NetworkManager_protocolRequestInterceptionEnabled, UndefinedValue::Value))) {
                return UndefinedValue::Value;
            }
            if (Js::truthy(Js::strictEqual($this->NetworkManager_userCacheDisabled, UndefinedValue::Value))) {
                $this->NetworkManager_userCacheDisabled = false;
            }
            try {
                if (Js::truthy($this->NetworkManager_protocolRequestInterceptionEnabled)) {
                    Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->NetworkManager_applyProtocolCacheDisabled($client), Js::invoke($client, 'send', ['Fetch.enable', Js::object(['handleAuthRequests' => true, 'patterns' => new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::object(['urlPattern' => '*'])])])])])));
                } else {
                    Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([$this->NetworkManager_applyProtocolCacheDisabled($client), Js::invoke($client, 'send', ['Fetch.disable'])])));
                }
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_applyProtocolCacheDisabled(mixed $client): mixed
    {
        return Js::async(function () use ($client) {
            if (Js::truthy(Js::strictEqual($this->NetworkManager_userCacheDisabled, UndefinedValue::Value))) {
                return UndefinedValue::Value;
            }
            try {
                Js::await(Js::invoke($client, 'send', ['Network.setCacheDisabled', Js::object(['cacheDisabled' => $this->NetworkManager_userCacheDisabled])]));
            } catch (\Throwable $error) {
                if (Js::truthy($this->NetworkManager_canIgnoreError($error))) {
                    return UndefinedValue::Value;
                }
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }

    private function NetworkManager_onRequestWillBeSent(mixed $client, mixed $event): mixed
    {
        if (Js::truthy(Js::logicalAnd($this->NetworkManager_userRequestInterceptionEnabled, fn () => !Js::truthy(Js::invoke(Js::get(Js::get($event, 'request'), 'url'), 'startsWith', ['data:']))))) {
            $_nativeBinding3 = $event;
            $networkRequestId = Js::get($_nativeBinding3, 'requestId');
            Js::invoke($this->networkEvents, 'storeRequestWillBeSent', [$networkRequestId, $event]);
            $requestPausedEvent = Js::invoke($this->networkEvents, 'getRequestPaused', [$networkRequestId]);
            if (Js::truthy($requestPausedEvent)) {
                $_nativeBinding4 = $requestPausedEvent;
                $fetchRequestId = Js::get($_nativeBinding4, 'requestId');
                $this->NetworkManager_patchRequestEventHeaders($event, $requestPausedEvent);
                $this->createRequest($client, $event, $fetchRequestId);
                Js::invoke($this->networkEvents, 'forgetRequestPaused', [$networkRequestId]);
            }
            return UndefinedValue::Value;
        }
        $this->createRequest($client, $event, UndefinedValue::Value);
        return UndefinedValue::Value;
    }

    private function NetworkManager_onAuthRequired(mixed $client, mixed $event): mixed
    {
        $response = 'Default';
        if (Js::truthy(Js::invoke($this->NetworkManager_attemptedAuthentications, 'has', [Js::get($event, 'requestId')]))) {
            $response = 'CancelAuth';
        } else {
            if (Js::truthy($this->NetworkManager_credentials)) {
                $response = 'ProvideCredentials';
                Js::invoke($this->NetworkManager_attemptedAuthentications, 'add', [Js::get($event, 'requestId')]);
            }
        }
        $_nativeBinding5 = Js::logicalOr($this->NetworkManager_credentials, fn () => Js::object(['username' => UndefinedValue::Value, 'password' => UndefinedValue::Value]));
        $username = Js::get($_nativeBinding5, 'username');
        $password = Js::get($_nativeBinding5, 'password');
        Js::invoke(Js::invoke($client, 'send', ['Fetch.continueWithAuth', Js::object(['requestId' => Js::get($event, 'requestId'), 'authChallengeResponse' => Js::object(['response' => $response, 'username' => $username, 'password' => $password])])]), 'catch', [Js::debugError(...)]);
        return UndefinedValue::Value;
    }

    private function NetworkManager_onRequestPaused(mixed $client, mixed $event): mixed
    {
        if (Js::truthy(Js::logicalAnd(!Js::truthy($this->NetworkManager_userRequestInterceptionEnabled), fn () => $this->NetworkManager_protocolRequestInterceptionEnabled))) {
            Js::invoke(Js::invoke($client, 'send', ['Fetch.continueRequest', Js::object(['requestId' => Js::get($event, 'requestId')])]), 'catch', [Js::debugError(...)]);
        }
        $_nativeBinding6 = $event;
        $networkRequestId = Js::get($_nativeBinding6, 'networkId');
        $fetchRequestId = Js::get($_nativeBinding6, 'requestId');
        if (Js::truthy(!Js::truthy($networkRequestId))) {
            $this->createUninstrumentedRequest($client, $event);
            return UndefinedValue::Value;
        }
        $requestWillBeSentEvent = ((function () use ($event, $networkRequestId) {
    $requestWillBeSentEvent = Js::invoke($this->networkEvents, 'getRequestWillBeSent', [$networkRequestId]);
    if (Js::truthy(Js::logicalAnd($requestWillBeSentEvent, fn () => (Js::logicalOr(!Js::strictEqual(Js::get(Js::get($requestWillBeSentEvent, 'request'), 'url'), Js::get(Js::get($event, 'request'), 'url')), fn () => !Js::strictEqual(Js::get(Js::get($requestWillBeSentEvent, 'request'), 'method'), Js::get(Js::get($event, 'request'), 'method'))))))) {
        Js::invoke($this->networkEvents, 'forgetRequestWillBeSent', [$networkRequestId]);
        return UndefinedValue::Value;
    }
    return $requestWillBeSentEvent;
}))();
        if (Js::truthy($requestWillBeSentEvent)) {
            $this->NetworkManager_patchRequestEventHeaders($requestWillBeSentEvent, $event);
            $this->createRequest($client, $requestWillBeSentEvent, $fetchRequestId);
        } else {
            Js::invoke($this->networkEvents, 'storeRequestPaused', [$networkRequestId, $event]);
        }
        return UndefinedValue::Value;
    }

    private function NetworkManager_patchRequestEventHeaders(mixed $requestWillBeSentEvent, mixed $requestPausedEvent): mixed
    {
        Js::set(Js::get($requestWillBeSentEvent, 'request'), 'headers', Js::assign(Js::object([]), Js::get(Js::get($requestWillBeSentEvent, 'request'), 'headers'), Js::get(Js::get($requestPausedEvent, 'request'), 'headers')));
        return UndefinedValue::Value;
    }

    private function createUninstrumentedRequest(mixed $client, mixed $event): mixed
    {
        $frame = (Js::truthy(Js::get($event, 'frameId')) ? Js::invoke($this->frameProvider, 'frame', [Js::get($event, 'frameId')]) : null);
        $request = new \Nesk\Puphpeteer\Native\HTTPRequest($client, $frame, Js::get($event, 'requestId'), $this->NetworkManager_userRequestInterceptionEnabled, $event, new \Nesk\Puphpeteer\Native\Runtime\JsArray([]));
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'Request'), $request);
        Js::discard(Js::invoke($request, 'finalizeInterceptions', []));
        return UndefinedValue::Value;
    }

    private function createRequest(mixed $client, mixed $event, mixed $fetchRequestId = UndefinedValue::Value, mixed $fromMemoryCache = false): mixed
    {
        $redirectChain = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        if (Js::truthy(Js::get($event, 'redirectResponse'))) {
            $redirectResponseExtraInfo = null;
            if (Js::truthy(Js::get($event, 'redirectHasExtraInfo'))) {
                $redirectResponseExtraInfo = Js::invoke(Js::invoke($this->networkEvents, 'responseExtraInfo', [Js::get($event, 'requestId')]), 'shift', []);
                if (Js::truthy(!Js::truthy($redirectResponseExtraInfo))) {
                    Js::invoke($this->networkEvents, 'queueRedirectInfo', [Js::get($event, 'requestId'), Js::object(['event' => $event, 'fetchRequestId' => $fetchRequestId])]);
                    return UndefinedValue::Value;
                }
            }
            $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
            if (Js::truthy($request)) {
                $this->NetworkManager_handleRequestRedirect($client, $request, Js::get($event, 'redirectResponse'), $redirectResponseExtraInfo);
                $redirectChain = Js::get($request, '_redirectChain');
                $extraInfo = Js::invoke(Js::invoke($this->networkEvents, 'requestExtraInfo', [Js::get($event, 'requestId')]), 'shift', []);
                if (Js::truthy($extraInfo)) {
                    Js::invoke($request, 'updateHeaders', [Js::get($extraInfo, 'headers')]);
                }
            }
        }
        $frame = (Js::truthy(Js::get($event, 'frameId')) ? Js::invoke($this->frameProvider, 'frame', [Js::get($event, 'frameId')]) : null);
        $request = new \Nesk\Puphpeteer\Native\HTTPRequest($client, $frame, $fetchRequestId, $this->NetworkManager_userRequestInterceptionEnabled, $event, $redirectChain);
        $extraInfo = Js::invoke(Js::invoke($this->networkEvents, 'requestExtraInfo', [Js::get($event, 'requestId')]), 'shift', []);
        if (Js::truthy($extraInfo)) {
            Js::invoke($request, 'updateHeaders', [Js::get($extraInfo, 'headers')]);
        }
        Js::set($request, '_fromMemoryCache', $fromMemoryCache);
        Js::invoke($this->networkEvents, 'storeRequest', [Js::get($event, 'requestId'), $request]);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'Request'), $request);
        Js::discard(Js::invoke($request, 'finalizeInterceptions', []));
        return UndefinedValue::Value;
    }

    private function NetworkManager_onRequestWillBeSentExtraInfo(mixed $_client, mixed $event): mixed
    {
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        if (Js::truthy($request)) {
            Js::invoke($request, 'updateHeaders', [Js::get($event, 'headers')]);
        } else {
            Js::invoke(Js::invoke($this->networkEvents, 'requestExtraInfo', [Js::get($event, 'requestId')]), 'push', [$event]);
        }
        return UndefinedValue::Value;
    }

    private function NetworkManager_onRequestServedFromCache(mixed $client, mixed $event): mixed
    {
        $requestWillBeSentEvent = Js::invoke($this->networkEvents, 'getRequestWillBeSent', [Js::get($event, 'requestId')]);
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        if (Js::truthy($request)) {
            Js::set($request, '_fromMemoryCache', true);
        }
        if (Js::truthy(Js::logicalAnd(!Js::truthy($request), fn () => $requestWillBeSentEvent))) {
            $this->createRequest($client, $requestWillBeSentEvent, UndefinedValue::Value, true);
            $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        }
        if (Js::truthy(!Js::truthy($request))) {
            Js::debugError(new \RuntimeException(('Request ' . Js::string(Js::get($event, 'requestId')) . ' was served from cache but we could not find the corresponding request object')));
            return UndefinedValue::Value;
        }
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'RequestServedFromCache'), $request);
        return UndefinedValue::Value;
    }

    private function NetworkManager_handleRequestRedirect(mixed $_client, mixed $request, mixed $responsePayload, mixed $extraInfo): mixed
    {
        $response = new \Nesk\Puphpeteer\Native\HTTPResponse($request, $responsePayload, $extraInfo);
        Js::set($request, '_response', $response);
        Js::invoke(Js::get($request, '_redirectChain'), 'push', [$request]);
        Js::invoke($response, '_resolveBody', [new \RuntimeException('Response body is unavailable for redirect responses')]);
        $this->NetworkManager_forgetRequest($request, false);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'Response'), $response);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'RequestFinished'), $request);
        return UndefinedValue::Value;
    }

    private function NetworkManager_emitResponseEvent(mixed $_client, mixed $responseReceived, mixed $extraInfo): mixed
    {
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($responseReceived, 'requestId')]);
        if (Js::truthy(!Js::truthy($request))) {
            return UndefinedValue::Value;
        }
        $extraInfos = Js::invoke($this->networkEvents, 'responseExtraInfo', [Js::get($responseReceived, 'requestId')]);
        if (Js::truthy(Js::get($extraInfos, 'length'))) {
            Js::debugError(new \RuntimeException(Js::add('Unexpected extraInfo events for request ', Js::get($responseReceived, 'requestId'))));
        }
        if (Js::truthy(Js::get(Js::get($responseReceived, 'response'), 'fromDiskCache'))) {
            $extraInfo = null;
        }
        $response = new \Nesk\Puphpeteer\Native\HTTPResponse($request, Js::get($responseReceived, 'response'), $extraInfo);
        Js::set($request, '_response', $response);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'Response'), $response);
        return UndefinedValue::Value;
    }

    private function NetworkManager_onResponseReceived(mixed $client, mixed $event): mixed
    {
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        $extraInfo = null;
        if (Js::truthy(Js::logicalAnd(Js::logicalAnd($request, fn () => !Js::truthy(Js::get($request, '_fromMemoryCache'))), fn () => Js::get($event, 'hasExtraInfo')))) {
            $extraInfo = Js::invoke(Js::invoke($this->networkEvents, 'responseExtraInfo', [Js::get($event, 'requestId')]), 'shift', []);
            if (Js::truthy(!Js::truthy($extraInfo))) {
                Js::invoke($this->networkEvents, 'queueEventGroup', [Js::get($event, 'requestId'), Js::object(['responseReceivedEvent' => $event])]);
                return UndefinedValue::Value;
            }
        }
        $this->NetworkManager_emitResponseEvent($client, $event, $extraInfo);
        return UndefinedValue::Value;
    }

    private function NetworkManager_onResponseReceivedExtraInfo(mixed $client, mixed $event): mixed
    {
        $redirectInfo = Js::invoke($this->networkEvents, 'takeQueuedRedirectInfo', [Js::get($event, 'requestId')]);
        if (Js::truthy($redirectInfo)) {
            Js::invoke(Js::invoke($this->networkEvents, 'responseExtraInfo', [Js::get($event, 'requestId')]), 'push', [$event]);
            $this->createRequest($client, Js::get($redirectInfo, 'event'), Js::get($redirectInfo, 'fetchRequestId'));
            return UndefinedValue::Value;
        }
        $queuedEvents = Js::invoke($this->networkEvents, 'getQueuedEventGroup', [Js::get($event, 'requestId')]);
        if (Js::truthy($queuedEvents)) {
            Js::invoke($this->networkEvents, 'forgetQueuedEventGroup', [Js::get($event, 'requestId')]);
            $this->NetworkManager_emitResponseEvent($client, Js::get($queuedEvents, 'responseReceivedEvent'), $event);
            if (Js::truthy(Js::get($queuedEvents, 'loadingFinishedEvent'))) {
                $this->NetworkManager_emitLoadingFinished($client, Js::get($queuedEvents, 'loadingFinishedEvent'));
            }
            if (Js::truthy(Js::get($queuedEvents, 'loadingFailedEvent'))) {
                $this->NetworkManager_emitLoadingFailed($client, Js::get($queuedEvents, 'loadingFailedEvent'));
            }
            return UndefinedValue::Value;
        }
        Js::invoke(Js::invoke($this->networkEvents, 'responseExtraInfo', [Js::get($event, 'requestId')]), 'push', [$event]);
        return UndefinedValue::Value;
    }

    protected function NetworkManager_forgetRequest(mixed $request, mixed $events): mixed
    {
        $requestId = Js::get($request, 'id');
        $interceptionId = Js::get($request, '_interceptionId');
        Js::invoke($this->networkEvents, 'forgetRequest', [$requestId]);
        if (Js::truthy(!Js::strictEqual($interceptionId, UndefinedValue::Value))) {
            Js::invoke($this->NetworkManager_attemptedAuthentications, 'delete', [$interceptionId]);
        }
        if (Js::truthy($events)) {
            Js::invoke($this->networkEvents, 'forget', [$requestId]);
        }
        return UndefinedValue::Value;
    }

    private function NetworkManager_onLoadingFinished(mixed $client, mixed $event): mixed
    {
        $queuedEvents = Js::invoke($this->networkEvents, 'getQueuedEventGroup', [Js::get($event, 'requestId')]);
        if (Js::truthy($queuedEvents)) {
            Js::set($queuedEvents, 'loadingFinishedEvent', $event);
        } else {
            $this->NetworkManager_emitLoadingFinished($client, $event);
        }
        return UndefinedValue::Value;
    }

    private function NetworkManager_emitLoadingFinished(mixed $client, mixed $event): mixed
    {
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        if (Js::truthy(!Js::truthy($request))) {
            return UndefinedValue::Value;
        }
        $this->NetworkManager_adoptCdpSessionIfNeeded($client, $request);
        if (Js::truthy(Js::invoke($request, 'response', []))) {
            Js::optionalInvoke(Js::invoke($request, 'response', []), '_resolveBody', fn () => []);
        }
        $this->NetworkManager_forgetRequest($request, true);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'RequestFinished'), $request);
        return UndefinedValue::Value;
    }

    private function NetworkManager_onLoadingFailed(mixed $client, mixed $event): mixed
    {
        $queuedEvents = Js::invoke($this->networkEvents, 'getQueuedEventGroup', [Js::get($event, 'requestId')]);
        if (Js::truthy($queuedEvents)) {
            Js::set($queuedEvents, 'loadingFailedEvent', $event);
        } else {
            $this->NetworkManager_emitLoadingFailed($client, $event);
        }
        return UndefinedValue::Value;
    }

    private function NetworkManager_emitLoadingFailed(mixed $client, mixed $event): mixed
    {
        $request = Js::invoke($this->networkEvents, 'getRequest', [Js::get($event, 'requestId')]);
        if (Js::truthy(!Js::truthy($request))) {
            return UndefinedValue::Value;
        }
        $this->NetworkManager_adoptCdpSessionIfNeeded($client, $request);
        Js::set($request, '_failureText', Js::get($event, 'errorText'));
        $response = Js::invoke($request, 'response', []);
        if (Js::truthy($response)) {
            Js::invoke($response, '_resolveBody', []);
        }
        $this->NetworkManager_forgetRequest($request, true);
        $this->emit(Js::get(Js::object(['Request' => 'request', 'Response' => 'response', 'RequestFinished' => 'requestfinished', 'RequestFailed' => 'requestfailed', 'RequestServedFromCache' => 'requestservedfromcache']), 'RequestFailed'), $request);
        return UndefinedValue::Value;
    }

    private function NetworkManager_adoptCdpSessionIfNeeded(mixed $client, mixed $request): mixed
    {
        if (Js::truthy(!Js::strictEqual($client, Js::get($request, 'client')))) {
            Js::set($request, 'client', $client);
        }
        return UndefinedValue::Value;
    }
}
