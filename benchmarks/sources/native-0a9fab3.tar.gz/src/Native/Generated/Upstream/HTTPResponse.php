<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/HTTPResponse.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

abstract class HTTPResponse implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{

    public function __construct()
    {
    }

    abstract public function remoteAddress(): mixed;

    abstract public function url(): mixed;

    public function ok(): mixed
    {
        $status = $this->status();
        return Js::logicalOr(Js::strictEqual($status, 0), fn () => (Js::logicalAnd(Js::numeric('>=', $status, 200), fn () => Js::numeric('<=', $status, 299))));
    }

    abstract public function status(): mixed;

    abstract public function statusText(): mixed;

    abstract public function headers(): mixed;

    abstract public function securityDetails(): mixed;

    abstract public function timing(): mixed;

    abstract public function content(): mixed;

    public function buffer(): mixed
    {
        return Js::async(function () {
            $content = Js::await($this->content());
            return \Nesk\Puphpeteer\Native\Runtime\NodeBuffer::from($content);
        });
    }

    public function text(): mixed
    {
        return Js::async(function () {
            $content = Js::await($this->content());
            return Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\TextDecoder('utf-8', Js::object(['fatal' => true])), 'decode', [$content]);
        });
    }

    public function json(): mixed
    {
        return Js::async(function () {
            $content = Js::await($this->text());
            return Js::parseJson($content);
        });
    }

    abstract public function request(): mixed;

    abstract public function fromCache(): mixed;

    abstract public function fromServiceWorker(): mixed;

    abstract public function frame(): mixed;

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
