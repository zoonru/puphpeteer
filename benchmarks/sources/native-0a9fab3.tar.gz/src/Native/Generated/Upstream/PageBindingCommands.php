<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
trait PageBindingCommands
{
    public function dispatchExposedBinding(mixed $world, mixed $event): mixed
    {
        return Js::async(function () use ($world, $event) {
            $payload = UndefinedValue::Value;
            try {
                $payload = Js::parseJsonValue(Js::get($event, 'payload'));
            } catch (\Throwable) {
                return UndefinedValue::Value;
            }
            $_nativeBinding1 = $payload;
            $type = Js::get($_nativeBinding1, 'type');
            $name = Js::get($_nativeBinding1, 'name');
            $seq = Js::get($_nativeBinding1, 'seq');
            $args = Js::get($_nativeBinding1, 'args');
            $isTrivial = Js::get($_nativeBinding1, 'isTrivial');
            if (Js::truthy(!Js::strictEqual($type, 'exposedFun'))) {
                return UndefinedValue::Value;
            }
            $context = Js::get($world, 'context');
            if (Js::truthy(!Js::truthy($context))) {
                return UndefinedValue::Value;
            }
            $binding = Js::invoke($this->bindings, 'get', [$name]);
            Js::await(Js::optionalInvoke($binding, 'run', fn () => [$context, $seq, $args, $isTrivial]));
            return UndefinedValue::Value;
        });
    }
}
