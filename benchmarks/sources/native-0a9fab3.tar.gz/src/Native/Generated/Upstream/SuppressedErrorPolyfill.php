<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/disposable.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class SuppressedErrorPolyfill extends \Nesk\Puphpeteer\Native\Runtime\JsError
{
    private mixed $SuppressedErrorPolyfill_error;
    private mixed $SuppressedErrorPolyfill_suppressed;

    public function __construct(mixed $error, mixed $suppressed, mixed $message = 'An error was suppressed during disposal')
    {
        parent::__construct($message);
        $this->SuppressedErrorPolyfill_error = UndefinedValue::Value;
        $this->SuppressedErrorPolyfill_suppressed = UndefinedValue::Value;
        $this->name = 'SuppressedError';
        $this->SuppressedErrorPolyfill_error = $error;
        $this->SuppressedErrorPolyfill_suppressed = $suppressed;
    }

    public function error(): mixed
    {
        return $this->SuppressedErrorPolyfill_error;
    }

    public function suppressed(): mixed
    {
        return $this->SuppressedErrorPolyfill_suppressed;
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            'error' => $this->error(),
            'suppressed' => $this->suppressed(),
            default => parent::getJsProperty($name),
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: return parent::setJsProperty($name, $value);
        }
    }
}
