<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait FrameContentCommands
{
    public function setContent(mixed $html, mixed $options = UndefinedValue::Value): mixed
    {
        $this->assertAttached();
        return Js::async(function () use ($html, $options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            $_nativeBinding1 = $options;
            $waitUntil = Js::defaultValue(Js::get($_nativeBinding1, 'waitUntil'), fn () => ['load']);
            $timeout = Js::defaultValue(Js::get($_nativeBinding1, 'timeout'), fn () => Js::invoke(Js::get($this->manager, 'timeoutSettings'), 'navigationTimeout', []));
            Js::await($this->setFrameContent($html));
            $watcher = new \Nesk\Puphpeteer\Native\LifecycleWatcher(Js::get($this->manager, 'networkManager'), $this, $waitUntil, $timeout);
            $error = Js::await(Deferred::race([Js::invoke($watcher, 'terminationPromise', []), Js::invoke($watcher, 'lifecyclePromise', [])]));
            Js::invoke($watcher, 'dispose', []);
            if (Js::truthy($error)) {
                throw $error;
            }
            return UndefinedValue::Value;
        });
    }
}
