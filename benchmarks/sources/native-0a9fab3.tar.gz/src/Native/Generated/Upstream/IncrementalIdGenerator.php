<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: util/incremental-id-generator.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class IncrementalIdGenerator
{
    public static function createIncrementalIdGenerator(): mixed
    {
        $id = 0;
        return function () use (&$id) {
    if (Js::truthy(Js::strictEqual($id, Js::get(Js::object(['MAX_SAFE_INTEGER' => 9007199254740991]), 'MAX_SAFE_INTEGER')))) {
        $id = 0;
    }
    return ++$id;
};
    }
}
