<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/NetworkEventManager.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

// All state operations; diagnostic printState remains pending.
namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class NetworkEventStore
{
    private mixed $NetworkEventManager_requestWillBeSentMap;
    private mixed $NetworkEventManager_requestPausedMap;
    private mixed $NetworkEventManager_httpRequestsMap;
    private mixed $NetworkEventManager_requestWillBeSentExtraInfoMap;
    private mixed $NetworkEventManager_responseReceivedExtraInfoMap;
    private mixed $NetworkEventManager_queuedRedirectInfoMap;
    private mixed $NetworkEventManager_queuedEventGroupMap;

    public function forget(mixed $networkRequestId): mixed
    {
        Js::invoke($this->NetworkEventManager_requestWillBeSentMap, 'delete', [$networkRequestId]);
        Js::invoke($this->NetworkEventManager_requestPausedMap, 'delete', [$networkRequestId]);
        Js::invoke($this->NetworkEventManager_requestWillBeSentExtraInfoMap, 'delete', [$networkRequestId]);
        Js::invoke($this->NetworkEventManager_queuedEventGroupMap, 'delete', [$networkRequestId]);
        Js::invoke($this->NetworkEventManager_queuedRedirectInfoMap, 'delete', [$networkRequestId]);
        Js::invoke($this->NetworkEventManager_responseReceivedExtraInfoMap, 'delete', [$networkRequestId]);
        return UndefinedValue::Value;
    }

    public function requestExtraInfo(mixed $networkRequestId): mixed
    {
        if (Js::truthy(!Js::truthy(Js::invoke($this->NetworkEventManager_requestWillBeSentExtraInfoMap, 'has', [$networkRequestId])))) {
            Js::invoke($this->NetworkEventManager_requestWillBeSentExtraInfoMap, 'set', [$networkRequestId, new \Nesk\Puphpeteer\Native\Runtime\JsArray([])]);
        }
        return (Js::invoke($this->NetworkEventManager_requestWillBeSentExtraInfoMap, 'get', [$networkRequestId]));
    }

    public function responseExtraInfo(mixed $networkRequestId): mixed
    {
        if (Js::truthy(!Js::truthy(Js::invoke($this->NetworkEventManager_responseReceivedExtraInfoMap, 'has', [$networkRequestId])))) {
            Js::invoke($this->NetworkEventManager_responseReceivedExtraInfoMap, 'set', [$networkRequestId, new \Nesk\Puphpeteer\Native\Runtime\JsArray([])]);
        }
        return (Js::invoke($this->NetworkEventManager_responseReceivedExtraInfoMap, 'get', [$networkRequestId]));
    }

    private function queuedRedirectInfo(mixed $fetchRequestId): mixed
    {
        if (Js::truthy(!Js::truthy(Js::invoke($this->NetworkEventManager_queuedRedirectInfoMap, 'has', [$fetchRequestId])))) {
            Js::invoke($this->NetworkEventManager_queuedRedirectInfoMap, 'set', [$fetchRequestId, new \Nesk\Puphpeteer\Native\Runtime\JsArray([])]);
        }
        return (Js::invoke($this->NetworkEventManager_queuedRedirectInfoMap, 'get', [$fetchRequestId]));
    }

    public function queueRedirectInfo(mixed $fetchRequestId, mixed $redirectInfo): mixed
    {
        Js::invoke($this->queuedRedirectInfo($fetchRequestId), 'push', [$redirectInfo]);
        return UndefinedValue::Value;
    }

    public function takeQueuedRedirectInfo(mixed $fetchRequestId): mixed
    {
        return Js::invoke($this->queuedRedirectInfo($fetchRequestId), 'shift', []);
    }

    public function inFlightRequestsCount(): mixed
    {
        $inFlightRequestCounter = 0;
        foreach (Js::iterate(Js::invoke($this->NetworkEventManager_httpRequestsMap, 'values', [])) as $request) {
            if (Js::truthy(!Js::truthy(Js::invoke($request, 'response', [])))) {
                $inFlightRequestCounter++;
            }
        }
        return $inFlightRequestCounter;
    }

    public function storeRequestWillBeSent(mixed $networkRequestId, mixed $event): mixed
    {
        Js::invoke($this->NetworkEventManager_requestWillBeSentMap, 'set', [$networkRequestId, $event]);
        return UndefinedValue::Value;
    }

    public function getRequestWillBeSent(mixed $networkRequestId): mixed
    {
        return Js::invoke($this->NetworkEventManager_requestWillBeSentMap, 'get', [$networkRequestId]);
    }

    public function forgetRequestWillBeSent(mixed $networkRequestId): mixed
    {
        Js::invoke($this->NetworkEventManager_requestWillBeSentMap, 'delete', [$networkRequestId]);
        return UndefinedValue::Value;
    }

    public function getRequestPaused(mixed $networkRequestId): mixed
    {
        return Js::invoke($this->NetworkEventManager_requestPausedMap, 'get', [$networkRequestId]);
    }

    public function forgetRequestPaused(mixed $networkRequestId): mixed
    {
        Js::invoke($this->NetworkEventManager_requestPausedMap, 'delete', [$networkRequestId]);
        return UndefinedValue::Value;
    }

    public function storeRequestPaused(mixed $networkRequestId, mixed $event): mixed
    {
        Js::invoke($this->NetworkEventManager_requestPausedMap, 'set', [$networkRequestId, $event]);
        return UndefinedValue::Value;
    }

    public function getRequest(mixed $networkRequestId): mixed
    {
        return Js::invoke($this->NetworkEventManager_httpRequestsMap, 'get', [$networkRequestId]);
    }

    public function storeRequest(mixed $networkRequestId, mixed $request): mixed
    {
        Js::invoke($this->NetworkEventManager_httpRequestsMap, 'set', [$networkRequestId, $request]);
        return UndefinedValue::Value;
    }

    public function forgetRequest(mixed $networkRequestId): mixed
    {
        Js::invoke($this->NetworkEventManager_httpRequestsMap, 'delete', [$networkRequestId]);
        return UndefinedValue::Value;
    }

    public function getQueuedEventGroup(mixed $networkRequestId): mixed
    {
        return Js::invoke($this->NetworkEventManager_queuedEventGroupMap, 'get', [$networkRequestId]);
    }

    public function queueEventGroup(mixed $networkRequestId, mixed $event): mixed
    {
        Js::invoke($this->NetworkEventManager_queuedEventGroupMap, 'set', [$networkRequestId, $event]);
        return UndefinedValue::Value;
    }

    public function forgetQueuedEventGroup(mixed $networkRequestId): mixed
    {
        Js::invoke($this->NetworkEventManager_queuedEventGroupMap, 'delete', [$networkRequestId]);
        return UndefinedValue::Value;
    }

    public function __construct()
    {
        $this->NetworkEventManager_requestWillBeSentMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_requestPausedMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_httpRequestsMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_requestWillBeSentExtraInfoMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_responseReceivedExtraInfoMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_queuedRedirectInfoMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
        $this->NetworkEventManager_queuedEventGroupMap = new \Nesk\Puphpeteer\Native\Runtime\StringMap();
    }
}
