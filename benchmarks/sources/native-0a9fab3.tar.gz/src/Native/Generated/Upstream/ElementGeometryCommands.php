<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/ElementHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait ElementGeometryCommands
{
    public static function intersectBoundingBox(mixed $box, mixed $width, mixed $height): mixed
    {
        Js::set($box, 'width', Js::max((Js::truthy(Js::numeric('>=', Js::get($box, 'x'), 0)) ? Js::min(Js::numeric('-', $width, Js::get($box, 'x')), Js::get($box, 'width')) : Js::min($width, Js::add(Js::get($box, 'width'), Js::get($box, 'x')))), 0));
        Js::set($box, 'height', Js::max((Js::truthy(Js::numeric('>=', Js::get($box, 'y'), 0)) ? Js::min(Js::numeric('-', $height, Js::get($box, 'y')), Js::get($box, 'height')) : Js::min($height, Js::add(Js::get($box, 'height'), Js::get($box, 'y')))), 0));
        Js::set($box, 'x', Js::max(Js::get($box, 'x'), 0));
        Js::set($box, 'y', Js::max(Js::get($box, 'y'), 0));
        return UndefinedValue::Value;
    }

    public function clickablePoint(mixed $offset = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($offset) {
            $box = Js::await($this->ElementHandle_clickableBox());
            if (Js::truthy(!Js::truthy($box))) {
                throw new \RuntimeException('Node is either not clickable or not an Element');
            }
            if (Js::truthy(!Js::strictEqual($offset, UndefinedValue::Value))) {
                return Js::object(['x' => Js::add(Js::get($box, 'x'), Js::get($offset, 'x')), 'y' => Js::add(Js::get($box, 'y'), Js::get($offset, 'y'))]);
            }
            return Js::object(['x' => Js::add(Js::get($box, 'x'), Js::numeric('/', Js::get($box, 'width'), 2)), 'y' => Js::add(Js::get($box, 'y'), Js::numeric('/', Js::get($box, 'height'), 2))]);
        });
    }

    public function hover(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            Js::await($this->scrollIntoViewIfNeeded());
            $_nativeBinding1 = Js::await($this->clickablePoint());
            $x = Js::get($_nativeBinding1, 'x');
            $y = Js::get($_nativeBinding1, 'y');
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'mouse'), 'move', [$x, $y]));
            return UndefinedValue::Value;
        });
    }

    public function click(mixed $options = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            Js::await($this->scrollIntoViewIfNeeded());
            $_nativeBinding2 = Js::await($this->clickablePoint(Js::get($options, 'offset')));
            $x = Js::get($_nativeBinding2, 'x');
            $y = Js::get($_nativeBinding2, 'y');
            try {
                Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'mouse'), 'click', [$x, $y, $options]));
            } finally {
                if (Js::truthy(Js::get($options, 'debugHighlight'))) {
                    Js::await(Js::browserResult(Js::invoke(Js::invoke($this->frame(), 'page', []), 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('(x, y) => {
    const highlight = document.createElement(\'div\');
    highlight.innerHTML = `<style>
        @scope {
          :scope {
              position: fixed;
              left: ${x}px;
              top: ${y}px;
              width: 10px;
              height: 10px;
              border-radius: 50%;
              animation: colorChange 10s 1 normal;
              animation-fill-mode: forwards;
          }

          @keyframes colorChange {
              from {
                  background-color: red;
              }
              to {
                  background-color: #FADADD00;
              }
          }
        }
      </style>`;
    highlight.addEventListener(\'animationend\', () => {
        highlight.remove();
    }, { once: true });
    document.body.append(highlight);
}'), $x, $y])));
                }
            }
            return UndefinedValue::Value;
        });
    }

    public function tap(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            Js::await($this->scrollIntoViewIfNeeded());
            $_nativeBinding3 = Js::await($this->clickablePoint());
            $x = Js::get($_nativeBinding3, 'x');
            $y = Js::get($_nativeBinding3, 'y');
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'touchscreen'), 'tap', [$x, $y]));
            return UndefinedValue::Value;
        });
    }

    public function touchStart(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            Js::await($this->scrollIntoViewIfNeeded());
            $_nativeBinding4 = Js::await($this->clickablePoint());
            $x = Js::get($_nativeBinding4, 'x');
            $y = Js::get($_nativeBinding4, 'y');
            return Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'touchscreen'), 'touchStart', [$x, $y]));
        });
    }

    public function touchMove(mixed $touch = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($touch) {
            Js::await($this->scrollIntoViewIfNeeded());
            $_nativeBinding5 = Js::await($this->clickablePoint());
            $x = Js::get($_nativeBinding5, 'x');
            $y = Js::get($_nativeBinding5, 'y');
            if (Js::truthy($touch)) {
                return Js::await(Js::invoke($touch, 'move', [$x, $y]));
            }
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'touchscreen'), 'touchMove', [$x, $y]));
            return UndefinedValue::Value;
        });
    }

    public function touchEnd(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            Js::await($this->scrollIntoViewIfNeeded());
            Js::await(Js::invoke(Js::get(Js::invoke($this->frame(), 'page', []), 'touchscreen'), 'touchEnd', []));
            return UndefinedValue::Value;
        });
    }

    private function ElementHandle_clickableBox(): mixed
    {
        return Js::async(function () {
            $boxes = Js::await(Js::browserResult($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    if (!(element instanceof Element)) {
        return null;
    }
    return [...element.getClientRects()].map(rect => {
        return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
    });
}'))));
            if (Js::truthy(!Js::truthy(Js::optionalGet($boxes, 'length')))) {
                return null;
            }
            Js::await($this->ElementHandle_intersectBoundingBoxesWithFrame($boxes));
            $frame = $this->frame();
            $parentFrame = UndefinedValue::Value;
            while (Js::truthy(($parentFrame = Js::optionalInvoke($frame, 'parentFrame', fn () => [])))) {
                $handle = Js::await(Js::invoke($frame, 'frameElement', []));
                try {
                    if (Js::truthy(!Js::truthy($handle))) {
                        throw new \RuntimeException('Unsupported frame type');
                    }
                    $parentBox = Js::await(Js::browserResult(Js::invoke($handle, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('element => {
    // Element is not visible.
    if (element.getClientRects().length === 0) {
        return null;
    }
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return {
        left: rect.left +
            parseInt(style.paddingLeft, 10) +
            parseInt(style.borderLeftWidth, 10),
        top: rect.top +
            parseInt(style.paddingTop, 10) +
            parseInt(style.borderTopWidth, 10),
    };
}')])));
                    if (Js::truthy(!Js::truthy($parentBox))) {
                        return null;
                    }
                    foreach (Js::iterate($boxes) as $box) {
                        Js::set($box, 'x', Js::add(Js::get($box, 'x'), Js::get($parentBox, 'left')));
                        Js::set($box, 'y', Js::add(Js::get($box, 'y'), Js::get($parentBox, 'top')));
                    }
                    Js::await(($handle)->ElementHandle_intersectBoundingBoxesWithFrame($boxes));
                    $frame = $parentFrame;
                } finally {
                    Js::disposeHandle($handle);
                }
            }
            $box = Js::invoke($boxes, 'find', [function (mixed $box) {
    return Js::logicalAnd(Js::numeric('>=', Js::get($box, 'width'), 1), fn () => Js::numeric('>=', Js::get($box, 'height'), 1));
}]);
            if (Js::truthy(!Js::truthy($box))) {
                return null;
            }
            return Js::object(['x' => Js::get($box, 'x'), 'y' => Js::get($box, 'y'), 'height' => Js::get($box, 'height'), 'width' => Js::get($box, 'width')]);
        });
    }

    private function ElementHandle_intersectBoundingBoxesWithFrame(mixed $boxes): mixed
    {
        return Js::async(function () use ($boxes) {
            $_nativeBinding6 = Js::await(Js::browserResult(Js::invoke(Js::invoke($this->frame(), 'isolatedRealm', []), 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('() => {
    return {
        documentWidth: document.documentElement.clientWidth,
        documentHeight: document.documentElement.clientHeight,
    };
}')])));
            $documentWidth = Js::get($_nativeBinding6, 'documentWidth');
            $documentHeight = Js::get($_nativeBinding6, 'documentHeight');
            foreach (Js::iterate($boxes) as $box) {
                self::intersectBoundingBox($box, $documentWidth, $documentHeight);
            }
            return UndefinedValue::Value;
        });
    }

    public function boundingBox(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            $box = Js::await(Js::browserResult($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    if (!(element instanceof Element)) {
        return null;
    }
    // Element is not visible.
    if (element.getClientRects().length === 0) {
        return null;
    }
    const rect = element.getBoundingClientRect();
    return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
}'))));
            if (Js::truthy(!Js::truthy($box))) {
                return null;
            }
            $offset = Js::await($this->ElementHandle_getTopLeftCornerOfFrame());
            if (Js::truthy(!Js::truthy($offset))) {
                return null;
            }
            return Js::object(['x' => Js::add(Js::get($box, 'x'), Js::get($offset, 'x')), 'y' => Js::add(Js::get($box, 'y'), Js::get($offset, 'y')), 'height' => Js::get($box, 'height'), 'width' => Js::get($box, 'width')]);
        });
    }

    public function boxModel(): mixed
    {
        return $this->invokeIsolatedVoid(function () {
            $model = Js::await(Js::browserResult($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    if (!(element instanceof Element)) {
        return null;
    }
    // Element is not visible.
    if (element.getClientRects().length === 0) {
        return null;
    }
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    const offsets = {
        padding: {
            left: parseInt(style.paddingLeft, 10),
            top: parseInt(style.paddingTop, 10),
            right: parseInt(style.paddingRight, 10),
            bottom: parseInt(style.paddingBottom, 10),
        },
        margin: {
            left: -parseInt(style.marginLeft, 10),
            top: -parseInt(style.marginTop, 10),
            right: -parseInt(style.marginRight, 10),
            bottom: -parseInt(style.marginBottom, 10),
        },
        border: {
            left: parseInt(style.borderLeft, 10),
            top: parseInt(style.borderTop, 10),
            right: parseInt(style.borderRight, 10),
            bottom: parseInt(style.borderBottom, 10),
        },
    };
    const border = [
        { x: rect.left, y: rect.top },
        { x: rect.left + rect.width, y: rect.top },
        { x: rect.left + rect.width, y: rect.top + rect.height },
        { x: rect.left, y: rect.top + rect.height },
    ];
    const padding = transformQuadWithOffsets(border, offsets.border);
    const content = transformQuadWithOffsets(padding, offsets.padding);
    const margin = transformQuadWithOffsets(border, offsets.margin);
    return {
        content,
        padding,
        border,
        margin,
        width: rect.width,
        height: rect.height,
    };
    function transformQuadWithOffsets(quad, offsets) {
        return [
            {
                x: quad[0].x + offsets.left,
                y: quad[0].y + offsets.top,
            },
            {
                x: quad[1].x - offsets.right,
                y: quad[1].y + offsets.top,
            },
            {
                x: quad[2].x - offsets.right,
                y: quad[2].y - offsets.bottom,
            },
            {
                x: quad[3].x + offsets.left,
                y: quad[3].y - offsets.bottom,
            },
        ];
    }
}'))));
            if (Js::truthy(!Js::truthy($model))) {
                return null;
            }
            $offset = Js::await($this->ElementHandle_getTopLeftCornerOfFrame());
            if (Js::truthy(!Js::truthy($offset))) {
                return null;
            }
            foreach (Js::iterate((new \Nesk\Puphpeteer\Native\Runtime\JsArray(['content', 'padding', 'border', 'margin']))) as $attribute) {
                foreach (Js::iterate(Js::get($model, $attribute)) as $point) {
                    Js::set($point, 'x', Js::add(Js::get($point, 'x'), Js::get($offset, 'x')));
                    Js::set($point, 'y', Js::add(Js::get($point, 'y'), Js::get($offset, 'y')));
                }
            }
            return $model;
        });
    }

    private function ElementHandle_getTopLeftCornerOfFrame(): mixed
    {
        return Js::async(function () {
            $point = Js::object(['x' => 0, 'y' => 0]);
            $frame = $this->frame();
            $parentFrame = UndefinedValue::Value;
            while (Js::truthy(($parentFrame = Js::optionalInvoke($frame, 'parentFrame', fn () => [])))) {
                $handle = Js::await(Js::invoke($frame, 'frameElement', []));
                try {
                    if (Js::truthy(!Js::truthy($handle))) {
                        throw new \RuntimeException('Unsupported frame type');
                    }
                    $parentBox = Js::await(Js::browserResult(Js::invoke($handle, 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('element => {
    // Element is not visible.
    if (element.getClientRects().length === 0) {
        return null;
    }
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return {
        left: rect.left +
            parseInt(style.paddingLeft, 10) +
            parseInt(style.borderLeftWidth, 10),
        top: rect.top +
            parseInt(style.paddingTop, 10) +
            parseInt(style.borderTopWidth, 10),
    };
}')])));
                    if (Js::truthy(!Js::truthy($parentBox))) {
                        return null;
                    }
                    Js::set($point, 'x', Js::add(Js::get($point, 'x'), Js::get($parentBox, 'left')));
                    Js::set($point, 'y', Js::add(Js::get($point, 'y'), Js::get($parentBox, 'top')));
                    $frame = $parentFrame;
                } finally {
                    Js::disposeHandle($handle);
                }
            }
            return $point;
        });
    }

    protected function assertConnectedElement(): mixed
    {
        return Js::async(function () {
            $error = Js::await(Js::browserResult($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('async (element) => {
    if (!element.isConnected) {
        return \'Node is detached from document\';
    }
    if (element.nodeType !== Node.ELEMENT_NODE) {
        return \'Node is not of type HTMLElement\';
    }
    return;
}'))));
            if (Js::truthy($error)) {
                throw new \RuntimeException($error);
            }
            return UndefinedValue::Value;
        });
    }

    protected function scrollIntoViewIfNeeded(): mixed
    {
        return Js::async(function () {
            if (Js::truthy(Js::await($this->isIntersectingViewport(Js::object(['threshold' => 1]))))) {
                return UndefinedValue::Value;
            }
            Js::await($this->scrollIntoView());
            return UndefinedValue::Value;
        });
    }

    public function isIntersectingViewport(mixed $options = UndefinedValue::Value): mixed
    {
        return $this->invokeIsolatedVoid(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            Js::await($this->assertConnectedElement());
            $handle = Js::await($this->ElementHandle_asSVGElementHandle());
            $target = Js::logicalAnd($handle, fn () => (Js::await(($handle)->ElementHandle_getOwnerSVGElement())));
            try {
                return Js::await(Js::browserResult(Js::invoke((((Js::coalesce($target, fn () => $this)))), 'evaluate', [new \Nesk\Puphpeteer\Native\JsFunction('async (element, threshold) => {
    const visibleRatio = await new Promise(resolve => {
        const observer = new IntersectionObserver(entries => {
            resolve(entries[0].intersectionRatio);
            observer.disconnect();
        });
        observer.observe(element);
    });
    return threshold === 1 ? visibleRatio === 1 : visibleRatio > threshold;
}'), Js::coalesce(Js::get($options, 'threshold'), fn () => 0)])));
            } finally {
                Js::disposeHandle($target);
            }
        });
    }

    private function ElementHandle_asSVGElementHandle(): mixed
    {
        return Js::async(function () {
            if (Js::truthy(Js::await(Js::browserResult($this->evaluate(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    return element instanceof SVGElement;
}')))))) {
                return ($this);
            } else {
                return null;
            }
        });
    }

    private function ElementHandle_getOwnerSVGElement(): mixed
    {
        return Js::async(function () {
            return Js::await($this->evaluateHandle(new \Nesk\Puphpeteer\Native\JsFunction('element => {
    if (element instanceof SVGSVGElement) {
        return element;
    }
    return element.ownerSVGElement;
}')));
        });
    }
}
