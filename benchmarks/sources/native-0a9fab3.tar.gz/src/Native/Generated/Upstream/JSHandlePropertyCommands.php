<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/JSHandle.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait JSHandlePropertyCommands
{

    public function getProperty(mixed $propertyName): mixed
    {
        HandleErrors::assertActive($this);
        return Js::async(function () use ($propertyName) {
            return Js::await($this->evaluateHandle(new \Nesk\Puphpeteer\Native\JsFunction('(object, propertyName) => {
    return object[propertyName];
}'), $propertyName));
        });
    }
}
