<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: api/Frame.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class FrameErrors
{
    public static function detached(mixed $frame): mixed
    {
        return Js::call(function (mixed $frame) {
    return ('Attempted to use detached Frame \'' . Js::string(Js::get($frame, '_id')) . '\'.');
}, [$frame]);
    }
}
