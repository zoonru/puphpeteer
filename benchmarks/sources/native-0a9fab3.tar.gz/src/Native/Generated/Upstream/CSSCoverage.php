<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Coverage.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class CSSCoverage implements \Nesk\Puphpeteer\Native\Runtime\MutableJsObject
{
    private mixed $CSSCoverage_client;
    private mixed $CSSCoverage_enabled;
    private mixed $CSSCoverage_stylesheetURLs;
    private mixed $CSSCoverage_stylesheetSources;
    private mixed $CSSCoverage_eventListeners;
    private mixed $CSSCoverage_resetOnNavigation;

    public function __construct(mixed $client)
    {
        $this->CSSCoverage_client = UndefinedValue::Value;
        $this->CSSCoverage_enabled = false;
        $this->CSSCoverage_stylesheetURLs = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        $this->CSSCoverage_stylesheetSources = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
        $this->CSSCoverage_eventListeners = UndefinedValue::Value;
        $this->CSSCoverage_resetOnNavigation = false;
        $this->CSSCoverage_client = $client;
    }

    public function updateClient(mixed $client): mixed
    {
        $this->CSSCoverage_client = $client;
        return UndefinedValue::Value;
    }

    public function start(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            if ($options === UndefinedValue::Value) { $options = Js::object([]); }
            Js::assert(!Js::truthy($this->CSSCoverage_enabled), 'CSSCoverage is already enabled');
            $_nativeBinding1 = $options;
            $resetOnNavigation = Js::defaultValue(Js::get($_nativeBinding1, 'resetOnNavigation'), fn () => true);
            $this->CSSCoverage_resetOnNavigation = $resetOnNavigation;
            $this->CSSCoverage_enabled = true;
            Js::invoke($this->CSSCoverage_stylesheetURLs, 'clear', []);
            Js::invoke($this->CSSCoverage_stylesheetSources, 'clear', []);
            $this->CSSCoverage_eventListeners = new DisposableStackPolyfill();
            $clientEmitter = Js::invoke($this->CSSCoverage_eventListeners, 'use', [new \Nesk\Puphpeteer\Native\Runtime\TransportEventEmitter($this->CSSCoverage_client)]);
            Js::invoke($clientEmitter, 'on', ['CSS.styleSheetAdded', $this->CSSCoverage_onStyleSheet(...)]);
            Js::invoke($clientEmitter, 'on', ['Runtime.executionContextsCleared', $this->CSSCoverage_onExecutionContextsCleared(...)]);
            Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($this->CSSCoverage_client, 'send', ['DOM.enable']), Js::invoke($this->CSSCoverage_client, 'send', ['CSS.enable']), Js::invoke($this->CSSCoverage_client, 'send', ['CSS.startRuleUsageTracking'])])));
            return UndefinedValue::Value;
        });
    }

    private function CSSCoverage_onExecutionContextsCleared(): mixed
    {
        if (Js::truthy(!Js::truthy($this->CSSCoverage_resetOnNavigation))) {
            return UndefinedValue::Value;
        }
        Js::invoke($this->CSSCoverage_stylesheetURLs, 'clear', []);
        Js::invoke($this->CSSCoverage_stylesheetSources, 'clear', []);
        return UndefinedValue::Value;
    }

    private function CSSCoverage_onStyleSheet(mixed $event): mixed
    {
        return Js::async(function () use ($event) {
            $header = Js::get($event, 'header');
            if (Js::truthy(!Js::truthy(Js::get($header, 'sourceURL')))) {
                return UndefinedValue::Value;
            }
            try {
                $response = Js::await(Js::invoke($this->CSSCoverage_client, 'send', ['CSS.getStyleSheetText', Js::object(['styleSheetId' => Js::get($header, 'styleSheetId')])]));
                Js::invoke($this->CSSCoverage_stylesheetURLs, 'set', [Js::get($header, 'styleSheetId'), Js::get($header, 'sourceURL')]);
                Js::invoke($this->CSSCoverage_stylesheetSources, 'set', [Js::get($header, 'styleSheetId'), Js::get($response, 'text')]);
            } catch (\Throwable $error) {
                Js::debugError($error);
            }
            return UndefinedValue::Value;
        });
    }

    public function stop(): mixed
    {
        return Js::async(function () {
            Js::assert($this->CSSCoverage_enabled, 'CSSCoverage is not enabled');
            $this->CSSCoverage_enabled = false;
            $ruleTrackingResponse = Js::await(Js::invoke($this->CSSCoverage_client, 'send', ['CSS.stopRuleUsageTracking']));
            Js::await(Js::all(new \Nesk\Puphpeteer\Native\Runtime\JsArray([Js::invoke($this->CSSCoverage_client, 'send', ['CSS.disable']), Js::invoke($this->CSSCoverage_client, 'send', ['DOM.disable'])])));
            Js::optionalInvoke($this->CSSCoverage_eventListeners, 'dispose', fn () => []);
            $styleSheetIdToCoverage = new \Nesk\Puphpeteer\Native\Runtime\JsMap();
            foreach (Js::iterate(Js::get($ruleTrackingResponse, 'ruleUsage')) as $entry) {
                $ranges = Js::invoke($styleSheetIdToCoverage, 'get', [Js::get($entry, 'styleSheetId')]);
                if (Js::truthy(!Js::truthy($ranges))) {
                    $ranges = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
                    Js::invoke($styleSheetIdToCoverage, 'set', [Js::get($entry, 'styleSheetId'), $ranges]);
                }
                Js::invoke($ranges, 'push', [Js::object(['startOffset' => Js::get($entry, 'startOffset'), 'endOffset' => Js::get($entry, 'endOffset'), 'count' => (Js::truthy(Js::get($entry, 'used')) ? 1 : 0)])]);
            }
            $coverage = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
            foreach (Js::iterate(Js::invoke($this->CSSCoverage_stylesheetURLs, 'keys', [])) as $styleSheetId) {
                $url = Js::invoke($this->CSSCoverage_stylesheetURLs, 'get', [$styleSheetId]);
                Js::assert(!Js::strictEqual(Js::typeOf($url), 'undefined'), ('Stylesheet URL is undefined (styleSheetId=' . Js::string($styleSheetId) . ')'));
                $text = Js::invoke($this->CSSCoverage_stylesheetSources, 'get', [$styleSheetId]);
                Js::assert(!Js::strictEqual(Js::typeOf($text), 'undefined'), ('Stylesheet text is undefined (styleSheetId=' . Js::string($styleSheetId) . ')'));
                $ranges = CoverageHelpers::convertToDisjointRanges(Js::logicalOr(Js::invoke($styleSheetIdToCoverage, 'get', [$styleSheetId]), fn () => new \Nesk\Puphpeteer\Native\Runtime\JsArray([])));
                Js::invoke($coverage, 'push', [Js::object(['url' => $url, 'ranges' => $ranges, 'text' => $text])]);
            }
            return $coverage;
        });
    }

    public function getJsProperty(string $name): mixed
    {
        return match ($name) {
            default => UndefinedValue::Value,
        };
    }

    public function setJsProperty(string $name, mixed $value): mixed
    {
        switch ($name) {
            default: throw new \TypeError('Unsupported property write: ' . $name);
        }
    }

    public function __get(string $name): mixed { return $this->getJsProperty($name); }
    public function __set(string $name, mixed $value): void { $this->setJsProperty($name, $value); }
}
