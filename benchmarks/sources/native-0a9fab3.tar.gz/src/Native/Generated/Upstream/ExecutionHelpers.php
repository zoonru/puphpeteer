<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/ExecutionContext.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;
use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
final class ExecutionHelpers
{
    public static function convertArgument(mixed $context, mixed $arg): mixed
    {
        if (Js::truthy(Js::strictEqual(Js::typeOf($arg), 'bigint'))) {
            return Js::object(['unserializableValue' => ('' . Js::string(Js::invoke($arg, 'toString', [])) . 'n')]);
        }
        if (Js::truthy(Js::objectIs($arg, (-0.0)))) {
            return Js::object(['unserializableValue' => '-0']);
        }
        if (Js::truthy(Js::objectIs($arg, INF))) {
            return Js::object(['unserializableValue' => 'Infinity']);
        }
        if (Js::truthy(Js::objectIs($arg, (-INF)))) {
            return Js::object(['unserializableValue' => '-Infinity']);
        }
        if (Js::truthy(Js::objectIs($arg, NAN))) {
            return Js::object(['unserializableValue' => 'NaN']);
        }
        $objectHandle = (Js::truthy(Js::logicalAnd($arg, fn () => (Js::logicalOr(($arg instanceof \Nesk\Puphpeteer\Native\JSHandle), fn () => ($arg instanceof \Nesk\Puphpeteer\Native\ElementHandle))))) ? $arg : null);
        if (Js::truthy($objectHandle)) {
            if (Js::truthy(!Js::strictEqual(Js::get($objectHandle, 'realm'), ($context)->sourceWorld()))) {
                throw new \Nesk\Puphpeteer\Native\Runtime\JsError('JSHandles can be evaluated only in the context they were created!');
            }
            if (Js::truthy(Js::get($objectHandle, 'disposed'))) {
                throw new \Nesk\Puphpeteer\Native\Runtime\JsError('JSHandle is disposed!');
            }
            if (Js::truthy(Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'unserializableValue'))) {
                return Js::object(['unserializableValue' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'unserializableValue')]);
            }
            if (Js::truthy(!Js::truthy(Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'objectId')))) {
                return Js::object(['value' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'value')]);
            }
            return Js::object(['objectId' => Js::get(Js::invoke($objectHandle, 'remoteObject', []), 'objectId')]);
        }
        return Js::object(['value' => $arg]);
    }

    public static function rewriteError(mixed $error): mixed
    {
        return (function (mixed $error) {
    if (Js::truthy(Js::invoke(Js::get($error, 'message'), 'includes', ['Object reference chain is too long']))) {
        return Js::object(['result' => Js::object(['type' => 'undefined'])]);
    }
    if (Js::truthy(Js::invoke(Js::get($error, 'message'), 'includes', ['Object couldn\'t be returned by value']))) {
        return Js::object(['result' => Js::object(['type' => 'undefined'])]);
    }
    if (Js::truthy(Js::logicalOr(Js::invoke(Js::get($error, 'message'), 'endsWith', ['Cannot find context with specified id']), fn () => Js::invoke(Js::get($error, 'message'), 'endsWith', ['Inspected target navigated or closed'])))) {
        throw new \Nesk\Puphpeteer\Native\Runtime\JsError('Execution context was destroyed, most likely because of a navigation.');
    }
    throw $error;
})($error);
    }
}
