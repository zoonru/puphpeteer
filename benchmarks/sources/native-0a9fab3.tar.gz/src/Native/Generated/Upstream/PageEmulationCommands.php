<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/Page.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

trait PageEmulationCommands
{

    public function isJavaScriptEnabled(): mixed
    {
        return Js::get($this->emulationManager, 'javascriptEnabled');
    }

    public function setJavaScriptEnabled(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            return Js::await(Js::invoke($this->emulationManager, 'setJavaScriptEnabled', [$enabled]));
        });
    }

    public function setGeolocation(mixed $options): mixed
    {
        return Js::async(function () use ($options) {
            return Js::await(Js::invoke($this->emulationManager, 'setGeolocation', [$options]));
        });
    }

    public function emulateFocusedPage(mixed $enabled): mixed
    {
        return Js::async(function () use ($enabled) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateFocus', [$enabled]));
        });
    }

    public function emulateMediaType(mixed $type = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($type) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateMediaType', [$type]));
        });
    }

    public function emulateCPUThrottling(mixed $factor): mixed
    {
        return Js::async(function () use ($factor) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateCPUThrottling', [$factor]));
        });
    }

    public function emulateMediaFeatures(mixed $features = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($features) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateMediaFeatures', [$features]));
        });
    }

    public function emulateTimezone(mixed $timezoneId = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($timezoneId) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateTimezone', [$timezoneId]));
        });
    }

    public function emulateIdleState(mixed $overrides = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($overrides) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateIdleState', [$overrides]));
        });
    }

    public function emulateVisionDeficiency(mixed $type = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($type) {
            return Js::await(Js::invoke($this->emulationManager, 'emulateVisionDeficiency', [$type]));
        });
    }

    public function setViewport(mixed $viewport): mixed
    {
        return Js::async(function () use ($viewport) {
            $needsReload = Js::await(Js::invoke($this->emulationManager, 'emulateViewport', [$viewport]));
            $this->viewportValue = $viewport;
            if (Js::truthy($needsReload)) {
                Js::await($this->reload());
            }
            return UndefinedValue::Value;
        });
    }

    public function viewport(): mixed
    {
        return $this->viewportValue;
    }

    public function reload(mixed $options = UndefinedValue::Value): mixed
    {
        return Js::async(function () use ($options) {
            $_nativeBinding1 = Js::await(Js::all([$this->waitForNavigation(Js::assign(Js::object([]), $options, Js::object(['ignoreSameDocumentNavigation' => true]))), Js::invoke($this->session, 'send', ['Page.reload', Js::object(['ignoreCache' => Js::coalesce(Js::optionalGet($options, 'ignoreCache'), fn () => false)])])]));
            $result = Js::get($_nativeBinding1, 0);
            return $result;
        });
    }
}
