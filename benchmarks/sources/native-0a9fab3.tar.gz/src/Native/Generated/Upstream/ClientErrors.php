<?php

declare(strict_types=1);

/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
// Generated from puppeteer-core 24.36.1: cdp/utils.ts. Do not edit.
// Derived file; see LICENSE-PUPPETEER (Puppeteer) or LICENSE-CDP (protocol schemas).

namespace Nesk\Puphpeteer\Native\Generated\Upstream;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

final class ClientErrors
{
    public static function getErrorDetails(mixed $details): mixed
    {
        return (function (mixed $details) {
    $name = '';
    $message = UndefinedValue::Value;
    $lines = Js::coalesce(Js::optionalInvoke(Js::optionalGet(Js::get($details, 'exception'), 'description'), 'split', fn () => ['
    at ']), fn () => new \Nesk\Puphpeteer\Native\Runtime\JsArray([]));
    $size = Js::min(Js::coalesce(Js::optionalMap(Js::get($details, 'stackTrace'), fn ($_nativeOptional1) => Js::get(Js::get($_nativeOptional1, 'callFrames'), 'length')), fn () => 0), Js::numeric('-', Js::get($lines, 'length'), 1));
    Js::invoke($lines, 'splice', [(-$size), $size]);
    if (Js::truthy(Js::optionalGet(Js::get($details, 'exception'), 'className'))) {
        $name = Js::get(Js::get($details, 'exception'), 'className');
    }
    $message = Js::invoke($lines, 'join', ['
']);
    if (Js::truthy(Js::logicalAnd($name, fn () => Js::invoke($message, 'startsWith', [('' . Js::string($name) . ': ')])))) {
        $message = Js::invoke($message, 'slice', [Js::add(Js::get($name, 'length'), 2)]);
    }
    return Js::object(['message' => $message, 'name' => $name]);
})($details);
    }
    public static function createClientError(mixed $details): mixed
    {
        $name = UndefinedValue::Value;
        $message = UndefinedValue::Value;
        if (Js::truthy(!Js::truthy(Js::get($details, 'exception')))) {
            $name = 'Error';
            $message = Js::get($details, 'text');
        } else {
            if (Js::truthy(Js::logicalAnd((Js::logicalOr(!Js::strictEqual(Js::get(Js::get($details, 'exception'), 'type'), 'object'), fn () => !Js::strictEqual(Js::get(Js::get($details, 'exception'), 'subtype'), 'error'))), fn () => !Js::truthy(Js::get(Js::get($details, 'exception'), 'objectId'))))) {
                return \Nesk\Puphpeteer\Native\JSHandle::value(Js::get($details, 'exception'));
            } else {
                $detail = self::getErrorDetails($details);
                $name = Js::get($detail, 'name');
                $message = Js::get($detail, 'message');
            }
        }
        $error = new \Nesk\Puphpeteer\Native\Runtime\BrowserError($message);
        Js::set($error, 'name', $name);
        $messageHeight = Js::get(Js::invoke(Js::get($error, 'message'), 'split', ['
']), 'length');
        $messageLines = Js::invoke(Js::invoke((Js::get($error, 'stack')), 'split', ['
']), 'splice', [0, $messageHeight]);
        $stackLines = new \Nesk\Puphpeteer\Native\Runtime\JsArray([]);
        if (Js::truthy(Js::get($details, 'stackTrace'))) {
            foreach (Js::iterate(Js::get(Js::get($details, 'stackTrace'), 'callFrames')) as $frame) {
                Js::invoke($stackLines, 'push', [('    at ' . Js::string(Js::logicalOr(Js::get($frame, 'functionName'), fn () => '<anonymous>')) . ' (' . Js::string(Js::get($frame, 'url')) . ':' . Js::string(Js::add(Js::get($frame, 'lineNumber'), 1)) . ':' . Js::string(Js::add(Js::get($frame, 'columnNumber'), 1)) . ')')]);
                if (Js::truthy(Js::numeric('>=', Js::get($stackLines, 'length'), Js::get(Js::object(['stackTraceLimit'=>\Nesk\Puphpeteer\Native\Runtime\BrowserError::$stackTraceLimit]), 'stackTraceLimit')))) {
                    break;
                }
            }
        }
        Js::set($error, 'stack', Js::invoke(new \Nesk\Puphpeteer\Native\Runtime\JsArray([...Js::iterate($messageLines), ...Js::iterate($stackLines)]), 'join', ['
']));
        return $error;
    }
}
