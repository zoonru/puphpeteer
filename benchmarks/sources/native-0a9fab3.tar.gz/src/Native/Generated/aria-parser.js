/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
(() => {
    const assert = (value, message) => {
        if (!value) {
            throw new Error(message);
        }
    };
    const isKnownAttribute = (attribute) => {
        return ['name', 'role'].includes(attribute);
    };
    const ATTRIBUTE_REGEXP = /\[\s*(?<attribute>\w+)\s*=\s*(?<quote>"|')(?<value>\\.|.*?(?=\k<quote>))\k<quote>\s*\]/g;
    const parseARIASelector = (selector) => {
        if (selector.length > 10_000) {
            throw new Error(`Selector ${selector} is too long`);
        }
        const queryOptions = {};
        const defaultName = selector.replace(ATTRIBUTE_REGEXP, (_, attribute, __, value) => {
            assert(isKnownAttribute(attribute), `Unknown aria attribute "${attribute}" in selector`);
            queryOptions[attribute] = value;
            return '';
        });
        if (defaultName && !queryOptions.name) {
            queryOptions.name = defaultName;
        }
        return queryOptions;
    };
    return parseARIASelector;
})()
