<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** Transport and state storage for the source-generated CdpMouse implementation. */
final class Mouse
{
    use Generated\Upstream\MouseCommands;

    private \stdClass $mouseState;
    private Runtime\JsArray $transactions;

    public function __construct(private Session $client, private Keyboard $keyboard)
    {
        $this->initializeMouseState();
    }
}
