<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

final class ProtocolException extends ProtocolError
{
    public function __construct(public readonly string $method, public readonly array $error)
    {
        parent::__construct(Generated\Upstream\ProtocolMessages::format($method, $error));
        $this->setJsProperty('code', (int) ($error['code'] ?? 0));
        $this->setJsProperty('originalMessage', $error['message'] ?? '');
    }
}
