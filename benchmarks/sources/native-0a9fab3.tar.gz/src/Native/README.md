# Нативный Puppeteer PHP: перенос исходников в работе

Цель — полноценный PHP-клиент Puppeteer с асинхронностью Amp, обновляемый по
версии в корневом `package.json`, без Node.js/Python в runtime клиента.
**Текущая реализация ещё не достигает полной совместимости и не готова к такому релизу.**
Существующий `Nesk\Puphpeteer\Puppeteer` пока остаётся Rialto/Node.js-клиентом.
Новая реализация развивается в `Nesk\Puphpeteer\Native` до завершения миграции.

## Обновление исходников

```sh
# 1. Изменить dependencies.puppeteer в package.json на точную версию.
# 2. Обновить PHP по этой версии:
composer update-php
# 3. Проверить воспроизводимость и выполнить тесты:
composer verify-php
composer test-native
composer test-php-generator
composer test-native-browser
# 4. Проверка возможности релиза полного клиента:
composer verify-php-release
```

Последняя команда сейчас намеренно завершается ошибкой: высокоуровневый API
перенесён не полностью. Успешный `update-php` означает успешную генерацию
реализованной части, а не обещание полной поддержки Puppeteer.

`update-php` устанавливает точную версию Puppeteer и TypeScript 5.9.3 в
`.build/native-upstream`. npm lifecycle scripts отключены: браузеры не скачиваются.
Затем AST-компилятор читает настоящие `.ts` из `puppeteer-core/src`, включая тела
методов, и схемы CDP той же поставки. Браузерный injected bundle извлекается из
JavaScript-модуля с помощью AST без исполнения модуля на этапе извлечения.

Сборка проходит во временном каталоге. Перед установкой проверяются PHP-синтаксис
и весь unit-набор tests/Native с загрузкой сгенерированных классов именно
из staging-каталога. Рабочие артефакты
заменяются только после успеха, с резервной копией на время rename и восстановлением
при ошибке замены. Одновременные updater-процессы исключены файловой блокировкой.
`verify-php` повторяет генерацию и сравнивает каждый файл, включая лишние файлы.

Для разработки без скачивания можно использовать `composer update-php -- --offline`
или `composer verify-php -- --offline`: версия в корневом `node_modules` обязана
совпадать с `package.json`. `test-php-generator` использует совпадающую версию из `.build/native-upstream/node_modules`
или корневого `node_modules`.

Node.js и npm нужны сборщику, PHP-клиент их не использует. Legacy composer hook
`post-install-cmd: npm install` пока сохранён для старого Rialto-клиента; он должен
быть удалён при окончательной смене публичной точки входа перед native-релизом.

## Что генерируется сейчас

- EventEmitter целиком из common/EventEmitter.ts и его bundled mitt из JavaScript
  пакета Puppeteer. PageEventCommands переводит специальные on/off для request.
  Symbol.dispose сопоставлен с внутренним disposeEmitter; замыкания и callback
  dispatch имеют явную PHP/Fiber границу.
- `PageNetworkIdleCommands`: цепочка учёта активных запросов из Page-конструктора,
  waitForNetworkIdle/waitForNetworkIdle$, waitForRequest, waitForResponse и
  waitForFrame из TS. ObservableUtilities компилирует fromEmitterEvent, timeout
  и filterAsync; операторы RxJS обслуживает PHP runtime на Revolt.
- `PageNavigationCommands`: goBack/goForward и внутренний #go из CdpPage.
  `FrameNavigationCommands`: полные тела goto и waitForNavigation из CdpFrame,
  включая вложенный async navigate, выбор Deferred, обработку ошибок и finally.
  `FrameNavigationHelpers` компилирует referrerPolicyToProtocol.
- Полный класс `Deferred` из util/Deferred.ts: resolve/reject, timeout, race,
  сохранение одного promise и очистка таймеров. Promise и timers имеют PHP/Amp
  границу; состояние Deferred и async arrow functions генерируются из TS.
- DisposableStackPolyfill, AsyncDisposableStackPolyfill и SuppressedErrorPolyfill
  целиком из util/disposable.ts. PHP использует поставляемые Puppeteer polyfill-классы:
  собственного ECMAScript DisposableStack в PHP нет. Ручной SubscriptionStack удалён;
  подписки NetworkManager и LifecycleWatcher освобождает сгенерированный стек.
- `LifecycleCommands`: все методы и инициализаторы полей LifecycleWatcher.ts,
  включая раздельное завершение lifecycle и навигации, ответы, detach и dispose.
  Конструктор и подключение событий остаются PHP-адаптером. Устаревший поиск
  ответа по loader ID в FrameManager/NetworkManager удалён.
- `FrameLifecycleCommands`: исходные обработчики init, loadingStarted/loadingStopped.
  `FrameContentCommands`, `FrameDocumentCommands`, `FrameDocumentWriter` и
  `PageDocumentCommands`: setContent/content и браузерные функции записи/сериализации
  документа. FrameErrors компилирует исходную функцию сообщения об удалённом frame.
- `FrameTagCommands` и `PageTagCommands`: addScriptTag/addStyleTag из полных
  исходных тел, включая callbacks внутри браузера. `RealmTransferCommands`
  компилирует transferHandle из IsolatedWorld; CDP-адаптер принимает backendNodeId.
- Исполняемые PHP-классы `TimeoutSettings`, `SecurityDetails`, `ConsoleMessage`,
  `Dialog` и `CdpDialog` из тел TS-методов и конструкторов.
- Trait `PageCommands` для методов, чьи тела являются прямым CDP-вызовом.
- `JSHandleCommands` из тел методов TS-реализации; браузерные функции ElementHandle.
- `Binding` целиком из cdp/Binding.ts: поля, constructor/getters и run;
  ErrorLikeHelpers переводит isErrorLike, а JSHandleDisposalCommands — оба
  исходных dispose symbol methods.
- `ScriptInjector` целиком из common/ScriptInjector.ts: состояние amendments,
  append/pop, inject и сборка скрипта. `ExecutionUtilityCommands` переводит getter
  puppeteerUtil и #addBindingWithoutThrowing; Native ExecutionContext вызывает их
  вместо ручной сборки injected wrapper.
- `ExecutionEvaluator`: полное тело ExecutionContext.#evaluate вместе с вложенными
  функциями, LazyArg/Promise.all, сериализацией, sourceURL и обработкой результата.
  LazyArg и вспомогательные FunctionHelpers/ExecutionHelpers генерируются из TS;
  жизненный цикл ExecutionContext ещё обслуживается PHP-адаптером.
- Классы API/CDP HTTPRequest и HTTPResponse целиком: конструкторы, поля,
  методы и аксессоры. Native-обёртки только преобразуют возвращаемые headers,
  remoteAddress и redirectChain в PHP-массивы; encoding и JSON имеют явные PHP-границы.
- `KeyboardCommands`: все девять методов CdpKeyboard из Input.ts и полная таблица
  USKeyboardLayout; `ElementInputCommands`: тела type/press из ElementHandle.ts.
  Для двух ElementHandle-методов используется явный PHP-адаптер
  throwIfDisposed + bindIsolatedHandle с проверкой сигнатуры и decorators.
- `MouseCommands`: все методы/аксессоры CdpMouse, исходные инициализаторы состояния,
  helper-функции и button flags из Input.ts; PageDragCommands включает
  setDragInterception/isDragInterceptionEnabled.
- Классы Touchscreen, CdpTouchscreen и CdpTouchHandle целиком из API/CDP Input.ts,
  включая конструкторы и инициализацию полей. Stateful ID generator переводится
  из incremental-id-generator.ts; записываемая переменная замыкания определяется
  по AST и сохраняется по ссылке.
- ElementGeometryCommands: исходные clickablePoint/boundingBox/boxModel,
  пересечение прямоугольников с viewport каждого frame, обход родителей,
  scrollIntoViewIfNeeded/isIntersectingViewport и click/hover/tap/touch actions.
  PageActionCommands и FrameActionCommands переводят click/hover/tap/type/focus
  по селектору, включая using/disposal временного handle.
- EmulatedState и EmulationManager целиком из EmulationManager.ts: состояние,
  список CDP-клиентов, синхронизация и все методы эмуляции. PageEmulationCommands
  содержит исходные делегаторы, setViewport/viewport и reload.
  WeakMap-декоратор invokeAtMostOnceForArguments имеет проверяемый PHP-адаптер:
  изменение исходника декоратора останавливает генерацию до повторного аудита.
- NetworkManager целиком из cdp/NetworkManager.ts: все поля и конструктор,
  add/removeClient, настройки сети, authentication, перехват и корреляция событий.
  Прежние traits NetworkSettings/NetworkEventCommands удалены. PageNetworkCommands
  содержит делегаторы и service worker bypass; BrowserVersionCommands —
  version/userAgent и исходный getVersion. Предикат TargetCloseError тоже переводится.
  NetworkEventStore содержит исходные операции NetworkEventManager;
  диагностический printState ещё не переведён.
- Сгенерированные HTTPRequest/CdpHTTPRequest включают continue/respond/abort,
  приоритеты, очередь и finalizeInterceptions. RequestHelpers переводит
  headersArray/handleError; таблицы status/error codes берутся из исходника.
  Создание request/response выполняют исходные обработчики NetworkManager;
  PHP-адаптер подключает их к Session и освобождает ожидания при закрытии владельца.
- Frame getters и рекурсивная функция `checkLifecycle` из LifecycleWatcher.ts,
  включая исходную таблицу `waitUntil`. Генератор поддерживает for-of и lazy &&.
- Парсер Puppeteer-specific селекторов, включая parsel-js, и исходные обработчики
  CSS/XPath/text/pierce/P selectors. Они выполняются в браузере и хешируются в manifest.
- 644 CDP-команды и константы для 217 событий для исходников Puppeteer 24.36.1.
  Это низкоуровневый протокол; он не равнозначен полной поддержке Puppeteer.
- Браузерный bundle `injected.js` с оригинальными poller/query utilities Puppeteer.
- `manifest.json`: версии, SHA-256 исходников, компилятора и артефактов.
- `api-coverage.json`: полный обход методов/аксессоров классов в `puppeteer-core/src`,
  включая abstract/private/internal. Для текущей версии учтено 1613 членов,
  413 имеют статус `translated`. Эти числа не являются процентом готовности
  публичного API. Ручные runtime-адаптеры отдельно не объявлены транспилированными.

Текущий компилятор поддерживает ограниченное и проверяемое подмножество AST.
Неизвестные операторы, выражения, statements и свободные идентификаторы не получают
приблизительную реализацию. Ошибка в выбранном для полного переноса классе
останавливает сборку; неподходящие методы Page остаются `pending` в инвентаризации.
Сгенерированные async-методы возвращают `Amp\Future`, синхронные возвращают значения.
Async-функция начинает выполняться сразу до первого await через PHP Fiber.
Promise.all сохраняет порядок результатов и отклоняется при первой ошибке,
не отменяя другие операции. Массивы состояния Mouse сохраняют identity через JsArray.
Полная эквивалентность JS Promise scheduling ещё не реализована и не заявляется.

## Runtime и пример

Runtime использует один reader WebSocket, таблицу request ID → Future, маршрутизацию
по session ID и сериализацию записи кадров. Обработчики событий запускаются в
отдельных fibers, поэтому обработчик `dialog` может отправить CDP-команду, пока
`evaluate` ждёт результат prompt. Отмена PHP-запроса снимает его ожидание;
она не откатывает уже отправленное действие в браузере. Поздние ответы отбрасываются.

```php
use Nesk\Puphpeteer\Native\Puppeteer;
use function Amp\async;
use function Amp\Future\await;

$browser = (new Puppeteer)->connect([
    'browserWSEndpoint' => getenv('BROWSERLESS_WS'),
])->await();
$context = $browser->createBrowserContext()->await();
try {
    $tasks = [];
    foreach (['https://example.com', 'https://example.org'] as $url) {
        $tasks[] = async(function () use ($context, $url) {
            $page = $context->newPage()->await();
            try {
                $page->goto($url)->await();
                return $page->title()->await();
            } finally {
                $page->close()->await();
            }
        });
    }
    $titles = await($tasks);
} finally {
    try { $context->close()->await(); }
    finally { $browser->disconnect(); }
}
```

`Browser::close()` отправляет реальный `Browser.close`; для отключения от общего
browserless используйте `disconnect()`, для освобождения своего context — его `close()`.
Пользовательские ошибки обработчиков браузерных событий извлекаются через
`throwListenerError()`, сохраняя работу CDP-reader. Прямой пользовательский emit
сохраняет синхронные исключения; отложенные ошибки callbacks наблюдаются отдельно.

## Проверки

`GeneratedTest.php` проверяет JS truthiness/null/undefined, defaults, наследование,
ветвления, сериализацию и async-методы из исходных TS-классов.
`test-generator.cjs` меняет константу в копии исходников и подтверждает изменение
поведения полученного PHP. Отдельная мутация тела callback в Binding.ts проверяет
поведение извлечённой браузерной обёртки. Мутация modifierBit в Input.ts меняет
modifiers в реальном результате сгенерированного PHP-метода. Изменение default steps
в Mouse.move меняет количество и координаты отправленных команд. Для Touchscreen
изменяются радиус точки, предел счётчика ID и имя его переменной: исполняемый PHP
повторяет новое поведение, включая переход счётчика через предел. Неподдерживаемый statement не создаёт
частичного output.

Docker-интеграция запускает только PHP у клиента, без Node/Python в PATH, с
отключёнными функциями запуска процессов. Проверяет настоящие browserless CDP,
сгенерированные команды/диалоги/ConsoleMessage, конкурентные ответы, отмену и
поздний ответ, upstream browser pollers, JSHandle, скриншот и очистку context.
Отчёт — `.build/native-artifacts/integration.json`.
Отдельный контейнер запускает оригинальный Puppeteer из `.build/native-upstream`
на том же browserless. `oracle.cjs` и `conformance.php` выполняют одинаковые
сценарии, а `compare.php` сравнивает результаты с сохранением null/undefined,
BigInt и -0. Результаты — `oracle.json` и `conformance.json` в том же каталоге.
`NetworkManagerTest` проверяет перестановки extra-info, идентичность запросов
при редиректе и отклонение незавершённого чтения тела при закрытии target. Browserless сам содержит Node.js
как часть сервера. Тестовый HTTP fixture не является транспортом автоматизации.

## Оставшаяся работа до полноценного релиза

1. Полная модель API и наследования: сопоставление публичных деклараций с CDP/BiDi
   реализациями, properties, overloads, aliases, DTO и enum вместо нынешних mixed/array.
2. Расширение компилятора: closures, destructuring, остальные loops, collections, imports,
   decorators, disposal, module initialization, async generators, Promise races.
3. Runtime-совместимость JS и зависимостей: identity, undefined, event ordering,
   Promise semantics, AbortSignal, RxJS, ошибки, timers и освобождение ресурсов.
4. Полный Browser/BrowserContext/Target/Frame/Realm/JSHandle/ElementHandle lifecycle,
   полная модель frame/target lifecycle, BFCache, prerender activation и workers.
   FrameManager уже отслеживает вложенные iframe, настоящие OOPIF и смену renderer,
   сохраняет Frame identity и раздельные execution contexts для CDP-сессий.
   `goto` возвращает HTTPResponse, учитывает редиректы, same-document и about:blank;
   поддерживает load/domcontentloaded/networkidle0/networkidle2 и массив waitUntil.
   `waitForNavigation` подписывается до действия, вызывающего навигацию. `evaluate` принимает JsFunction и аргументы,
   JSHandle, BigInt, undefined и особые number values. waitForFunction переживает
   навигацию, принимает аргументы и Amp Cancellation через option `signal`;
   отмена останавливает браузерный poller. Handles и DOM API ещё неполные.
5. Locators/selectors/actionability/Input, полная network event model/cookies/proxy,
   downloads/uploads, PDF/screenshot options, tracing/coverage/accessibility,
   workers/dialogs/console bindings и остальные публичные возможности версии.
6. Node-specific API адаптировать на PHP: local launch, browser discovery/install,
   process/pipe/filesystem и recording. Firefox/BiDi требует отдельного транспорта
   и переноса соответствующей реализации. Это не исключено из цели.
7. Расширить дифференциальные сценарии с оригинальным Puppeteer выбранной версии
   до всех public API. Сейчас 383 браузерных наблюдения сравнивают значения, handles,
   изоляцию DOM, селекторы, ожидание через навигацию, HTTPResponse, редиректы,
   iframe/OOPIF, смену renderer, navigation/lifecycle API, waitForSelector, ARIA
   и exposeFunction, события клавиатуры, ввод в OOPIF и конкурентное выполнение
   во время задержки ввода; движения, клики, прокрутку, drag-and-drop и
   восстановление Mouse после отказа CDP, события Touchscreen и нескольких
   touch handles, ошибки повторного start/end, геометрию и действия над элементами
   в основной странице, вложенных iframe и OOPIF; viewport, reload и emulation;
   HTTP headers, User-Agent, cache, offline/throttling, service worker bypass
   и HTTP Basic authentication, включая параллельные requests и OOPIF;
   подмену запросов/ответов, abort, cooperative interception, EventEmitter, waitForNetworkIdle и ожидания
   request/response/frame с асинхронными PHP-предикатами и историю страницы.
   Ещё 60 сравнений вызывают непосредственно оригинальные классы HTTP request/response,
   полный NetworkManager и polyfill-стеки освобождения ресурсов и соответствующий
   сгенерированный PHP на общих входных данных, без запросов к браузеру.
   Расширить CI и
   release gate по доказанному покрытию; одного синтаксиса или количества методов мало.
8. После полного покрытия — сменить публичную точку входа, удалить Rialto/npm runtime
   зависимости и старый install hook, обновить документацию и проверить чистую
   Composer-установку без Node/npm. Только затем готовить полноценный релиз.

## Пример функций и handles

```php
use Nesk\Puphpeteer\Native\JsFunction;

$answer = $page->evaluate(new JsFunction('(a, b) => a + b'), 17, 25)->await();
$input = $page->querySelector('#name')->await();
try {
    $input->focus()->await();
    $id = $page->evaluate(new JsFunction('element => element.id'), $input)->await();
} finally {
    $input->dispose()->await();
}
```

PHP-имена `querySelector`/`querySelectorAll` соответствуют Puppeteer `$`/`$$`;
`JsFunction` заменяет функцию JavaScript, `BigInt` хранит decimal string,
`Runtime\UndefinedValue::Value` сохраняет отличие undefined от null.
ARIA-селекторы используют PHP bindings и Accessibility.queryAXTree.
Полная модель actionability у locators остаётся в плане миграции. Для emulation
ещё требуется подключение к полному жизненному циклу prerender/activation и
перенос defaultViewport из Browser.connect/launch options.

## Frame и навигация

```php
$iframeElement = $page->querySelector('iframe')->await();
$frame = $iframeElement->contentFrame()->await();
$response = $frame->goto('https://example.com', [
    'waitUntil' => ['domcontentloaded', 'networkidle2'],
])->await();

$navigation = $page->waitForNavigation(['timeout' => 5000]);
$page->evaluate('location.href = "/next"')->await();
$response = $navigation->await();
```

`frames-oracle.cjs` и `frames.php` сравнивают 18 наблюдений на fixture с
`--site-per-process`; тест отдельно требует, чтобы cross-site iframe использовал
другую CDP-сессию. Проверяются parent/child relationships, frameElement/contentFrame,
контексты и focus внутри OOPIF, HTTPResponse.frame, сохранение идентичности после
смены renderer, удаление вложенных Frame, networkidle и waitForNavigation.
Отчёты: `.build/native-artifacts/frames-oracle.json` и `frames-native.json`.
Прямой `Frame.goto()` при OOPIF → same-process переходе в проверенной версии
оригинального Puppeteer может завершиться `Target closed`; тест смены renderer
использует изменение `iframe.src` и ожидает фактическую загрузку документа.

## Ожидание селекторов

`Page`, `Frame` и `ElementHandle` поддерживают `waitForSelector(selector, options)`.
Браузерные функции ожидания и получения первого результата извлекаются из
`common/QueryHandler.ts`; проверка видимости использует оригинальный injected bundle.
CSS/XPath/text/pierce/P selectors выбирают исходный polling режим, visible/hidden
используют RAF, а scoped MutationPoller наблюдает сам root ElementHandle.

```php
$element = $page->waitForSelector('#ready', [
    'visible' => true,
    'timeout' => 5000,
    'signal' => $cancellation, // Amp\Cancellation, необязательно
])->await();
```

Ожидание на Page/Frame перезапускается после навигации; ожидание на ElementHandle
привязано к его документу. Результат переносится в основной execution context,
поэтому его можно передать в `page.evaluate`. При `hidden: true` отсутствующий
узел даёт null, а существующий скрытый узел — ElementHandle, как в оригинале.
Отмена останавливает browser poller и освобождает промежуточные handles.

`selectors-oracle.cjs` и `selectors.php` сравнивают 11 наблюдений: появление,
visible/hidden, text fallback, scoped и detached root, изоляцию от изменённых
DOM-прототипов страницы, timeout, Amp cancellation и переход через навигацию.
OOPIF-сценарий в `frames.php` также использует `waitForSelector`.
Результаты: `.build/native-artifacts/selectors-oracle.json` и `selectors-native.json`.

## Bindings, exposeFunction и ARIA

```php
use function Amp\async;

$page->exposeFunction('lookup', static function (string $key) {
    return async(static function () use ($key) {
        // Здесь можно ожидать асинхронный PHP HTTP/DB клиент.
        return ['key' => $key, 'found' => true];
    });
})->await();
$result = $page->evaluate('lookup("item")')->await();
$page->removeExposedFunction('lookup')->await();
```

Обёртки `addPageBinding`, получения DOM-аргументов, resolve/reject берутся из
`cdp/utils.ts` и `cdp/Binding.ts`. CDP-событие направляется в execution context
той же сессии; PHP callback может вернуть значение или Amp Future. Отдельный
reader продолжает обрабатывать команды, поэтому callback может сам вызвать
`page.title()` или `element.evaluate()` без блокировки транспорта.

Функции устанавливаются в существующие Frame и в новые документы через preload
scripts, включая OOPIF. Удаление убирает wrapper и preload. PHP Throwable
становится отклонением JavaScript Promise; stack trace остаётся PHP stack trace.
DOM-аргументы приходят как ElementHandle и освобождаются после вызова.

ARIA `aria/`, `aria=`, `::-p-aria(...)`, querySelectorAll и waitForSelector работают
через эти bindings. Исходный ARIA parser и assert выполняются в браузере;
PHP использует Accessibility.queryAXTree и возвращает DOM-handles. Фильтр ролей
также извлекается из исходников Puppeteer. Это добавляет CDP-вызовы для ARIA,
но не запускает Node/Python в клиенте.

`bindings-oracle.cjs` и `bindings.php` сравнивают 20 наблюдений: значения,
конкурентные callbacks, reentrant evaluation, ошибки, DOM-аргументы, очистку
callback maps, ARIA-поиск и валидацию, inline-вызов в новом документе, существующие
и новые OOPIF, удаление и повторную навигацию. Отчёты —
`.build/native-artifacts/bindings-oracle.json` и `bindings-native.json`.

## Клавиатура и ввод текста

```php
$page->type('#name', 'Привет 😀', ['delay' => 20])->await();
$page->keyboard->down('Shift')->await();
$page->keyboard->press('KeyA')->await();
$page->keyboard->up('Shift')->await();
$input = $page->querySelector('#name')->await();
try { $input->press('Enter')->await(); }
finally { $input->dispose()->await(); }
```

Состояние клавиатуры и CDP Session принадлежат Page; ElementHandle фокусирует свой
элемент в isolated world и использует клавиатуру страницы. Это работает и для
iframe другого процесса. Frame.type/Page.type теперь также переводятся из
исходных тел методов, включая освобождение временного handle.

Таблица клавиш, keyDown/rawKeyDown/keyUp, repeat, location, Shift/Control/Alt/Meta,
переопределение text, editing commands и Unicode следуют исходникам Puppeteer.
`Keyboard.type` перебирает Unicode code points, а JS string.length считает UTF-16
code units. Задержка ввода использует Amp timer и позволяет другим fibers и
браузерным операциям продолжать работу.

`keyboard-cases.json` используется обоими клиентами; browser fixture записывает
настоящие trusted key/beforeinput/input события. Дополнительные сценарии проверяют
неизвестную клавишу, disposed handle, отсутствующий селектор, подмену focus в
main world, ввод в OOPIF и выполнение PHP/CDP во время задержки. Артефакты —
`keyboard-native.json` и `keyboard-oracle.json` в `.build/native-artifacts`.

## Мышь

```php
$page->mouse->move(100, 100, ['steps' => 5])->await();
$page->mouse->click(100, 100, ['count' => 2])->await();
$page->mouse->wheel(['deltaY' => 300])->await();
$page->setDragInterception(true)->await();
$page->mouse->dragAndDrop(['x' => 40, 'y' => 40], ['x' => 230, 'y' => 50])->await();
$page->mouse->reset()->await();
```

Move/down/up используют исходные транзакции Puppeteer: незавершённое изменение
видно последующим операциям, успешный ответ фиксирует его, ошибка откатывает
соответствующую транзакцию. Click/reset запускают несколько команд конкурентно,
как в оригинале; общей блокировки ожидания ответов у Mouse нет.

29 дополнительных browser observations сравнивают trusted pointer/mouse/wheel
события, шаги и дробные координаты, одиночный/двойной/тройной клик, пять кнопок,
несколько нажатых кнопок, reset, ошибки параметров, модификаторы, drag-and-drop,
настоящий отказ CDP и работу PHP/браузера во время задержки клика.
`InputRuntimeTest` отдельно проверяет видимость незавершённой транзакции и откат,
запуск async до первого await, Promise.all и identity объектов в массиве.
Артефакты — `mouse-native.json` и `mouse-oracle.json` в `.build/native-artifacts`.

## Touchscreen

```php
$page->cdpSession()->send('Emulation.setTouchEmulationEnabled', [
    'enabled' => true, 'maxTouchPoints' => 5,
])->await();
$page->touchscreen->tap(40, 50)->await();
$touch = $page->touchscreen->touchStart(40, 50)->await();
$touch->move(100, 120)->await();
$touch->end()->await();
```

Через CDP в примере задаётся maxTouchPoints. Обычный режим touch также включается
через `$page->setViewport(['width' => 800, 'height' => 600, 'hasTouch' => true])->await()`.
Touchscreen предоставляет tap/touchStart/touchMove/touchEnd,
а возвращаемый TouchHandle — move/end. Поведение нескольких handles и повторных
операций следует исходникам Puppeteer выбранной версии. Координаты используют
семантику Math.round, включая округление половин к положительной бесконечности.

13 browser observations сравнивают настоящие trusted touchstart/touchmove/touchend
события, координаты, ID, force/radius, modifiers, несколько активных handles и
ошибки операций до начала или после завершения касания. Для ошибок CDP сравнивается
исходное сообщение протокола; числовой code не заполнен у CDP-клиента Puppeteer.
Unit-тесты дополнительно проверяют отказ touchStart и обновление CDP-клиента у
активных handles. Артефакты — `touch-native.json` и `touch-oracle.json` в
`.build/native-artifacts`.

## Действия над элементами и геометрия

```php
$page->click('#submit', ['offset' => ['x' => 10, 'y' => 15]])->await();
$page->hover('#menu')->await();
$element = $page->querySelector('#submit')->await();
try {
    $point = $element->clickablePoint()->await(); // object с x/y
    $box = $element->boundingBox()->await();
    $model = $element->boxModel()->await();
    $visible = $element->isIntersectingViewport(['threshold' => 1])->await();
} finally { $element->dispose()->await(); }
```

Геометрия сохраняет исходные browser callbacks Puppeteer и выполняет остальную
логику в PHP: обрезание rectangles по viewport, перевод координат через родителей,
учёт iframe border/padding и выбор первого подходящего client rect. Действия
прокручивают элемент при необходимости и используют Page.mouse/touchscreen.
Generated using превращается в try/finally и запускает dispose handle по правилам
синхронного dispose symbol; await using пока не поддерживается.

27 дополнительных сравнений проверяют частичную видимость, SVG, многострочный
inline, слишком маленькие и скрытые элементы, ошибки detached/disposed, offset,
несколько кликов, debugHighlight, прокрутку, изоляцию DOM, touch actions и iframe.
Скрытый OOPIF проверяется по boundingBox/boxModel/clickablePoint; intersection
проверяется после показа iframe. В локальном Chrome 152 оригинальный Puppeteer
ожидал callback IntersectionObserver в скрытом OOPIF до протокольного тайм-аута.

## Viewport, reload и эмуляция

```php
$page->setViewport([
    'width' => 390, 'height' => 844,
    'deviceScaleFactor' => 2, 'isMobile' => true, 'hasTouch' => true,
])->await();
$page->emulateTimezone('Europe/Podgorica')->await();
$page->emulateMediaFeatures([
    ['name' => 'prefers-color-scheme', 'value' => 'dark'],
])->await();
$page->setGeolocation(['latitude' => 42.44, 'longitude' => 19.26])->await();
$page->setJavaScriptEnabled(false)->await();
$response = $page->reload(['ignoreCache' => true])->await();
```

Исходный setViewport перезагружает страницу при изменении mobile/touch режима,
сохраняет значение viewport и поддерживает null для сброса. reload подписывается
на навигацию до отправки Page.reload и игнорирует same-document navigation.
Также перенесены emulateMediaType, emulateCPUThrottling, emulateIdleState,
emulateVisionDeficiency, emulateFocusedPage и isJavaScriptEnabled.
Geolocation требует отдельного разрешения браузера для origin.

23 сравнения с Puppeteer проверяют browser dimensions, scale/orientation/touch,
число загрузок документа, отключение inline scripts, timezone/media/geolocation,
валидацию параметров и поведение OOPIF. Наследование overrides определяется
Chromium: PHP повторяет исходные вызовы Puppeteer, не добавляя их самостоятельно
к OOPIF. На проверенном Chrome некоторые overrides остаются только у main target;
последовательные setEmulatedMedia могут также сбрасывать ранее заданные параметры.

EmulationManager.registerSpeculativeSession/updateClient сгенерированы и проверены
unit-тестом: состояние передаётся новой сессии до ожидания её ответов, прежняя
сессия не получает повторных команд, disconnect удаляет её из списка, activation
не оставляет дубликат. Сам Page пока не подключает эти методы к prerender targets:
полный target lifecycle остаётся незавершённой частью миграции.
WeakMap-кеш не удерживает старые состояния и не повторяет вызов с прежними
аргументами после ошибки, как исходный декоратор. Дополнительно проверяются
protocol defaults, переписывание Invalid timezone и обработка неподдерживаемого
metrics override. Генераторный mutation-тест меняет accuracy в исходном TS и
проверяет изменённую CDP-команду, а изменение декоратора отклоняет до публикации.

## Сетевые настройки

```php
$page->setExtraHTTPHeaders(['X-Client' => 'native-php'])->await();
$page->setUserAgent([
    'userAgent' => 'MyBrowser/1', 'platform' => 'Linux',
])->await();
$page->setCacheEnabled(false)->await();
$page->emulateNetworkConditions([
    'latency' => 150, 'download' => 100000, 'upload' => 50000,
])->await();
$page->setOfflineMode(true)->await();
$page->emulateNetworkConditions(null)->await(); // сбрасывает также offline
$page->setBypassServiceWorker(true)->await();
```

Параметры и правила их изменения исполняются из исходных методов NetworkManager.
setExtraHTTPHeaders заменяет предыдущий набор, проверяет строковые значения до
изменения состояния и нормализует имена. Для Unicode lowercase явно подключён
symfony/polyfill-mbstring как runtime-зависимость. setUserAgent поддерживает строку,
metadata и объект options; при отсутствии userAgent берёт исходное значение через
Browser.getVersion. Page.browser возвращает тот же объект Browser.

В отличие от части Emulation overrides, NetworkManager явно применяет настройки
ко всем своим CDP-сессиям. Настройки передаются новым OOPIF при инициализации до
снятия Runtime.waitForDebugger, а закрытые сессии удаляются из списка.
Сгенерированная обработка ошибок различает TargetCloseError, неподдерживаемые
команды и остальные ошибки, которые возвращаются вызывающему PHP-коду.

22 browser observations сравнивают реальные заголовки на fixture-сервере,
User-Agent/Client Hints/platform, HTTP cache, offline и latency, новый/существующий
OOPIF и настройки после перезагрузки. Service worker регистрируется в браузере:
с bypass ответ приходит с сервера, после выключения — снова от worker.
Unit-тест дополнительно проверяет начальные protocol defaults, копию headers,
отсутствие частичного изменения при валидации и классификацию ошибок. Mutation-тест
меняет нормализацию ключа в исходном TS и проверяет изменённый PHP-результат.
Cookies ещё требуют переноса. Сам NetworkManager, включая конструктор и
регистрацию клиентов, теперь компилируется целиком; его host-границы описаны ниже.

## HTTP authentication

```php
$page->authenticate(['username' => 'user', 'password' => 'password'])->await();
$response = $page->goto('https://example.test/protected')->await();
$page->authenticate(null)->await();
```

Исполняется исходная auth-логика Puppeteer: включение Fetch с handleAuthRequests,
автоматическое продолжение requestPaused и отправка credentials на challenge.
Повторный challenge одного Fetch request ID получает CancelAuth; разные ID
обрабатываются независимо. Смена credentials при уже включённом Fetch не запускает
повторный Fetch.enable, а authenticate(null) отключает auth-only interception.
Кеш ранее принятых HTTP credentials принадлежит Chromium и не очищается этой командой.

11 сравнений проверяют правильный/неверный пароль (200/401), параллельные запросы,
redirect, смену credentials, отключение режима, другую страницу и новый/существующий
OOPIF. Новый OOPIF посещает отдельный origin до другой страницы, чтобы проверку
не подменял кеш credentials. Unit-тест проверяет protocol messages и повторный
challenge, mutation-тест меняет CancelAuth в исходном TS и проверяет PHP-результат.
Совместная работа с пользовательскими continue/respond/abort проверяется в наборе
interception. Proxy authentication ещё требует отдельных интеграционных сценариев.

## Перехват запросов

```php
$page->on('request', function ($request) {
    if (str_contains($request->url(), '/mock')) {
        return $request->respond([
            'status' => 201, 'contentType' => 'text/plain', 'body' => 'Ответ из PHP',
        ]);
    }
    return $request->continue();
});
$page->setRequestInterception(true)->await();
```

continue поддерживает url/method/postData/headers; respond — status, contentType,
повторяющиеся headers и body. Текст передаётся UTF-8 строкой, бинарные данные —
`new Nesk\Puphpeteer\Native\ByteArray($bytes)` как аналог Uint8Array. Кодирование
байтов/base64 и доступ к исходному сообщению CDP являются явными PHP-границами.
abort принимает исходные Puppeteer error codes.

Без priority действие выполняется сразу. С числовым priority исходная модель
согласует обработчики: при равном приоритете abort выигрывает у respond,
respond — у continue. Page.on('request') добавляет обработчик в очередь, а
finalizeInterceptions ждёт возвращаемые Amp Future и выбирает итоговое действие.
Доступны isInterceptResolutionHandled, interceptResolutionState,
continueRequestOverrides, responseForRequest, abortErrorReason и enqueueInterceptAction.

В браузерном наборе шесть групп сравнивают override POST/headers, UTF-8 и binary
fulfillment, abort, отложенные cooperative handlers, redirect, authentication,
основную страницу и OOPIF, отключение interception. Unit-тесты проверяют оба
порядка Fetch/Network, повторные pauses, смену URL при redirect, uninstrumented
request routing, ошибки повторной обработки и invalid headers. Mutation-тест
меняет default status в TS и проверяет новую Fetch.fulfillRequest команду.

Создание request/response, часть cleanup и часть response/extra-info reconciliation
пока остаются PHP-адаптерами; их полный перенос и расширение проверок cache,
service worker requests, downloads и cancelled redirects остаются в плане.
Page.on/off/removeAllListeners используют сгенерированный EventEmitter; числовые
ID подписки остаются у внутреннего транспорта Session, который ещё требует переноса
публичного CDPSession API.

## EventEmitter и callbacks

```php
$handler = function ($message) use ($page) {
    $title = $page->title()->await();
    echo $title . ': ' . $message->text();
};
$page->on('console', $handler)->once('load', static function () {});
$page->off('console', $handler);
$page->removeAllListeners('request');
```

Page использует исходные on/off/once/listenerCount/emit/removeAllListeners.
on/off возвращают тот же объект; off принимает исходное замыкание. Можно создать
самостоятельный `Nesk\Puphpeteer\Native\EventEmitter`. Для identity-valued event key
используется `EventSymbol`. Wildcard callback получает type и payload.

Порядок удаления дубликатов, snapshot при emit и удаление once после вызова
следуют исходному mitt/EventEmitter, включая рекурсивный emit и исключения.
PHP callback выполняется до первой приостановки в отдельном Fiber. После await
остальные listeners могут продолжать работу; request callbacks при этом сохраняют
очередь cooperative interception. Обработчики console могут отправлять CDP-команды,
не блокируя reader. Синхронные ошибки браузерных listeners также регистрируются
без разрыва соединения. Использование замыканий сохраняет identity для off.

14 сравнений проверяют EventEmitter и Page, async console callbacks, load/close,
request once/off и удаление listeners. Mutation-тесты меняют отдельно TS once и
bundled JS wildcard, проверяя изменение PHP. Unit-тесты проверяют отложенные ошибки
и освобождение request callback после off на проверенной версии PHP.

Page-конструктор теперь создаёт inflight tracker из исходной цепочки RxJS.
Начальный request-listener совпадает с Puppeteer; events-тест сравнивает абсолютные
listenerCount, включая это начальное значение. Browser, BrowserContext и публичный
CDPSession ещё требуют своей EventEmitter-интеграции.

## Ожидание отсутствия сетевой активности

`$page->waitForNetworkIdle(['idleTime' => 500, 'concurrency' => 0])->await()`
выполняет сгенерированное тело Page.waitForNetworkIdle. Его внутренняя Observable
цепочка сохранена из TS, включая ReplaySubject, mergeMap/mergeScan, takeUntil,
distinctUntilChanged, switchMap и raceWith. NETWORK_IDLE_TIME извлекается из util.ts.

Счётчик уменьшается при первом response, requestfinished или requestfailed с тем же
request.id. Поэтому ожидание может завершиться после заголовков, пока тело ответа
ещё загружается. События с тем же id повторно не уменьшают счётчик. Изменение числа
запросов внутри допустимого concurrency не перезапускает таймер: исходная цепочка
сравнивает boolean превышения порога. Каждый вызов имеет собственный таймер.

`timeout` берётся из setDefaultTimeout, значение 0 отключает тайм-аут. Закрытие Page
отклоняет ожидание с TargetCloseError и освобождает подписки. Option `signal`
принимает Amp\Cancellation; после отмены Future выбрасывает Amp\CancelledException.
Как fromEvent в Puppeteer 24.36.1, этот метод не воспроизводит abort, случившийся
до подписки: заранее отменённый signal не прерывает ожидание. Это поведение
проверяется отдельно и не переносится автоматически на другие wait-методы.

PHP-операторы являются явной реализацией границы RxJS, а не результатом перевода
всей библиотеки. Поддерживаются используемые формы вызовов; другие операторы и
дополнительные overloads пока не заявлены. SHA-256 bundled RxJS и тела fromAbortSignal
зафиксированы: изменение зависимости останавливает генерацию для проверки адаптера.
Исходные тела Page и util при этом компилируются заново. Mutation-тест меняет
декремент счётчика и default concurrency, проверяя изменение исполняемого PHP.

14 браузерных сравнений проверяют минимальное ожидание, streaming response до
завершения тела, допустимый concurrency и его превышение, параллельные ожидания,
requestfailed, default timeout, отмену и её cleanup, предварительный abort,
запросы OOPIF и закрытие Page. Unit-тесты дополнительно проверяют повторные события,
синхронную отписку, рекурсивный take, replay, отмену проигравших таймеров и
сохранение таймера при изменениях ниже порога.

## Ожидание запросов, ответов и фреймов

`waitForRequest`, `waitForResponse` и `waitForFrame` выполняют тела Page.ts,
а общий filterAsync — тело util.ts. Передайте точный URL либо PHP callable,
возвращающий boolean или Amp\Future. Замыкание также может вызвать `await()`:
оно выполняется в отдельном Fiber, сохраняя конкурентную обработку событий.
Например, можно проверить `$response->text()->await()` внутри предиката.

```php
$response = $page->waitForResponse(
    fn ($response) => $response->url() === $url
        && str_contains($response->text()->await(), 'expected'),
    ['timeout' => 5000],
);
$page->evaluate(new JsFunction('url => fetch(url)'), $url)->await();
$matchedResponse = $response->await();
```

Подписка создаётся при вызове wait-метода. Предикаты разных событий выполняются
конкурентно, как исходный mergeMap: побеждает первый завершившийся положительный
предикат. Его событие возвращается тем же PHP-объектом. Ошибки синхронного и
асинхронного предиката отклоняют Future ожидания; они не отправляются дополнительно
в глобальный обработчик ошибок listeners. После завершения ожидания поздний
результат или ошибка другого предиката игнорируются; сам предикат не отменяется.

waitForFrame сначала подписывается на attached/navigated, затем проверяет уже
существующие frames. Можно использовать асинхронную проверку frameElement, включая
OOPIF. Request/response события, пришедшие до подписки, не воспроизводятся.
Timeout, Amp Cancellation и закрытие Page освобождают listeners и таймеры. Как и
в waitForNetworkIdle, предварительная отмена signal не воспроизводится.

17 браузерных сравнений проверяют literal URL, POST-предикат, чтение тела ответа,
конкурирующие предикаты, их ошибки, reentrant request при interception, текущие,
новые и навигирующие frames, асинхронный frameElement, тайм-ауты, отмену, cleanup
и закрытие Page. Mutation-тест меняет фильтрацию и сообщение ошибки в TS, а также
использует dollar/Unicode identifiers; сгенерированный PHP должен следовать этим
изменениям. Компилятор кодирует такие имена без коллизий с обычными PHP-переменными.

## История страницы и ответ навигации

`$page->goBack($options)->await()` и `$page->goForward($options)->await()`
исполняют исходный #go: получают Page.getNavigationHistory, выбирают запись,
создают waitForNavigation и отправляют Page.navigateToHistoryEntry. Options
передаются без изменения. Если записи нет, операция отклоняется с исходным
сообщением `History entry to navigate to not found.`.

Результат — HTTPResponse текущего перехода либо null, как у Puppeteer. Переход
между hash/pushState-записями не создаёт нового ответа. При BFCache Chrome
восстанавливает предыдущий документ вместе с JavaScript-состоянием; такой
переход также может вернуть null. Когда BFCache отключён и документ загружается
заново, возвращается полученный HTTPResponse.

LifecycleWatcher теперь хранит только navigation request, замеченный после
создания watcher. Исходные #onRequest/#onResponse/#onRequestFailed управляют
Deferred ожидания ответа, а navigationResponse возвращает response именно этого
request. Ветка BackForwardCacheRestore из исходного #navigated помечает swap.
Прежний глобальный кэш навигационных ответов и ожидание ответа по loader ID
удалены. Завершение lifecycle и navigation Deferred, detach и dispose теперь
компилируются из исходников. Ручная сборка ожиданий goto/waitForNavigation
удалена: исполняются тела методов CdpFrame. Конструктор watcher, подключение
событий и барьер восстановления метаданных BFCache перед navigationResponse
остаются runtime-адаптерами: весь LifecycleWatcher ещё не объявляется
транспилированным.

10 браузерных сравнений проверяют пустую историю, назад/вперёд, pushState,
удаление будущих записей после новой навигации, некорректный waitUntil,
восстановление JavaScript-состояния. Дополнительная native regression проверяет
main-frame identity, все дочерние frames и выполнение кода в восстановленном OOPIF.
Обнаруженное отличие сохраняется в history-frame-diagnostics-oracle.json:
Puppeteer 24.36.1 после восстановления документа из BFCache теряет дочерние frames
из своего списка, хотя iframe остаются в DOM. Это подтверждено на Chrome 152 и
закреплённом Chrome for Testing 144.0.7559.96. PHP восстанавливает фреймы и читает
содержимое OOPIF; прямые проверки записываются в history-frame-regression-native.json.
Этот случай не засчитывается как совпадение с эталоном и не заменяет сравнения
остальных сценариев. Перед полным переносом FrameManager нужно сохранить эту
проверку и явно обработать обнаруженную ошибку исходной реализации.

Отдельный запуск с отключённым BFCache проверяет повторную HTTP-загрузку:

```bash
NATIVE_BFCACHE=disabled composer test-native-local -- history content
```

Его артефакты сохраняются в `.build/native-artifacts/local-no-bfcache`, сохраняя
результаты обычного запуска в `.build/native-artifacts/local`. Mutation-тесты
меняют delta истории, состояние/async body Deferred и условие BFCache в TS,
проверяя соответствующее изменение PHP. Unit-тесты проверяют порядок подписки
и CDP-команды, передачу options, состояния Deferred и освобождение таймеров race.

## Исходные goto и waitForNavigation

FrameNavigationCommands генерируется из полных тел CdpFrame.goto и
CdpFrame.waitForNavigation. Вложенная async-функция navigate тоже переводится:
её запись в ensureNewDocumentNavigation после ответа Page.navigate определяет,
какой Deferred ожидать. Компилятор поднимает локальные function declarations и
передаёт замыканиям живые ссылки на внешние переменные. Собственные параметры,
локальные переменные и catch bindings не становятся внешними captures.
Динамический this/arguments внутри таких функций пока вызывает ошибку сборки.
Mutation-тест изменяет TimeoutSettings, добавляя две вложенные функции и изменение
внешней переменной; сгенерированный PHP исполняет изменённый алгоритм.

Исходная функция referrerPolicyToProtocol выполняет replaceAll и toUpperCase.
Runtime поддерживает проверенный шаблон /-./g, UTF-16 offsets и исключение JS
line terminators; произвольные global regex и замены одиночных surrogate code
units не объявлены реализованными. Валидные значения referrerPolicy проверяются
через настоящий Chrome. В этой версии Puppeteer goto не принимает AbortSignal;
для waitForNavigation сигнал сопоставляется с Amp Cancellation. CancelledException
сохраняет исходную причину отмены в getPrevious().

Отдельный navigation-набор сравнивает referer из extraHTTPHeaders, переопределение
options, пять политик referrer, отклонение конфликтующей пары заголовка/политики,
невалидный waitUntil и URL, default navigation timeout, отмену, игнорирование
same-document, новый документ после hash-перехода, зависший intercepted request,
timeout=0, ответ 201, сетевую ошибку и последующее восстановление работы reader.
После timeout источник не отменяет уже отправленный Page.navigate: поздний ответ
остаётся частью протокольного обмена и не должен завершать другое ожидание.

Как и setContent, исходная навигация входит в finally не на всех путях раннего
отклонения Deferred.race. Компилятор сохраняет порядок операций исходников;
полная гарантия немедленного освобождения подписок при каждом timeout пока
не заявляется. Это не заменяет проверки возврата самой операции по таймауту.

## Установка и сериализация документа

`$page->setContent($html, $options)->await()` и аналогичный метод Frame выполняют
исходные `document.open/write/close`, затем ожидают lifecycle документа.
Опции `waitUntil` и `timeout`, включая 0 и default navigation timeout, сохраняют
семантику Puppeteer. Ожидание lifecycle может завершиться без смены loader ID;
ожидания same-document/new-document navigation при этом остаются отдельными.
`content()` сериализует все document.childNodes по исходному алгоритму, включая
doctype и комментарии вне html. Функции внутри браузера взяты из TS через AST.

20 сравнений с оригинальным Puppeteer проверяют замену/пустой HTML, Unicode,
комментарии/doctype, сохранение URL, выполнение inline JavaScript и его отключение,
exposed binding после document.open, iframe/srcdoc и OOPIF, удалённые фреймы,
удерживаемый intercepted resource, load/domcontentloaded/networkidle0, timeout,
нулевой timeout и некорректный waitUntil. Во время ожидания load PHP выполняет
другой браузерный вызов через тот же reader. Переменные browser frame ID в тексте
ошибки заменяются маркером отдельно на каждой стороне сравнения.

Тест выявил устаревшие дочерние фреймы после перехода на новый документ. Native
FrameManager теперь удаляет их на обычной навигации, а при BFCache восстанавливает
метаданные дерева через Page.getFrameTree. Это PHP-адаптер; алгоритм FrameManager
ещё не перенесён целиком из TS. Обе проверки обязательны: старые iframe отсутствуют
на новой странице, а после возврата все восстановленные iframe доступны.

Mutation-тест меняет document.write и сообщение detach в TS и проверяет изменение
исполняемого результата. Unit-тесты различают завершение документа и навигации,
проверяют ожидание загружающегося дочернего frame, изменение loader ID, identity
ошибки и освобождение подписок при dispose. Mutable Error и стек PHP-подписок
имеют явную runtime-границу. В исходном setContent dispose вызывается после
успешного Deferred.race: при отклонении по timeout этот вызов пропускается.
Генератор сохраняет такое поведение исходной версии, поэтому гарантии освобождения
всех подписок setContent сразу после timeout сейчас нет.

## Добавление скриптов и стилей

`$page->addScriptTag($options)->await()` и `addStyleTag`, а также соответствующие
методы Frame, выполняют исходные методы api/Frame.ts и делегирование api/Page.ts.
Нужно указать ровно одно из url, path или непустого content. Сохраняются script
type/id, загрузка внешних ресурсов, добавление sourceURL при чтении файла и
исходные ошибки валидации. Для style с path исходник записывает options.content:
переданный PHP stdClass сохраняет эту мутацию; PHP-массив преобразуется в локальный
объект параметров и остаётся значением на стороне вызывающего кода.

Браузерный callback создаёт элемент в isolated realm, после чего исходный
IsolatedWorld.transferHandle переносит handle в main realm через DOM.describeNode
и DOM.resolveNode и освобождает прежний handle. В своём realm и для primitive
handle исходный алгоритм возвращает тот же объект. Возвращённый ElementHandle
можно передать в page.evaluate или Frame.evaluate соответствующего фрейма.
Сами ExecutionContext и adoptBackendNode пока остаются PHP/CDP-адаптерами.

NodeFileSystem заменяет только используемое здесь fs.promises.readFile(path,
'utf8'). Он возвращает Future, читает файл порциями и уступает event loop между
порциями. Системные fopen/fread остаются синхронными: полностью неблокирующий
дисковый ввод-вывод здесь не заявляется. Процессы и Node/Python для чтения не
запускаются. Строки, похожие на URL, обрабатываются как локальные пути, без PHP
stream wrappers. Для отсутствующего файла NodeFileError сохраняет ENOENT,
операцию open и путь. Общий Node.js fs API этим не реализован.

22 сравнения с оригинальным Puppeteer проверяют inline/URL/file для script/style,
Unicode, script type/id и content="0", ES module с импортом, sourceURL,
изменение style options, ошибки входных параметров/файла/ресурса, CSP и bypass,
OOPIF и изоляцию родителя. Подмена document.createElement в main world не ломает
вставку через isolated world. Строки ошибок браузерной загрузки сравниваются без
стека и служебного префикса Error; само сообщение проверяется явно.

Unit-тесты проверяют перенос и освобождение handle, идентичность primitive и
same-realm handle, мутацию options, sourceURL для пути с переводом строки,
асинхронный результат чтения и ENOENT. Mutation-тест меняет значение script type
в исходнике TS: сгенерированный PHP должен исполнять новый default.

## Чтение HTTP-ответов и POST-данных

Классы HTTPResponse и CdpHTTPResponse целиком компилируются из исходников API/CDP.
Это включает конструктор, разбор status text из extra-info, все getters,
content/_resolveBody и ok/buffer/text/json. Инициализаторы contentPromise и
bodyLoadedDeferred также компилируются из TS. Повторные content() возвращают
тот же Future и затем тот же ByteArray; CDP-команда отправляется после окончания
загрузки через актуальный request.client. `content()->await()->bytes` содержит
сырые байты, `buffer()->await()` возвращает бинарную PHP-строку.

TextDecoder для text() проверяет UTF-8 в fatal-режиме и снимает начальный BOM.
Для JSON сохраняются округление больших целых до IEEE-754 и отрицательный ноль;
объекты отображаются в ассоциативные PHP-массивы. Ошибки JSON представлены
JsonException, а не идентичным V8 SyntaxError/стеком. Полная совместимость
произвольных JS-строк, в частности одиночных UTF-16 surrogate, не заявляется.
Низкоуровневый stringToTypedArray имеет PHP-адаптер байтов с проверкой хеша
исходной функции: изменение upstream останавливает обновление до аудита.

CdpHTTPResponse.content теперь исполняет специальную ветку ProtocolError для
`No resource with given identifier found`, выдавая исходное пояснение о возможном
preflight-запросе. Остальные протокольные ошибки сохраняются. Исходный
fetchPostData вызывает debugError и возвращает UndefinedValue после ошибки CDP.
Это можно наблюдать через Runtime\Js::setDebugLogger; reader остаётся активным.

Все запросы одной последовательности редиректов теперь используют общее
изменяемое состояние цепочки в JsArray. Поэтому первый запрос тоже видит
последующие редиректы. Исходный redirectChain вызывает slice; Native-обёртка
возвращает PHP-копию массива с теми же объектами HTTPRequest. Изменение копии не
меняет внутреннюю цепочку. Отдельное ручное хранилище редиректов удалено.
Корреляция событий и логика регистрации подписок NetworkManager компилируются
из TS; токены Session и представление CDP-события остаются runtime-границей. Сам HTTPRequest, включая конструктор и управление
состоянием, больше не дублируется.

Генератор полного класса сохраняет порядок инициализации: поля базового класса,
тело его конструктора, затем поля производного класса после super() и остаток
производного конструктора. TypeScript declare уточняет тип и не сбрасывает
унаследованное значение. Getter/setter компилируются в методы и явную диспетчеризацию
свойств через Js::get/Js::set и PHP __get/__set. Так замена request.client
продолжает исполнять исходный setter. Поле id реализует абстрактный getter базы.
Неизвестная форма наследования, конструктора или конфликт служебных имён
останавливает обновление до публикации.

У HTTPResponse исходный headers() возвращает один изменяемый объект, а
HTTPRequest.headers() делает structuredClone. Это проверяется на сгенерированных
классах. Публичные Native-обёртки возвращают PHP-массивы по значению, поэтому
изменение результата HTTPResponse.headers() через PHP-массив не меняет ответ.

14 прямых сравнений конструктора HTTPResponse проверяют приоритет extra-info,
поля безопасности/адреса, Unicode, пустые строки и предел status text в 1000
UTF-16 единиц. Ещё 10 прямых сравнений HTTPRequest проверяют fragment, тип и
признак навигации, POST/undefined/null, обновление и копирование headers,
смену client, идентичность frame/response, ошибки и общее состояние редиректов.
Это отдельные сравнения с исходными классами Puppeteer, а не браузерные наблюдения.

17 браузерных сравнений проверяют потоковый ответ, параллельный evaluate во время
ожидания тела, identity Future/ByteArray, binary content/buffer, неверный UTF-8,
BOM, JSON/ошибку JSON, большие числа и -0, postData/fetchPostData, GET без POST,
копию цепочки редиректов и недоступное тело 302, границы статусов ok(). Unit-тесты
проверяют один getResponseBody на несколько способов чтения, смену request.client
перед загрузкой, обе ветки протокольной ошибки и debug callback.
Mutation-тесты меняют сообщение ошибки, предел status text, нормализацию headers,
поля и конструкторы базы/потомка, default типа запроса и тело setter в TS.
PHP должен исполнять каждое изменение, включая сохранение унаследованного значения
при declare. Отдельная проверка убеждается, что изменение encoding helper
блокирует публикацию.

## Корреляция Network-событий

Сгенерированный NetworkManager включает полные обработчики запросов, ответов,
обеих форм extra-info, редиректов и loadingFinished/loadingFailed. Ручная очередь транзакций
и её flush удалены. Исходный NetworkEventStore хранит очереди redirectInfo и
response/loading event groups; пока extra-info отсутствует, соответствующие
response/finished и следующий redirected request ждут его, как в Puppeteer.

RequestWillBeSentExtraInfo обновляет тот же HTTPRequest либо ожидает его создания.
Заголовки обновляются и при редиректе. Для response из disk cache исходный код
игнорирует response extra-info; memory cache не ожидает отсутствующее extra-info.
Смена CDP-сессии запроса происходит в обработчиках завершения загрузки, включая
ошибки. Поэтому последующее чтение тела OOPIF идёт через его текущий клиент.
При loadingFailed исходник сохраняет failureText и разблокирует чтение тела;
результат чтения определяется getResponseBody, а не принудительной подменой
ошибкой загрузки в PHP.

Список пар event/handler, начальное хранилище, конструктор, addClient и removeClient
берутся из TS. Класс наследует сгенерированный EventEmitter. Проверка networkEnabled,
повторного подключения, регистрация до Network.enable, применение настроек,
обработка ошибок и освобождение DisposableStack исполняют исходные тела.
Повторный addClient возвращается сразу, даже если первый ещё ожидает инициализации.
После ошибки инициализации upstream оставляет клиент зарегистрированным; новое
подключение выполняется после Disconnected. PHP сохраняет это поведение.

TransportEventEmitter использует исходную композицию EventEmitter вокруг
SessionEmitterAdapter. Последний связывает callback identity с observer-токеном
Session. observeSource создаёт общий изменяемый объект на одну отправку события,
а вложенный dispatch восстанавливает внешний объект после возврата. CDP-клиент
в запросах остаётся тем же Session. Вызов handler.bind(this) проверяет, что
PHP-замыкание уже привязано к этому receiver; произвольная перепривязка требует
отдельного адаптера и не подменяется приблизительной реализацией.

Native-обёртка передаёт события в FrameManager/Page, сохраняет первый Future
инициализации между регистрацией frame и его await-фазой и освобождает ожидания
тела при закрытии владельца. FrameProvider обращается к FrameManager.frame.
Для cleanup владельца только поле хранилища и метод forgetRequest открыты
PHP-наследнику как protected; их исходные операции не переписаны. Эти границы
не означают полного переноса FrameManager или всей модели CDPSession.

13 прямых сравнений NetworkManager используют общие последовательности CDP-событий:
extra-info до request и после loadingFinished/loadingFailed, отсутствие extra-info,
смену клиента, cache, задержанный редирект, заголовки в цепочке, события без request,
лишний extra-info и число запросов in-flight. Сравниваются порядок событий,
состояние тех же объектов, headers, ошибки и чтение тела через выбранный клиент.
Node-эталон вызывает оригинальный NetworkManager, PHP — полный сгенерированный
класс через emitter тестового CDP-клиента. Это 13 последовательностей, а не 13 браузерных сценариев.
Unit-тесты дополнительно проверяют подключение обработчиков к реальному Session.
Ещё 10 прямых сравнений проверяют networkEnabled false/true/null/undefined,
повторное подключение при незавершённом Network.enable, отключение и повторное
добавление, сохранение чужих слушателей и четыре вида ошибок инициализации.
Unit-тесты проверяют общий объект события, nested dispatch и cleanup поверх Session.
Mutation-тесты меняют failureText, default конструктора, команду инициализации и
состояние после removeClient: PHP должен исполнять изменённые тела. Отрицательный
тест неподдерживаемой перепривязки handler останавливает генерацию до публикации.

## Освобождение ресурсов и символы

Из исходника util/disposable.ts компилируются синхронный и асинхронный стеки:
инициализаторы, disposed, use/adopt/defer, move и методы освобождения по символам.
Также компилируется SuppressedErrorPolyfill с исходным сообщением и полями
error/suppressed. Стек выполняет callbacks в обратном порядке, продолжает очистку
после исключения, сохраняет единственную ошибку и строит дерево подавленных ошибок
при нескольких исключениях. Async-стек ожидает каждое освобождение, предпочитает
asyncDispose и поддерживает fallback на синхронный dispose. Результат async-метода — Amp Future.

WellKnownSymbol хранит отдельные значения для dispose, asyncDispose и toStringTag.
Они не совпадают со строковыми ключами. Компилятор переводит соответствующие
computed-поля/методы и объектные литералы; JsSymbolObject предоставляет явную
диспетчеризацию этих символов в PHP. EventEmitter публикует исходный disposeSymbol,
поэтому стек может удалить только подписки, принадлежащие обёртке emitter.
Неизвестный символ или object method с динамическими this/arguments/super требует
отдельной реализации и останавливает сборку. Поддержка всех JavaScript Symbols
или произвольных object methods этим не заявляется.

Сравнения запускают именно экспортированные polyfill-классы Puppeteer, а не
встроенный DisposableStack текущего Node.js. В частности, исходный polyfill
допускает defer после dispose, но повторный dispose ничего не выполняет; это
поведение сохраняется. PHP-слой не подменяет его правилами другой реализации.
Полная эквивалентность Promise microtasks не заявляется; проверка асинхронного
ожидания использует незавершённый Future и подтверждает порядок после его завершения.

13 прямых сравнений покрывают обычное освобождение, move, одну и несколько ошибок,
повторный/reentrant dispose, поздний defer и асинхронное ожидание с выбором символа.
Unit-тесты проверяют identity ресурсов/ошибок, различие symbol/string, cleanup
EventEmitter и отсутствие пропуска следующих callbacks при ошибке. Mutation-тест
меняет в TS порядок обхода, передаваемое callback значение и сообщение ошибки:
изменения обязаны исполняться в PHP. Отрицательные тесты неизвестного символа и
динамического this проверяют отказ до публикации артефактов.

## Cookies и permissions из исходников

Генератор переносит тела `cookies`, `setCookie`, `deleteCookie` и
`deleteMatchingCookies` для Browser/BrowserContext, cookie-методы CdpPage и
`overridePermissions`/`clearPermissionOverrides` из CdpBrowserContext.
Таблица соответствия permissions и преобразование partitionKey также читаются
из TypeScript. `defaultBrowserContext()` возвращает один объект на Browser.
PHP-методы возвращают Amp Future; cookies на публичной границе — списки PHP-массивов.

Runtime поддерживает rest-параметры, `filter`/`some`, Map из iterable и удаление
атрибутов cookie. URL разбирает [rowbot/url](https://github.com/TRowbotham/URL-Parser),
реализующий WHATWG URL и доступный на поддерживаемых версиях PHP. URL-адаптер
пока предоставляет только чтение строковых свойств; изменение URL и searchParams
требуют отдельной реализации. Runtime не запускает отдельный процесс для URL.

24 локальных браузерных сравнения проверяют изоляцию контекстов, cookies страницы и контекста,
HttpOnly, замену и удаление, несколько URL, sourcePort, partition keys, ошибки URL,
permissions и делегирование Browser. В исходниках Puppeteer 24.36.1
`deleteMatchingCookies` возвращает true при совпадении имени даже после несовпадения
дополнительных фильтров: эта особенность сохранена и проверяется против оригинала.
Невалидный URL при совпавшем имени вызывает TypeError до удаления.

Mutation-тест меняет expires, mapping camera, partition conversion и список
удаляемых полей; проверяет исполнение изменённого PHP, а не только текст генерации.

## JavaScript и CSS coverage

`page.coverage` и `page.coverage()` возвращают один объект Coverage. Все три класса
Coverage/JSCoverage/CSSCoverage перенесены целиком из `cdp/Coverage.ts`: конструкторы,
start/stop, updateClient, подписки, сброс при навигации, сбор исходников и raw V8
coverage. Преобразование вложенных диапазонов в непересекающиеся интервалы также
генерируется из исходного алгоритма. PHP-адаптер преобразует внешние результаты
stop в списки PHP-массивов; методы возвращают Amp Future.

12 сравнительных браузерных сценариев проверяют JS и CSS, resetOnNavigation,
reportAnonymousScripts, includeRawScriptCoverage, useBlockCoverage и повторные
start/stop. Отдельные положительные проверки требуют наличия именованных скриптов,
выполненных диапазонов и анонимного скрипта при reportAnonymousScripts; внутренние
pptr-скрипты должны отсутствовать. Chrome 152 после навигации не вернул старые
JS-скрипты даже с resetOnNavigation:false; оба клиента сохранили этот результат CDP. Unit-тесты проверяют вложенные/смежные/пустые интервалы, порядок
параллельной отправки команд и освобождение только собственных слушателей.
Изменения sourceURL, порога фильтрации интервалов и тела start проверяются
mutation-тестами; неизвестные labelled continue не компилируются.

Вычисления ExecutionContext получают исходную sourceURL-декорацию из Puppeteer,
чтобы внутренние скрипты не попадали в coverage. Пользовательский sourceURL
сохраняется. Пока применяется INTERNAL_URL из исходника, без JS call-site metadata.
SOURCE_URL_REGEX имеет проверяемую границу адаптации для ECMAScript whitespace
и multiline anchors: изменение исходного regexp останавливает обновление.
Array.sort здесь поддерживает числовые компараторы, стабильные равные элементы
и дробный результат сравнения; остальные типы результата требуют расширения runtime.

## Metrics, queryObjects и Log

Генератор переносит Page.metrics, таблицу supportedMetrics, построение объекта
метрик и событие Performance.metrics. Публичный metrics() возвращает Amp Future
с PHP-массивом. Поля и значения фильтруются исходным кодом Puppeteer, включая
повторяющиеся значения и отсутствие списка. Значения времени и heap не сравниваются
между процессами буквально: браузерные тесты сравнивают набор полей, валидность,
рост Nodes и событие console.timeStamp; точные значения проверяются на CDP fixture.

Page.queryObjects использует проверки прототипа из исходника, клиент главного
frame и его mainRealm для создания результата. Сравнения проверяют объекты,
повторный запрос, primitive/disposed/foreign handles и работоспособность reader
после ошибки. Обработчик metrics выполняет повторный вызов браузера из PHP.

Инициализация Page теперь генерируется из #initialize: FrameManager.initialize,
Performance.enable и Log.enable запускаются до ожидания Promise.all. Адаптер
FrameManager возвращает Future. Исключения закрытого target и остальные ошибки
обрабатываются по исходному catch. Log.entryAdded использует исходные mapping
уровней, исключение worker-сообщений, освобождение аргументов через releaseObject
и создание ConsoleMessage. Runtime.consoleAPICalled описан в следующем разделе; worker lifecycle остаётся отдельным незавершённым участком API; pageerror
описан ниже.

Mutation-тест меняет имя поддерживаемой метрики, преобразование значения,
команду Performance.enable, warning mapping и primitive guard: обновлённое
поведение обязано исполняться в PHP. Всего 13 сравнительных браузерных наблюдений.

## Console API и аргументы JSHandle

Ручная сборка Runtime.consoleAPICalled в Page удалена. Тело CdpPage.#onConsoleAPI
генерируется из исходников: создание JSHandle для каждого аргумента, проверка
слушателей, dispose невостребованных handles, текст, уровни, location, stackTrace
и targetId. Публичный Native ConsoleMessage наследует исходный класс и возвращает
args/stackTrace/location как PHP-массивы; JSHandle сохраняют identity и доступ
к своему execution context. Владение аргументами наблюдаемого сообщения остаётся
у вызывающего кода, как в Puppeteer: после использования следует вызвать dispose.

FrameManager направляет console из main world известного активного context,
включая OOPIF, в исходный обработчик Page. Из исходников Frame следует, что
utility world не публикуется через page.console; чужие isolated worlds также
игнорируются. Native Session использует сгенерированные setTarget/target для
сохранения привязки target metadata. Полный Target lifecycle ещё не перенесён.

12 сравнений с оригиналом проверяют текст и JSHandle для string/number/boolean,
null/undefined/NaN/Infinity/-0/BigInt, объектов, массивов, функций, DOM и Symbol;
warning/error/debug/trace/assert, location/stack, обычный iframe и OOPIF targetId.
В Chrome 152 console.log() без аргументов не вызвал событие ни в одном клиенте:
это проверяется как отсутствие события. Utility/foreign worlds тоже имеют
проверки отсутствия сообщений. Unit-тесты подтверждают освобождение всех handles
при нуле слушателей и сохранение аргументов при наличии слушателя.

Mutation-тест меняет join-разделитель, warning mapping и dispose-ветвь исходника:
PHP должен исполнять изменённое поведение. Это не снимает общих ограничений
неполного JS runtime и ещё не означает завершённость worker console.

## Pageerror и исходные ошибки CDP

CdpPage.#handleException и createClientError/getErrorDetails из cdp/utils.ts
генерируются из исходников. Событие pageerror получает BrowserError с name,
getMessage() и свойством stack, либо исходное значение, если в браузере выброшен
примитив. Пользовательский обработчик поэтому не должен требовать Throwable для
любого payload. PHP getTraceAsString() остаётся PHP stack; браузерный stack доступен
через свойство stack и собирается исходным алгоритмом Puppeteer.

BrowserError предоставляет ленивый заголовок JS-ошибки; createClientError заменяет
stack браузерными callFrames, сохраняет многострочное сообщение и применяет лимит
10 кадров по умолчанию. Host PHP frames здесь не подставляются в browser stack.
Создание evaluation errors и worker lifecycle остаются отдельной работой.

15 прямых сравнений с оригинальным createClientError покрывают отсутствующие поля,
Unicode-name, описание ошибки, stack, обычные объекты и примитивы, включая NaN,
negative zero и BigInt. 14 браузерных сценариев проверяют настоящие исключения,
unhandled Promise.reject, main/utility world, обычный iframe и повторный вызов
браузера из обработчика. В проверенном Puppeteer/Chrome Page не доставляет это
событие из OOPIF: remoteCount=0 зафиксирован отдельно, без объявления доставки
успешной. PHP повторяет маршрутизацию исходного primary client.

Runtime теперь сохраняет короткое замыкание optional property chains с
последующими обязательными свойствами; отсутствующее обязательное свойство после
ненулевой базы всё ещё вызывает TypeError. String.split возвращает изменяемый
JsArray; String.slice отсчитывает UTF-16 units. Срез, образующий одиночный surrogate,
отклоняется, поскольку PHP-граница пока использует UTF-8. Линейные break в
поддерживаемых циклах компилируются; labelled break прекращает сборку.

## File chooser и uploadFile

FileChooser перенесён целиком из common/FileChooser.ts. Методы Page.waitForFileChooser,
#onFileChooser и CdpElementHandle.uploadFile также генерируются из исходников.
Ожидание возвращает Amp Future; несколько текущих ожиданий получают один объект
FileChooser. accept/cancel сохраняют исходное состояние handled, включая неудачную
загрузку. Для отмены ожидания options.signal принимает Amp Cancellation.
Как в текущем исходнике Puppeteer, сигнал, отменённый до регистрации слушателя,
не воспроизводит событие abort: в этом случае ожидание завершается по timeout.

uploadFile использует исходный isolated-handle decorator и проверку multiple,
DOM.describeNode/DOM.setFileInputFiles. Пустой список очищает FileList через
браузерный DataTransfer и отправляет исходные input/change events. FileChooser.cancel
выполняет исходный callback с cancel event. Имена/содержимое, trusted/bubbles/composed
событий, повторная обработка, timeout/abort и последующий chooser проверяются против
Puppeteer; прямой upload проверен в OOPIF. Всего 17 браузерных сравнений.

Runtime реализует move() как перенос следующего resource-dispose: автоматическая
очистка using пропускается один раз, ручной dispose по-прежнему освобождает handle.
Изменение исходного moveable decorator останавливает обновление для аудита.
Nested object bindings, Set.size/clear и rest-параметры используются исходным кодом.

NodePath сохраняет абсолютные POSIX/Windows пути и лексически разрешает относительные
пути на POSIX без realpath/stat. Файл не обязан существовать на PHP-хосте: CDP читает
его на стороне браузера. Относительные пути при выполнении PHP на Windows пока
отклоняются; абсолютные пути проходят исходную проверку. Это остаётся ограничением
незавершённого runtime, а не заявлением о полной поддержке Node path.

В ходе сравнения устранён старый ручной формат ProtocolException. Тело
createProtocolErrorMessage и шаблон CallbackRegistry теперь генерируются из
исходников; сохраняется prefix Protocol error (method) и presence-based добавление
data, включая null/false/пустую строку. originalMessage остаётся исходным сообщением CDP.
Mutation-тест проверяет FileChooser.handled, callback cancel, upload guard и команду CDP.

## Получение свойств JSHandle и освобождение ссылок

`api/JSHandle.getProperty`, `cdp/JSHandle.getProperties` и `dispose` генерируются
из реализаций Puppeteer. `getProperty` сохраняет синхронный `throwIfDisposed`
до создания Future, а браузерная функция извлечения свойства остаётся JavaScript.
Сообщение декоратора генерируется из его default callback; изменение тела
декоратора останавливает обновление до проверки PHP-адаптера.

CDP `getProperties` использует один `Runtime.getProperties` с `ownProperties`.
Исходный фильтр оставляет enumerable descriptors с value, пропускает accessors
без вызова getter и создаёт отдельные handles через realm. PHP-граница преобразует
Map в массив handles с сохранением порядка. `getProperties` после dispose
сохраняет исходное обращение к CDP, а не добавляет отсутствующий upstream guard.

`dispose` устанавливает флаг до ожидания `Runtime.releaseObject`, повторный вызов
не отправляет команду. Исходный releaseObject подавляет ошибку уже уничтоженного
realm. Возвращённые handles свойств остаются действительными после освобождения
родительского handle и требуют собственного dispose.

Тело `valueFromRemoteObject` также генерируется: undefined/null, BigInt,
NaN/Infinity/-Infinity/-0, assertion при objectId и ошибка неизвестного значения.
Компилятор сохраняет знак отрицательного нуля и поддерживает завершающиеся throw
ветви switch. BigInt-адаптер принимает десятичную запись из CDP; это не общая
реализация преобразования произвольных JavaScript-значений функцией BigInt.

Набор `handles` проверяет свойства, inherited/accessor/key-handle lookup,
независимое владение дочерним handle, DOM handles, повторное освобождение и
освобождение после навигации. Unit-тесты отдельно проверяют единственный CDP
запрос, pending release, подавление ошибки и точные специальные значения.
Mutation-проверка изменяет фильтр, команды и тексты source guard; изменённый
контроль потока декоратора должен отклоняться до записи результата генерации.
Realm lifecycle, evaluate и evaluateHandle ещё имеют ручную PHP-границу;
этот перенос не означает завершение всего JSHandle/ElementHandle lifecycle.

## Ошибки evaluate и служебные source URL

`createEvaluationError` выполняется из сгенерированного тела `cdp/utils.ts`.
ExecutionContext передаёт ExceptionDetails в этот helper и сохраняет результат
на границе PHP исключений. Error-объекты становятся `Runtime\BrowserError`:
`getMessage()` возвращает исходное сообщение без прежнего добавления всего
CDP description, а `name` и `stack` доступны как свойства. Stack собирается
исходным алгоритмом, включая multiline header, порядок frames, stackTraceLimit,
служебные URL и изменение порядка исходного массива callFrames через reverse.

Брошенные строки, числа, null, undefined и BigInt сохраняются в
`Native\JavaScriptException::$value`. Это необходимая граница языка: PHP
разрешает бросать только Throwable. Для события pageerror примитивы по-прежнему
передаются напрямую в callback, как в оригинальном Puppeteer.

```php
try {
    $page->evaluate('throw 123n')->await();
} catch (Nesk\Puphpeteer\Native\JavaScriptException $error) {
    assert($error->value instanceof Nesk\Puphpeteer\Native\BigInt);
    echo $error->value->decimal; // 123
}
```

BrowserError захватывает PHP host frames при создании и форматирует заголовок
при первом чтении stack. `createEvaluationError` удаляет собственный frame и
соединяет оставшиеся PHP frames с browser frames. PHP пути и caller names
естественно отличаются от Node; `getTraceAsString()` также остаётся PHP trace.
`createClientError`, используемый pageerror, заменяет host frames браузерными,
поэтому его прежние сравнения stack продолжают проходить без нормализации.

Методы PuppeteerURL и тела static arrow fields parse/isPuppeteerURL тоже
генерируются: fromCallSite, URL decoding/encoding, getters и toString. URI-адаптер
сохраняет правила encodeURIComponent/decodeURIComponent для UTF-8, включая
символы !~*'(), literal plus и ошибку malformed percent/UTF-8 sequence. Состав
класса проверяется при обновлении. Static arrow fields представлены PHP-методами;
произвольная подмена этих полей не реализована, поэтому класс не учитывается
как полностью перенесённый. Автоматическое добавление PHP call-site metadata
к переданной функции ещё предстоит: без явного sourceURL и metadata
JsFunction::sourceUrl сохраняется pptr:internal.

`evaluationerrors` сравнивает 21 результат helper/URL, включая специальные
значения, порядок и мутацию frames, URI ошибки и нулевой stackTraceLimit.
`evaluation` сравнивает 21 браузерное наблюдение: Error/TypeError/AggregateError,
примитивы, SyntaxError, Promise rejection, функции, evaluateHandle/JSHandle,
isolated realm, OOPIF и параллельный успех при ошибке соседнего Future.
Browser-frame сравнения исключают платформенные host frames и используют
stackTraceLimit=100, чтобы вместить оба стека. Нулевая граница проверяется отдельно.
Mutation-тесты меняют имя ошибки, lineNumber и URL default; неизвестное новое
поле PuppeteerURL отклоняется до публикации генерации.

## Аргументы evaluate и ошибки возврата по значению

`convertArgument` и `rewriteError` из `cdp/ExecutionContext.ts` перенесены в
`Generated\Upstream\ExecutionHelpers`. Полный evaluator использует исходный
вложенный convertArgument и этот rewriteError; отдельный argument-адаптер
делегирует helper вместо прежних ручных проверок. Преобразование аргументов сохраняет -0, NaN,
Infinity/-Infinity, BigInt, undefined и приоритет remoteObject.unserializableValue
перед objectId. Значение обычного аргумента сохраняет ссылку до транспортной
сериализации. Undefined передаётся отдельным CallArgument без value, поэтому
браузер видит аргумент с undefined, а не отсутствие аргумента.

Проверки handle выполняются в исходном порядке: сначала принадлежность realm,
затем disposed. Тексты ошибок включают исходные восклицательные знаки.
`rewriteError` преобразует сообщения CDP о слишком длинной цепочке ссылок и
невозможности вернуть объект по значению в remote undefined. Поэтому
`evaluate` с циклическим результатом возвращает UndefinedValue, а
`evaluateHandle` позволяет работать с этим же циклическим объектом через ссылку.
Только два исходных suffix сообщения заменяются ошибкой уничтоженного context;
для прочих ошибок сохраняется исходный объект исключения.

Набор `arguments` сравнивает 23 браузерных наблюдения: специальные значения,
число аргументов при undefined, свойства объектов, повторно сериализованный
объект, primitive/object handles, foreign/disposed guards, циклический и глубокий
результат для Runtime.evaluate/callFunctionOn и работу reader после ошибок.
Набор `executionerrors` сравнивает 8 случаев исходной rewriteError, извлечённой
TypeScript AST и выполненной в Node, включая проверки suffix и identity ошибки.
Unit-тесты проверяют также identity значения до сериализации и приоритет полей
remoteObject. Mutation-тест изменяет числовую проверку, текст guard и результат
переписывания ошибки; изменённый PHP обязан выполнить новые исходные тела.

## Полное тело evaluator и LazyArg

`Generated\Upstream\ExecutionEvaluator` компилирует всё тело
`ExecutionContext.#evaluate`: обе CDP-ветви, вложенные функции преобразования,
Promise.all для LazyArg, flags, sourceURL, исходный catch сериализации и
обработку результата. Ручная сборка Runtime.evaluate/Runtime.callFunctionOn
удалена из PHP ExecutionContext. `LazyArg` тоже строится из исходника, включая
factory и async get. Static factory представлен PHP-методом, поэтому весь класс
не отмечается как полностью совместимый с изменяемым JS static field.

Один evaluator сохраняется на execution context: LazyArg получает одинаковый
объект при повторных и параллельных вызовах. Его puppeteerUtil делегирует
существующей utility realm. Отдельный аргумент клиента на каждый вызов сохраняет
индивидуальную Cancellation; одновременные вычисления не перезаписывают клиент
друг друга. Этот адаптер нормализует callFrames для исходных операций массива
и инвалидирует native context после соответствующих ошибок CDP.

PHP Fiber начинает evaluate сразу. Транспорт фиксирует обычные аргументы до
возврата Future: последующее изменение stdClass не меняет отправляемое значение.
При наличии LazyArg исходный Promise.all определяет момент преобразования.
JSON-граница опускает undefined/function свойства, преобразует такие элементы
массива и вложенные нечисловые NaN/Infinity в null, отклоняет вложенный BigInt.
Циклы stdClass, PHP array и JsArray отклоняются синхронным TypeError, к которому
исходный catch добавляет Recursive objects are not allowed. Общие ссылки без
цикла допустимы. Диагностический путь V8 через constructor/property не воспроизводится;
глубина сериализации ограничена 512. Произвольные PHP-объекты не поддерживаются.

JsFunction принимает явный sourceUrl типа PuppeteerURL; исходный evaluator
использует metadata, если в тексте нет sourceURL. Автоматическая привязка PHP
call-site ещё не реализована. Стабильная идентичность IsolatedWorld при смене
execution context также требует переноса lifecycle: текущая PHP-граница
представляет realm объектом ExecutionContext. Перенос evaluator не подтверждает
полную совместимость передачи старых handles после навигации.

Набор `evaluator` сравнивает 15 результатов с реальным Puppeteer: порядок LazyArg,
параллельный вызов, utility, identity context, фиксацию аргументов, JSON ошибки,
metadata и работоспособность reader. Четыре unit-теста проверяют также раздельные
клиенты и отличие синхронного throw от отклонения Future. Mutation-тест меняет
обе CDP-команды, flags, LazyArg result и текст catch; PHP обязан выполнить
изменённые тела. Попытка записи в подставленный per-call client отклоняется
генератором до публикации.

## Подготовка текста JavaScript-функции

`util/Function.stringifyFunction` генерируется целиком в FunctionHelpers.
ExecutionContext вызывает его перед декорированием sourceURL и отправкой
Runtime.callFunctionOn. Тело функции сохраняет обычные и стрелочные формы,
добавляет `function ` к сокращённому методу и переносит async-prefix по правилам
исходника. `JsFunction::toString()` удаляет начальные пробелы и комментарии
перед function token, как у функции, созданной из такого литерала в Node.
Исходное поле source остаётся неизменным; тело функции и комментарии внутри
него сохраняются. Браузер исполняет итоговый JavaScript. Сокращённые методы и generator/async
формы больше не обходят исходную подготовку Puppeteer.

Четыре используемых regexp имеют проверяемое соответствие JS → PCRE.
Диапазоны `ID_Start`, `ID_Continue` и ECMAScript whitespace строятся через
RegExp движок Node во время генерации и сохраняются в FunctionPatterns.php.
Это устраняет зависимость результата от версии Unicode в PCRE хоста PHP,
включая различия для FEFF, U+0085 и новых идентификаторов. Runtime использует
готовые диапазоны и не запускает Node/Python. Версия Unicode записывается в
manifest.json; текущая сборка использует 17.0. Смена Unicode-версии генератора
может изменить артефакты даже при прежней версии Puppeteer, что обнаружит
`composer verify-php -- --offline`.

Это ограниченное преобразование четырёх проверенных regexp. Изменение их
формы в upstream останавливает генерацию до аудита нового соответствия.
Для этих anchored prefix checks реализованы числовые captures результата match;
полный RegExp API со свойствами index/input/groups и stateful global matching
по-прежнему не заявляется. substring реализован для используемой формы с одним
целочисленным аргументом, с UTF-16 отсчётом и ограничением отрицательного start.

`functionsource` сравнивает 33 строки с исходным helper и один сводный результат
проверки 4 464 Unicode boundary points, каждый в начале и продолжении имени.
Набор включает некорректные строки только для проверки самой функции
stringifyFunction: она не является парсером и не подтверждает валидность JS.
`functions` проверяет 28 форм функции реальными вызовами Puppeteer/Chrome и
один последующий вызов reader. Покрыты сокращённые методы, комментарии,
async/generator формы, Unicode/astral имена, ZWNJ/ZWJ, FEFF и начальные
пробелы/комментарии. Последние включают регрессионный случай существующего
набора tags: новая подготовка функции должна сохранять его работоспособность.
Mutation-тест меняет source prefix, сравнивает сгенерированную строку и исполняет
её в Node; изменение Unicode regexp должно отклоняться до записи артефактов.

## Инъекция и обновление PuppeteerUtil

Класс ScriptInjector генерируется целиком из TypeScript, включая Set amendments,
порядок добавления, удаление, dirty flag, force и точный текст итоговой функции.
Браузерный injected.js теперь сохраняется побайтно из исходного строкового
литерала без дополнительного перевода строки. Его содержимое выполняется только
в браузере. PHP-класс читает этот поставляемый asset при сборке скрипта.

Getter ExecutionContext.puppeteerUtil и #addBindingWithoutThrowing тоже
генерируются из исходника. Они устанавливают ARIA bindings один раз, сохраняют
Future utility, освобождают прежний handle при новой инъекции и передают ошибки
установки bindings в debugError. На PHP-границе остаются module-level singleton,
ARIA callbacks и адаптация сигнатуры evaluate. Установка внутреннего binding
через CDP теперь также генерируется; полный lifecycle ExecutionContext ещё
предстоит перенести.

PuppeteerUtil теперь остаётся оригинальным замороженным объектом. Прежняя
расширенная копия удалена. Selector parser bundle получает отдельный handle
на execution context, а ARIA parser вызывается из извлечённого исходного JS.
Дополнительные поля getQueryHandlerAndSelector/parseARIASelector больше не
добавляются к PuppeteerUtil. Реестр customQuerySelectors внутри utility сохраняет
исходную изменяемость и доступен amendments.

Состояние module singleton и dirty flag следует исходнику: inject сбрасывает
флаг после callback; исключение callback прерывает сброс. Возвращаемый Future
callback не ожидается синхронным inject. Полная эквивалентность JS microtask
scheduling не заявляется. Обновление одного execution context не означает
автоматическую повторную инъекцию во все существующие contexts.

Набор `injector` сравнивает 16 результатов с Puppeteer: хеш базового скрипта,
порядок и дедупликацию amendments, pop отсутствующего значения, force/cache,
повтор после ошибки callback, identity Future, замену и disposal handle,
замороженность utility, отсутствие PHP helper-полей и удаление amendment.
Четыре unit-теста проверяют ожидание обоих bindings, сохранение dirty state при
throw, разовую установку bindings и debugError. Mutation-тест изменяет условие
инъекции, текст wrapper, initializer bindings и вызываемый disposal-метод;
сгенерированный PHP выполняет новые тела. Неизвестный constructor в новом поле
ScriptInjector останавливает генерацию до публикации. Изменение исходной
инициализации module singleton также требует аудита PHP dependency binding.

## Mutex и установка внутренних bindings

`ExecutionBindingCommands` компилирует всё тело ExecutionContext.#addBinding:
проверку Map до блокировки, acquire, using, выбор executionContextName или ID,
Runtime.addBinding, вызов исходной addPageBinding, запись Map и обработку ошибок.
PHP сохраняет имена из Runtime.executionContextCreated; создаваемый utility world
также получает своё имя в адаптере. Ручная установка ARIA bindings через bind
заменена исходным методом. Внешние exposed functions пока используют прежний
PHP-адаптер установки и отдельный registry.

Mutex и вложенный Guard генерируются из util/Mutex.ts, включая FIFO, Deferred,
привязку resolve и необязательный callback освобождения. Mutex.Guard представлен
заменяемым PHP class-string полем; произвольные JS constructor-функции на этой
границе не исполняются. Поэтому Mutex не добавлен в перечень классов с полной
поддержкой поверхности JS API. Инвентаризация методов пока не учитывает вложенные
class expressions, хотя тело Guard тоже генерируется. Неизвестная базовая
реализация Guard отклоняется при обновлении.

Сохранены особенности upstream: callback первого свободного acquire не
передаётся Guard; исключение callback queued guard прерывает release. Проверка
наличия binding выполняется до acquire, поэтому два одновременно начатых
вызова для одного имени могут оба установить его. Последующий вызов после
завершённой установки уже пропускается. Это проверяется отдельно от FIFO.

Для этого исходного using генератор фиксирует dispose-метод при входе и вызывает
его в finally, включая return и throw. При одновременной ошибке тела и disposal
создаётся исходный SuppressedErrorPolyfill с обеими ошибками. Это синхронный using;
await using этим новым обработчиком не поддерживается. Null/undefined ресурс не
освобождается; Future, возвращённый sync disposer, не ожидается. Error-предикат
исключает JavaScriptException, используемый для переноса не-Error JS throw.

Набор `bindinginstall` сравнивает 11 наблюдений с Puppeteer. Кроме Mutex он
использует оригинальный ExecutionContext с настоящим CDP: для изолированной
проверки установки заменяется только создание возвращаемого remote handle.
Проверяются оба ARIA bindings, распространение name binding на созданный позже
world с тем же именем, изоляция ID binding от других worlds и cache utility.
Обычные браузерные bindings/selectors наборы дополнительно проверяют исполнение
ARIA callbacks через штатные contexts, включая ожидания и OOPIF.

Семь unit-тестов проверяют очередь, замену Guard, ошибки протокола и evaluate,
повтор после отказа, оба вида scope и using с двумя исключениями. Mutation-тест
меняет FIFO на LIFO, передачу и число вызовов callback, CDP-команду, context name,
тип wrapper и ключ registry: PHP обязан выполнить изменённую реализацию.

## События ExecutionContext и exposed functions

`ExecutionEventCommands` переводит полные тела #onBindingCalled и #onConsoleAPI
из ExecutionContext.ts. `PageBindingCommands` переводит #onBindingCalled из
CdpPage.ts. Native ExecutionContext теперь наследует исходный EventEmitter;
FrameManager передаёт событие соответствующему context, а сгенерированный
обработчик проверяет context ID и публикует исходные bindingcalled/consoleapicalled.
Фильтр main world для Page.console остаётся на границе FrameManager.

Внутренние bindings ищутся в исходном Map ExecutionContext. Неизвестные и внешние
события передаются дальше. Page-обработчик проверяет exposedFun и наличие context,
затем вызывает binding из внешнего registry. Пока этот registry зеркалируется
в native contexts, PageBindingCommands подключён к их PHP-адаптеру. Полный перенос
Page/IsolatedWorld lifecycle ещё не выполнен. Async listeners отслеживаются через
Session.track; их ошибки не останавливают WebSocket reader.

Ручные проверки event.name, обязательных полей payload и типа args удалены из
маршрутизации. Исходник ориентируется на имя внутри payload; это проверено
в браузере отправкой корректного payload через другое установленное protocol
binding. Невалидный JSON игнорируется исходным catch без переменной. Валидный
JSON null вызывает ошибку при destructuring, как upstream; этот случай проверяется
изолированно, с явным ожиданием Future. Ошибка internal callback уходит в debugError;
ошибка внешнего callback проходит через исходный Page-обработчик без такого catch.

JSON.parse для исполнения source-кода сохраняет stdClass и JsArray раздельно,
включая вложенные {} и []. Общая нормализация чисел сохраняет IEEE-754 округление
и отрицательный ноль; исходная строка проверяется до нормализации, чтобы не принять
невалидные числа с ведущими нулями. Ограничение глубины PHP JSON decoder — 512.
Существующий PHP array boundary HTTPResponse.json сохранён отдельно.

Native Binding.run принимает исходную сигнатуру context/seq/args/isTrivial
и делегирует сгенерированному Binding. Входной args обрабатывается как iterable;
вложенные source-объекты сохраняют своё представление до callback и сериализации.

Набор `bindingevents` сравнивает 13 результатов: 9 из исходных обработчиков,
извлечённых TypeScript AST и выполненных в Node, и 4 браузерных наблюдения.
Покрыты foreign context, malformed JSON, fallback с identity события, null,
optional binding, аргументы internal callback, разные пути ошибки, console,
маршрутизация по payload и JSON roundtrip. Roundtrip сравнивается как строка
JSON из браузера, поэтому {} и [] не сливаются в PHP-компараторе.
Четыре unit-теста добавляют ожидание callback, точные типы JSON и large integer/-0.
Mutation-тест меняет ID-предикат, имена событий, callback seq и exposedFun type;
неподдержанное destructuring catch отклоняется до публикации.

## Полный Binding.run и передача исключений

Класс Binding генерируется целиком из cdp/Binding.ts. Исходник определяет
извлечение non-trivial arguments, выбор node subtype, запись в args, вызов
callback, доставку результата и две ветви доставки ошибок. Ручное тело
Native Binding.run удалено. Его PHP-обёртка хранит исходный Binding и адаптирует
variadic evaluate/evaluateHandle через BindingContext. BindingHandle сохраняет
исходный Map getProperties без промежуточного преобразования в PHP-массив.

Компилятор поддерживает используемый switch с завершающим break и строгим JS
сравнением cases; fallthrough отклоняется до публикации. In-проверка различает
наличие индекса и значение undefined. Запись заменяет существующий индекс JsArray;
общая модель sparse arrays и произвольных array properties ещё не реализована.
Unary plus обрабатывает primitive numeric conversion; object-to-primitive hooks
не перенесены. Для radix-строк округление до binary64 выполняется по сохранённым
битам с ties-to-even, без промежуточной потери точности.

isErrorLike генерируется из util/ErrorLike.ts и проверяет наличие name/message,
в том числе со значением undefined. Native JavaScriptException переносит raw
throw; сгенерированный catch извлекает исходное значение. Поэтому rejection
может сохранить строку, null, undefined, -0, BigInt, массив или обычный объект.
Error-like объект доставляется через исходный new Error(message), включая
переданный stack. Для обычных PHP исключений стек берётся из PHP; равенство
платформенных host stack strings с Node не заявляется. Полная модель Error
по-прежнему зависит от отдельных runtime-адаптеров JsError/BrowserError.
Source Promise.catch также извлекает raw rejection и ожидает Future, возвращённый
обработчиком. Ошибка при доставке rejection уходит в исходный debugError.

Оба disposal methods JSHandle теперь генерируются из api/JSHandle.ts; PHP
moveable adapter сохраняет свой прежний skip-next-disposal contract. Sync
symbol запускает dispose().catch(debugError), async symbol возвращает dispose.
Binding использует эти symbols через исходный using контейнера аргументов.

В Puppeteer 24.36.1 Binding.run создаёт `const stack = new DisposableStack()`
и не освобождает его. Этот факт подтверждён unit и браузерным сравнением:
контейнер аргументов освобождается до callback, но DOM argument handle остаётся
жив после завершения binding. Результат-handle также не освобождается этим
методом. Прежняя дополнительная PHP cleanup удалена, чтобы выполнить исходный
алгоритм. Тесты сами освобождают сохранённые handles после наблюдения.
Mutation-тест заменяет const stack на using stack и подтверждает, что новая
генерация начинает освобождать содержимое без ручной правки PHP алгоритма.

Набор `bindingrun` сравнивает 19 результатов с Puppeteer: 12 вариантов throw,
DOM argument с JSON объектом, возвращаемый handle, их lifetime, function result,
reader и преобразование 204 numeric strings. Для чисел сравниваются binary64
байты, поэтому округление и отрицательный ноль не скрываются форматированием.
Шесть unit-тестов дополнительно проверяют мутацию args, ErrorLike поля,
подавление ошибки доставки и flattening Promise.catch. Mutation-тесты меняют
constructor state, case subtype, результат callback, ErrorLike predicate,
using stack и тело disposal symbol; изменённый PHP обязан выполнить новые тела.

## Локальный браузерный прогон

`composer test-native-local` запускает тот же набор сценариев в отдельном headless
Chrome с собственным профилем и PHP fixture-сервером на свободном порту 8080.
По умолчанию используется установленный Chrome на macOS; путь можно передать в
CHROME_BIN, PHP — в NATIVE_PHP_BIN. Допустим выбор сценариев, например
`composer test-native-local -- actions`. PHP-клиент запускается с PATH без
Node/Python и отключёнными функциями запуска процессов. Node нужен только runner
и эталонному Puppeteer. Локальные артефакты находятся в `.build/native-artifacts/local`
и не пересекаются с Docker-артефактами.

После полного переноса Binding локальный прогон прошёл на PHP 8.5.7 и
Chrome 152.0.7977.83: 775 сравнений в 44 наборах, native integration и отдельная
положительная проверка восстановления OOPIF. Дополнительный запуск без BFCache прошёл для
history/navigation: 31 сравнение и native integration; предыдущая проверка
history/content без BFCache также прошла (30 сравнений). Unit-набор: 140 тестов, 921 assertions; PHPStan level 5 и проверка воспроизводимости проходят.
Docker-прогон новых изменений после touch input
не подтверждён: Docker API перестал отвечать до старта контейнеров, включая /_ping;
ожидающие CLI были остановлены без перезапуска Engine. Последний завершённый
Docker-прогон покрывал 159 сравнений до добавления геометрии. Это ограничение
проверки среды не означает готовность полного native-клиента к релизу.
