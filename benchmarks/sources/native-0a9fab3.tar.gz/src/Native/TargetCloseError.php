<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** Transport boundary for the upstream TargetCloseError predicate. */
final class TargetCloseError extends \RuntimeException {}
