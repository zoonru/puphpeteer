<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** Lossless browser BigInt. No dependency on GMP or machine integer width. */
final class BigInt implements \Stringable
{
    public readonly string $decimal;

    public function __construct(string $decimal)
    {
        if (!preg_match('/^-?\d+$/D', $decimal)) {
            throw new \InvalidArgumentException('BigInt requires a decimal integer');
        }
        $digits = ltrim(ltrim($decimal, '-'), '0');
        $this->decimal = $digits === '' ? '0' : (str_starts_with($decimal, '-') ? '-' : '') . $digits;
    }

    /** Decimal form supplied by the generated CDP remote-value decoder. */
    public static function fromDecimal(string $decimal): self { return new self($decimal); }

    public function toString(): string { return $this->decimal; }

    public function __toString(): string { return $this->decimal; }
}
