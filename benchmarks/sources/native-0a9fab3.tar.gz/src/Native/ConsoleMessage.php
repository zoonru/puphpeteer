<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;
use Nesk\Puphpeteer\Native\Runtime\Js;

/** PHP collections around the generated ConsoleMessage data model. */
final class ConsoleMessage extends Generated\Upstream\ConsoleMessage
{
    public function args(): array { return [...Js::iterate(parent::args())]; }
    public function location(): array { return (array) parent::location(); }
    public function stackTrace(): array { return array_map(static fn ($location)=>(array)$location,[...Js::iterate(parent::stackTrace())]); }
}
