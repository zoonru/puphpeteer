<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Nesk\Puphpeteer\Native\Generated\Upstream\JSHandleCommands;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

class JSHandle implements \Stringable, Runtime\JsObject, Runtime\JsSymbolObject
{
    use JSHandleCommands { getProperties as private sourceGetProperties; }
    use Generated\Upstream\JSHandlePropertyCommands;
    use Generated\Upstream\JSHandleDisposalCommands;

    private bool $skipResourceDisposal = false;
    public function move(): static { $this->skipResourceDisposal = true; return $this; }
    public function disposeResource(): void { if ($this->skipResourceDisposal) { $this->skipResourceDisposal = false; return; } $this->disposeSource(); }

    public function disposeResourceAsync(): Future { if ($this->skipResourceDisposal) { $this->skipResourceDisposal = false; return Future::complete(); } return $this->disposeSourceAsync(); }
    public function getJsSymbol(Runtime\WellKnownSymbol $symbol): mixed
    {
        return match ($symbol) { Runtime\WellKnownSymbol::Dispose => $this->disposeResource(...), Runtime\WellKnownSymbol::AsyncDispose => $this->disposeResourceAsync(...), default => UndefinedValue::Value };
    }
    /** Source consumers keep the Map without converting through the public PHP array view. */
    public function getPropertiesMap(): Future { return $this->sourceGetProperties(); }

    protected bool $released = false;

    public function __construct(protected ExecutionContext $executionContext, protected array $remote) {}

    public function context(): ExecutionContext { return $this->executionContext; }
    public function getJsProperty(string $name): mixed
    {
        return match($name){'realm'=>$this->executionContext,'id'=>$this->id(),'disposed'=>$this->disposed(),'constructor'=>(object)['name'=>$this instanceof ElementHandle ? 'CdpElementHandle' : 'CdpJSHandle'],default=>UndefinedValue::Value};
    }
    public function __toString(): string { return $this->toString(); }

    public static function value(array $remote): mixed
    {
        return Generated\Upstream\RemoteValues::valueFromRemoteObject($remote);
    }

    public function evaluate(JsFunction|string $function, mixed ...$arguments): Future
    {
        return $this->executionContext->evaluate($function, [$this, ...$arguments]);
    }

    public function evaluateHandle(JsFunction|string $function, mixed ...$arguments): Future
    {
        return $this->executionContext->evaluate($function, [$this, ...$arguments], false);
    }

    /** The PHP API exposes the source Map as an insertion-ordered array of handles. */
    public function getProperties(): Future
    {
        return $this->sourceGetProperties()->map(static function (Runtime\JsMap $map): array {
            $properties = [];
            foreach ($map as $entry) { $properties[Runtime\Js::get($entry, 0)] = Runtime\Js::get($entry, 1); }
            return $properties;
        });
    }
}
