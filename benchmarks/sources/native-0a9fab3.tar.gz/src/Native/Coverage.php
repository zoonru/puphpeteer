<?php

declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Nesk\Puphpeteer\Native\Runtime\Js;

/** Public PHP collection boundary over the generated coverage state machines. */
final class Coverage extends Generated\Upstream\Coverage
{
    public function stopJSCoverage(): Future
    {
        return parent::stopJSCoverage()->map(self::entries(...));
    }

    public function stopCSSCoverage(): Future
    {
        return parent::stopCSSCoverage()->map(self::entries(...));
    }

    private static function entries(mixed $entries): array
    {
        $result = [];
        foreach (Js::iterate($entries) as $entry) { $result[] = (array) Js::toWire($entry); }
        return $result;
    }
}
