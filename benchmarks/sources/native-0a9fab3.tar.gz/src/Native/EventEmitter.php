<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

/** Source-generated EventEmitter and mitt, usable independently of a browser. */
class EventEmitter extends Generated\Upstream\EventEmitter {}
