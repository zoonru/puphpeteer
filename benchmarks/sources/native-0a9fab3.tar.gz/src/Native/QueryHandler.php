<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use Amp\CancelledException;
use Amp\CompositeCancellation;
use Amp\TimeoutCancellation;
use Nesk\Puphpeteer\Native\Generated\Upstream\QueryFunctions;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;
use function Amp\async;

/** Runs the original selector parser and query callbacks beside the DOM. */
final class QueryHandler
{
    public static function waitFor(Frame|ElementHandle $root, string $selector, array $options = []): Future
    {
        return async(function () use ($root, $selector, $options): ?ElementHandle {
            $frame = $root instanceof Frame ? $root : $root->frame();
            $timeout = $options['timeout'] ?? $frame->page()->getDefaultTimeout();
            $deadline = $timeout > 0 ? new TimeoutCancellation($timeout / 1000) : null;
            $signal = $options['signal'] ?? null;
            $cancellation = $deadline && $signal ? new CompositeCancellation($deadline, $signal) : ($signal ?? $deadline);
            $visible = $options['visible'] ?? false;
            $hidden = $options['hidden'] ?? false;
            try {
                while (true) {
                    $cancellation?->throwIfRequested();
                    $context = $frame->manager->context($frame, true, $cancellation);
                    $adopted = $result = null;
                    try {
                        $adopted = $root instanceof ElementHandle ? $context->adoptElement($root)->await() : null;
                        $utility = $context->utility()->await();
                        $descriptor = $context->selectorUtility()->await()->evaluate(new JsFunction(<<<'JS'
(selectors, selector, template) => {
    const {QueryHandler, updatedSelector, polling} = selectors.getQueryHandlerAndSelector(selector);
    const query = QueryHandler.querySelector ? QueryHandler.querySelector.toString()
        : template.replace('__NATIVE_QUERY_ALL_FUNCTION__', '(' + QueryHandler.querySelectorAll.toString() + ')');
    return {query, selector: updatedSelector, polling};
}
JS), $selector, QueryFunctions::queryOneTemplate)->await();
                        $result = $context->waitForFunction(new JsFunction(QueryFunctions::waitFor), [
                            'polling' => $visible || $hidden ? 'raf' : $descriptor['polling'],
                            'root' => $adopted, 'signal' => $cancellation,
                        ], [$utility, $descriptor['query'], $descriptor['selector'], $adopted ?? UndefinedValue::Value,
                            $visible ? true : ($hidden ? false : UndefinedValue::Value)])->await();
                        $cancellation?->throwIfRequested();
                        if (!$result instanceof ElementHandle) { return null; }
                        return $frame->executionContext($cancellation)->adoptElement($result)->await();
                    } catch (\Throwable $error) {
                        if ($root instanceof ElementHandle || $context->active() || $error instanceof CancelledException) { throw $error; }
                    } finally {
                        $result?->dispose()->await();
                        if ($adopted !== null && $adopted !== $root) { $adopted->dispose()->await(); }
                    }
                }
            } catch (CancelledException $error) {
                if ($signal?->isRequested()) { throw $error; }
                throw new TimeoutError('Waiting for selector `' . $selector . '` failed: ' . $timeout . 'ms exceeded', 0, $error);
            } catch (\Throwable $error) {
                throw new \RuntimeException('Waiting for selector `' . $selector . '` failed', 0, $error);
            }
        });
    }

    public static function query(ElementHandle $root, string $selector, bool $all = false): Future
    {
        return async(function () use ($root, $selector, $all): mixed {
            $utility = $root->context()->utility()->await();
            $result = $root->evaluateHandle(new JsFunction(<<<'JS'
async (root, selector, utility, all, selectors) => {
    const {QueryHandler, updatedSelector} = selectors.getQueryHandlerAndSelector(selector);
    if (!all && QueryHandler.querySelector) {
        return await QueryHandler.querySelector(root, updatedSelector, utility);
    }
    const results = [];
    if (QueryHandler.querySelectorAll) {
        for await (const node of QueryHandler.querySelectorAll(root, updatedSelector, utility)) {
            if (!all) return node;
            results.push(node);
        }
    } else {
        const node = await QueryHandler.querySelector(root, updatedSelector, utility);
        if (node) results.push(node);
    }
    return all ? results : null;
}
JS), $selector, $utility, $all, $root->context()->selectorUtility()->await())->await();
            if (!$all) {
                if ($result instanceof ElementHandle) { return $result; }
                $result->dispose()->await();
                return null;
            }
            try {
                return array_values($result->getProperties()->await());
            } finally { $result->dispose()->await(); }
        });
    }
}
