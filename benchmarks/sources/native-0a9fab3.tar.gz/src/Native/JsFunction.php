<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

/** JavaScript executed in a browser realm. PHP callbacks remain in PHP. */
final class JsFunction implements \Stringable
{
    public function __construct(public readonly string $source, private readonly array $parameters = [], public readonly ?Generated\Upstream\PuppeteerURL $sourceUrl = null)
    {
        if (trim($source) === '') {
            throw new \InvalidArgumentException('JavaScript function source cannot be empty');
        }
    }

    public static function createWithBody(string $body): self
    {
        return self::createWithParameters([])->body($body);
    }

    public static function createWithParameters(array $parameters): self
    {
        foreach ($parameters as $parameter) {
            if (!is_string($parameter) || !preg_match('/^[A-Za-z_$][A-Za-z0-9_$]*$/D', $parameter)) {
                throw new \InvalidArgumentException('Invalid JavaScript parameter name');
            }
        }
        return new self('function(' . implode(', ', $parameters) . ') {}', $parameters);
    }

    public function body(string $body): self
    {
        return new self('function(' . implode(', ', $this->parameters) . ') {' . $body . "\n}", $this->parameters);
    }

    public static function sourceUrlFor(mixed $function): mixed { return $function instanceof self ? ($function->sourceUrl ?? Runtime\UndefinedValue::Value) : Runtime\UndefinedValue::Value; }

    public function toString(): string { return Generated\Upstream\FunctionPatterns::sourceText($this->source); }

    public function __toString(): string { return $this->toString(); }
}
