<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

use Nesk\Puphpeteer\Native\Runtime\Js;
use Nesk\Puphpeteer\Native\Runtime\JsError;
use Nesk\Puphpeteer\Native\Runtime\UndefinedValue;

/** PHP error boundary shared by CDP failures and generated ProtocolError branches. */
class ProtocolError extends JsError
{
    private mixed $protocolCode = UndefinedValue::Value;
    private string $originalMessage = '';
    public function __construct(mixed $message = UndefinedValue::Value, mixed $options = UndefinedValue::Value)
    {
        parent::__construct($message, $options);
        parent::setJsProperty('name', 'ProtocolError');
    }
    public function getJsProperty(string $name): mixed
    {
        return match($name){'code'=>$this->protocolCode,'originalMessage'=>$this->originalMessage,default=>parent::getJsProperty($name)};
    }
    public function setJsProperty(string $name, mixed $value): mixed
    {
        if ($name === 'code') { $this->protocolCode = $value; $this->code = is_int($value) ? $value : 0; return $value; }
        if ($name === 'originalMessage') { $this->originalMessage = Js::string($value); return $value; }
        return parent::setJsProperty($name, $value);
    }
}
