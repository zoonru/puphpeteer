<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

/** PHP throwable carrying a non-Error value thrown by browser JavaScript. */
final class JavaScriptException extends \RuntimeException
{
    public function __construct(public readonly mixed $value)
    {
        parent::__construct(Runtime\Js::string($value));
    }
}
