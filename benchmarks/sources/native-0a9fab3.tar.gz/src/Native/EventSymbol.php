<?php
declare(strict_types=1);
namespace Nesk\Puphpeteer\Native;

/** Identity-valued event key corresponding to a JavaScript Symbol. */
final class EventSymbol
{
    public function __construct(public readonly string $description = '') {}
}
