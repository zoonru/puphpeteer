<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Amp\Future;
use function Amp\async;

final class AriaQueryHandler
{
    public static function query(ElementHandle $root, string $selector, bool $all): Future
    {
        return async(function () use ($root, $selector, $all): ?JSHandle {
            $context = $root->context();
            $options = $context->evaluate(new JsFunction('(selector) => ('
                . file_get_contents(__DIR__ . '/Generated/aria-parser.js') . ')(selector)'), [$selector])->await();
            $handles = $root->queryAXTree($options['name'] ?? null, $options['role'] ?? null)->await();
            if (!$all) {
                $first = array_shift($handles);
                foreach ($handles as $handle) { $handle->dispose()->await(); }
                return $first;
            }
            try { return $context->evaluate(new JsFunction('(...elements)=>elements'), $handles, false)->await(); }
            finally { foreach ($handles as $handle) { $handle->dispose()->await(); } }
        });
    }
}
