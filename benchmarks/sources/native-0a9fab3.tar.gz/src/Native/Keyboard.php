<?php

declare(strict_types=1);

namespace Nesk\Puphpeteer\Native;

use Nesk\Puphpeteer\Native\Generated\Upstream\KeyboardCommands;
use Nesk\Puphpeteer\Native\Runtime\StringSet;

/** State and transport for the generated CdpKeyboard implementation. */
final class Keyboard
{
    use KeyboardCommands;

    private StringSet $pressedKeys;
    public int $_modifiers = 0;

    public function __construct(private Session $client)
    {
        $this->pressedKeys = new StringSet();
    }
}
